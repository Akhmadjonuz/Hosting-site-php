<?php
session_start();
define('MTOP', 1);
require_once('system/connect.php');
require_once('system/core.php');
require_once('system/function.php');
$title = 'Новости';
require_once('head.php');
switch($act) 
    { 
        default: 
        echo '<div class="why"><div class="lt"><b>Новости Топ-Рейтинга</b></div></div>';
        $count = mysql_num_rows(mysql_query("SELECT * FROM `news`")); 
        if($count > 0) 
            { 
                $total=intval(($count-1)/$page_news)+1;  
                $page=abs(intval($_GET['page']));  
                if(empty($page) OR $page < 0) 
                    { 
                        $page = 1;  
                    } 
                if($page > $total) 
                    { 
                        $page = $total;  
                    } 
$past=intval($all/$page_news);
$start=$page*$page_news-$page_news;
$onl = mysql_query("SELECT * FROM `".$prefix."news` ORDER BY `time` LIMIT ".$start.",".$page_news."");
                while($row = mysql_fetch_array($onl))  
                    { 

                     
                        $start++; 
                        $count_comment = mysql_num_rows(mysql_query("SELECT * FROM `".$prefix."news_comments` WHERE `id_news` = '".$row['id']."'"));

                        echo '<div class="why"><div class="lt">'.$start.'.<strong>'.$row['name'].' ('.data($row['time']).')</strong><br>'; 
                        echo $row['text'].''; 
                        echo '<br/><small>Добавил: '.$row['author'].' <span style="color:green;">[соз]</span> </small></div></div>'; 

                         
                         
                             
                } 
navigation($count,$page_news,$page,'/n.php?',$total);
            } 
        else 
            { 
                echo '<div class="main">Новостей в Топ-Рейтинге нет!<br/></div>'; 
            } 
        break; 
 

    } 
echo '</section></div></div>';
require_once ('foot.php'); 
?>