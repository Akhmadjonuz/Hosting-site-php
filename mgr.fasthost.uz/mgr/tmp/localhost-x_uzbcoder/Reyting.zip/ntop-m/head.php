<?
if(!$title) $title = $set['top_name'];
echo'<!DOCTYPE html><html lang="ru"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>'.$title.'</title>
<meta name="keywords" content="Рейтинг, топ, сайты, отдача, раскрутка, бесплатно, seo анализ, статистика сайтов, продвижение сайта, как монетезировать сайт, как раскрутить сайт"/>

<meta name="description" content="Мобильный сервис предоставления частичной информации о сайтах, такие как: seo-данные (Yandex Cy, Google PageRank, индекс страниц...), полная статистика посещений сайта с детальным анализом."/>
<meta name="viewport" content="width=device-width" />
<link rel="shortcut icon" href="../style/favicon.ico" / >
<link href="/style/style.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="/style/js/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("div.indicator").delay(1000).fadeOut(1000);
});
</script>';
?>
<script>
$(document).ready(function () {
/*****ПРИМЕР НАжатия*****/
$("#login-form-btn").on('click', function () {
var login = $('#login');
var password = $('#password');
var result = $("#result");
if (login.val() != '') {
result.html('Вы указали логин: <b>' + login.val() + '</b><br> Пароль: ' + password.val());
} else {
result.html('Вы нихрена не указали...').addClass('blink');
}
result.fadeTo("slow", 0.9);
$('#login-form').slideUp('slow');
$('.btn-login').removeClass('open-login');
login.val('');
password.val('');
setTimeout(function () {
$("#result").animate({
opacity: 'hide',
display: 'none'
}, 2900);

}, 3500);
});
/*****ПРИМЕР НАжатия*****/

/*****Та кнопа что тебе нужно *****/
$(".btn-login").on('click', function () {
event.preventDefault();
var ss = $('#login-form');
/*if (ss.is(":hidden")) {
ss.slideDown('slow');
} else {
ss.slideUp('slow');
}*/
ss.slideToggle("slow");
$('.btn-login').toggleClass('open-login');
});
/*****Та кнопа что тебе нужно *****/

});
</script><?
echo '</head><body><div id="fixblock"><div class="header"><a href="/"><img src="/style/img/logo.png" alt=""/></a></div>
<div class="panel"><a href="/m/search"><img src="/style/img/search.png" alt=""/></a>';
if(!$user_data) {
echo'<a href="/m/authentication"><img src="/style/img/add.png" alt=""/></a>';
}
else{
echo '<a href="/m/office"><img src="/style/img/addu.png" alt=""/></a>';
}
echo'<a href="/m/rules"><img src="/style/img/th.png" alt=""/></a><a href="/n.php"><img src="/style/img/ar.png" alt=""/></a></div>';
echo'<span class="login-title">
<button type="button" class="btn-login open-login"></button>
</span>';
if(!$user_data) {
echo '<div id="login-form"><form method="post" action="/m/authentication"><div class="form-group">
<p><strong>&nbsp;&nbsp;Логин</strong>
&nbsp;&nbsp;<input type="text" class="form-control" name="login" placeholder="Ваш логин"></div>
<div class="form-group"><p><strong>Пароль</strong>
<input type="password" class="form-control" name="password" placeholder="Ваш пароль"></div>
<input name="ok" type="submit" value="Войти">
<a href="/m/rules"><font color="#787878">Регистрация</font></a></form></div>';
}
echo '<ul class="hr">
<li><a href="/"><font - color="#6e6e6e"><b>Топ 100</b></font></a> <img src="/style/img/kat_ar.png" alt=""/></li>
<li><a href="/m/category">Категории</a> <img src="/style/img/kat_ar1.png" alt=""/></li>
<li><a href="/m/faq.php">Другое</a> <img src="/style/img/kat_ar1.png" alt=""/>


</li>
</ul>
</div>
<br/><br/><br/><br/><br/>
</div></div></div></div></div></div>




';
if($_SERVER['PHP_SELF']=='/index.php') {
}
?>