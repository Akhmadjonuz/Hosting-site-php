<?php
session_start();
define('MTOP', 1);
require_once('system/connect.php');
require_once('system/core.php');
require_once('system/function.php');
$isset = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'");
if(mysql_num_rows($isset) == 0){
$title = 'Ошибка';
require_once('head.php');
echo '<div main="main"><center>Сайта нет в базе</center></div>';
require_once('foot.php');
exit;
}
$online_sait = mysql_num_rows(mysql_query("SELECT * FROM `sait_online` WHERE `id_sait` = '".$id."'"));
$user = mysql_fetch_array($isset);
if($user['ban'] == 1 AND $user_data['level'] <= 1){
$title = 'Бан';
require_once('head.php');
echo '
<div class="why"><div class="lt"><center>Сайт заблокирован</center></div></div>';
require_once('foot.php');
exit;
}
if($user['status'] == 0 AND $user_data['level'] <= 1){
$title = 'Модерация';
require_once('head.php');
echo '
<div class="main"><center>Вы не можете смотреть статистику данного сайта, так как он проходит модерацию</center></div>';
require_once('foot.php');
exit;
}
switch($act){
default:
$title = 'Информация о сайте';
require_once('head.php');
$category = mysql_fetch_array(mysql_query("SELECT * FROM `cat` WHERE `id` = '".$user['category']."'"));
$rat_plus = mysql_num_rows(mysql_query("SELECT * FROM `".$prefix."reputation` WHERE `id_sait` = '".$id."' AND `type` = 'plus'"));
						$rat_minus = mysql_num_rows(mysql_query("SELECT * FROM `".$prefix."reputation` WHERE `id_sait` = '".$id."' AND `type` = 'minus'"));
						$all_rat = $rat_plus + $rat_minus;
						if($rat_plus > 0)
							{
								$procent_plus = round(($rat_plus/$all_rat)*100,1);
							}
						else
							{
								$procent_plus = '0';
							}
						if($rat_minus > 0)
							{
								$procent_minus = round(($rat_minus/$all_rat)*100,1);
							}
						else
							{
								$procent_minus = '0';
							}
						$proverka_reputation = mysql_num_rows(mysql_query("SELECT * FROM `".$prefix."reputation` WHERE `ip` = '".$ip."' AND `time` > '".(time()-86400)."' AND `id_sait` = '".$id."'"));

$day = mysql_fetch_array(mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'"));
if(isset($user_data) AND $user_data['level'] >= 3 AND $user['status'] == 0)
echo '<div class="main"><center><b><font color="red"><br/>Сайт на модерации</font></b></center></div>';
else if($user['hosts'] <= 0 AND $user['ban'] == 0) echo '<div class="main"><br/><center>Сайт не участвует в TOP-100</center></div>';



echo '<div class="why"><div class="lt"><h1><b>Статистика '.$user['url'].'</b> <small>('.$online_sait.' чел. онлайн | id='.$user['id'].')</small></h1>';

if($user['id_user'] != $user_data['id'] AND $user['skrit'] == 1) {
echo '<div class="main">
Владелец сайта предпочёл скрыть статистику.</div>';
}	


if($user['skrit'] == 0) {
echo '<script src="https://www.google.com/jsapi"></script> <script>
   google.load("visualization", "1", {packages:["corechart"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
    var data = google.visualization.arrayToDataTable([
	["Дата", "Хостов", "Хитов", "Из", "В"],
	["'.date('d.m.y').'", '.$day['hosts'].', '.$day['hits'].', '.$day['in'].', '.$day['out'].'],["'.date("d.m.y", strtotime("-1 day")).'", '.$day['hosts2'].', '.$day['hits2'].', '.$day['in2'].', '.$day['out2'].'],["'.date("d.m.y", strtotime("-2 day")).'", '.$day['hosts3'].', '.$day['hits3'].', '.$day['in3'].', '.$day['out3'].'],    
	]);
    var options = {
     title: "",
     hAxis: {title: "Дата, Хитов, Хостов, В топ, Из топа"},
    };
    var chart = new google.visualization.ColumnChart(document.getElementById("oil"));
    chart.draw(data, options);
   }
  </script> <div id="oil" style="width: 100%; height: 200px;"></div>';
}

if($user['id_user'] == $user_data['id'] AND $user['skrit'] == 1) {
echo '<script src="https://www.google.com/jsapi"></script> <script>
   google.load("visualization", "1", {packages:["corechart"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
    var data = google.visualization.arrayToDataTable([
	["Дата", "Хостов", "Хитов", "Из", "В"],
	["'.date('d.m.y').'", '.$day['hosts'].', '.$day['hits'].', '.$day['in'].', '.$day['out'].'],["'.date("d.m.y", strtotime("-1 day")).'", '.$day['hosts2'].', '.$day['hits2'].', '.$day['in2'].', '.$day['out2'].'],["'.date("d.m.y", strtotime("-2 day")).'", '.$day['hosts3'].', '.$day['hits3'].', '.$day['in3'].', '.$day['out3'].'],    
	]);
    var options = {
     title: "",
     hAxis: {title: "Дата, Хитов, Хостов, В топ, Из топа"},
    };
    var chart = new google.visualization.ColumnChart(document.getElementById("oil"));
    chart.draw(data, options);
   }
  </script> <div id="oil" style="width: 100%; height: 200px;"></div>';
}

echo '<strong><b>Общее</b></strong><br/>Адрес: 
<a href="/out.php?id='.$user['id'].'"><img src="http://www.google.com/s2/favicons?domain='.$user['url'].'" width="15" height="15"> <strong>'.$user['url'].'</a></strong><br/>
Категория: <a href="/m/category/view/'.$user['category'].'"><strong>'.$category['name'].'</strong></a><br/>Описание: '.$user['about'].'<br/>';
echo '<font color=green><strong>За</strong></font> : <strong>'.$rat_plus.'</strong> ['.$procent_plus.'%]<br/>';
						echo '<font color=red><strong>Против</strong></font> : <strong>'.$rat_minus.'</strong> ['.$procent_minus.'%]<br/>';
if($proverka_reputation == 0)
							{
echo '<a href="http://'.$set['home'].'/infos.php?act=reputation_za&id='.$id.'">Повысить репутацию</a> | <a href="http://'.$set['home'].'/infos.php?act=reputation_protiv&id='.$id.'">Понизить репутацию</a>';
}						
	echo '</div></div></div></div>';
	

if($user['id_user'] == $user_data['id'] AND $user['skrit'] == 1) {
	

    
echo '<div class="why"><div class="lt"><tr class="navi3"><table width="100%" margin-left: -2% border="0" cellspacing="1" cellpadding="2">
<tr class="table_name"><td>Дата</td><td>Хосты</td><td>Хиты</td><td>В топ</td><td>Из топа</td></div><tr class="main"><td>Сегодня</td> <td>'.$day['hosts'].'</td> 
<td>'.$day['hits'].'</td> <td>'.$day['in'].'</td> <td>'.$day['out'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-1 day")).'</td> <td>'.$day['hosts2'].'</td>
<td>'.$day['hits2'].'</td><td>'.$day['in2'].'</td> <td>'.$day['out2'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-2 day")).'</td>
<td>'.$day['hosts3'].'</td> <td>'.$day['hits3'].'</td> <td>'.$day['in3'].'</td> <td>'.$day['out3'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-3 day")).'</td> <td>'.$day['hosts4'].'</td> <td>'.$day['hits4'].'</td> 
<td>'.$day['in4'].'</td> <td>'.$day['out4'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-4 day")).'</td>
<td>'.$day['hosts5'].'</td> <td>'.$day['hits5'].'</td> <td>'.$day['in5'].'</td> <td>'.$day['out5'].'</td></tr><tr class="main"><td>'.date("d.m", strtotime("-5 day")).'</td> <td>'.$day['hosts6'].'</td> <td>'.$day['hits6'].'</td> 
<td>'.$day['in6'].'</td> <td>'.$day['out6'].'</td></tr><tr class="main"><td>'.date("d.m", strtotime("-6 day")).'</td> 
<td>'.$day['hosts7'].'</td> <td>'.$day['hits7'].'</td> <td>'.$day['in7'].'</td> <td>'.$day['out7'].'</td></tr><tr class="main"><td>11.03.2016</td> <td>'.$day['hosts8'].'</td> <td>'.$day['hits8'].'</td>
<td>'.$day['in8'].'</td> <td>'.$day['out8'].'</td></tr></table></div></div>	
<div class="why"><div class="lt"><tr class="navi4">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr class="table_name2"><td>Анализ Яндекс</td><td></td></div><tr class="main2"><td>Яндекс Тиц</td> <td>' . getCI($user['url']) . '</td> </tr>	';
echo '<tr class="main2"><td>Яндекс каталог</td> <td>';
$xml=simplexml_load_file("http://bar-navig.yandex.ru/u?ver=2&url=http://".$url."/&show=1");
if(!$xml->topics->topic['title'] and !$xml->topics->topic['url']){
echo 'Нет';
}else{
echo 'Да';
}
echo '</td> </tr></table>';
echo '
<br>-<a href="https://yandex.ru/yandsearch?text='.$user['url'].'&amp;lr=0&amp;noreask=1">Упоминания сайта в поиске </a><br>-
<a href="https://images.yandex.ru/yandsearch?itype=any&amp;site='.$user['url'].'">Картинки сайта в поиске</a><br>-
<a href="https://yandex.ru/yandsearch?text=host:'.$user['url'].'+|+host:www.'.$user['url'].'&amp;how=tm">Индекс с датой индексации</a></div></div>
<div class="why"><div class="lt"><tr class="navi4">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr class="table_name2"><td>Анализ Google</td><td></td></div><tr class="main2"><td>Google PageRank</td> <td>'.$user['pr'].'</td> </tr>
<tr class="main2"><td>DMOZ каталог</td> <td>';
$file = file_get_contents('http://search.dmoz.org/cgi-bin/search?search=u:'.$url);
if(preg_match('#<strong>Open\s*Directory\s*Sites</strong>#ui',$file)){
echo'Да';
}else{
echo'Нет';
}
echo '</td> </tr>';
// гугл  индекс,description,keywords



if (isset($user['url'])){

$_url = $user['url'];
$_url = preg_replace('!^https?://!i', '', $_url);
$_url = preg_replace('!^http?://!i', '', $_url);
$_url = str_replace('/', '', $_url);




$_pars = hornbeam('https://a.pr-cy.ru/'.$_url.'/');
$_seo = hornbeam('http://'.$_url);

preg_match('<meta name="description" content="(.*)/>', $_seo, $_description); 
preg_match('<meta name="keywords" content="(.*)/>', $_seo, $_keywords);

$_description = str_replace('"', '', $_description);
$_keywords = str_replace('"', '', $_keywords);

$_pars = preg_replace('|<!DOCTYPE html>(.*?)Google</div>|is', '', $_pars);
$_pars = preg_replace('|<img class="chart" src="/assets/img/test-chart.svg" >(.*?)</html>|is', '', $_pars);
$_pars = str_replace('</div>', '', $_pars);
$_pars = str_replace('<div class="col-sm-8 content-test">', '', $_pars);
$_pars = str_replace('<span class="red">', '<b>', $_pars);
$_pars = str_replace('</span>', '</b>', $_pars);
}
// гугл  индекс,description,keywords





if ($_description[1])$_desc = $_description[1]; else $_desc = 'Не заполнены.';
if ($_keywords[1])$_key = $_keywords[1]; else $_key = 'Не заполнены.';
echo '

<tr class="main2"><td>Проиндексировано Google</td> <td>'.$_pars.'</td> </tr>




</table><br>-
<a href="https://www.google.com/search?q=link:'.$user['url'].'">Ссылаются на сайт</a><br>-
<a href="https://www.google.ru/search?q=site:'.$user['url'].'&amp;tbm=isch">Картинки сайта на google.com</a><br>-
<a href="https://www.google.com/search?hl=ru&amp;q=info:'.$user['url'].'">Проверка склейки домена</a><br>-
<a href="https://www.google.ru/search?q=related:'.$user['url'].'/&amp;filter=0">Похожие сайты в поисковике</a></div></div>
<div class="why"><div class="lt"><b>Мета теги</b><br>
<b>Описание:</b> '.$_desc.'<br/><br/><b>Ключевые слова:</b> '.$_key.'</div>';	
$_live = hornbeam('https://www.liveinternet.ru/stat/'.$_url.'/');

$_imgLive = '</table><img src="https://www.liveinternet.ru/stat/'.$_url.'/index.gif?avgraph=yes&graph=yes"/>';

$_live = preg_replace('|<html(.*?)по месяцам|is', '', $_live);
$_live = preg_replace('|перестроить(.*?)</html>|is', '', $_live);
$_live = preg_replace('|<input(.*?)"|is', '', $_live);
$_live = preg_replace('|<td>id_(.*?)</td>|is', '<td></td>', $_live);
$_live = preg_replace('|<a href="(.*?)">|is', '', $_live);
$_live = str_replace('width=520', 'width=100%', $_live);
if (strripos($_live, 'Просмотры'))
echo $_live.$_imgLive;  
else echo '<center><B>Данных об статистике LiveInternet не найдено.</B></center><br />';
}


if($user['skrit'] == 0) {
echo '<div class="why"><div class="lt"><tr class="navi3"><table width="100%"  margin-left: -2% border="0" cellspacing="1" cellpadding="3">
<tr class="table_name"><td>Дата</td><td>Хосты</td><td>Хиты</td><td>В топ</td><td>Из топа</td></div><tr class="main"><td>Сегодня</td> <td>'.$day['hosts'].'</td> 
<td>'.$day['hits'].'</td> <td>'.$day['in'].'</td> <td>'.$day['out'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-1 day")).'</td> <td>'.$day['hosts2'].'</td>
<td>'.$day['hits2'].'</td><td>'.$day['in2'].'</td> <td>'.$day['out2'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-2 day")).'</td>
<td>'.$day['hosts3'].'</td> <td>'.$day['hits3'].'</td> <td>'.$day['in3'].'</td> <td>'.$day['out3'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-3 day")).'</td> <td>'.$day['hosts4'].'</td> <td>'.$day['hits4'].'</td> 
<td>'.$day['in4'].'</td> <td>'.$day['out4'].'</td></tr><tr class="main"><td>'.date("d.m.y", strtotime("-4 day")).'</td>
<td>'.$day['hosts5'].'</td> <td>'.$day['hits5'].'</td> <td>'.$day['in5'].'</td> <td>'.$day['out5'].'</td></tr><tr class="main"><td>'.date("d.m", strtotime("-5 day")).'</td> <td>'.$day['hosts6'].'</td> <td>'.$day['hits6'].'</td> 
<td>'.$day['in6'].'</td> <td>'.$day['out6'].'</td></tr><tr class="main"><td>'.date("d.m", strtotime("-6 day")).'</td> 
<td>'.$day['hosts7'].'</td> <td>'.$day['hits7'].'</td> <td>'.$day['in7'].'</td> <td>'.$day['out7'].'</td></tr><tr class="main"><td>11.03.2016</td> <td>'.$day['hosts8'].'</td> <td>'.$day['hits8'].'</td>
<td>'.$day['in8'].'</td> <td>'.$day['out8'].'</td></tr></table></div></div>	
<div class="why"><div class="lt"><tr class="navi4">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr class="table_name2"><td>Анализ Яндекс</td><td></td></div><tr class="main2"><td>Яндекс Тиц</td> <td>' . getCI($user['url']) . '</td> </tr>	';
echo '<tr class="main2"><td>Яндекс каталог</td> <td>';
$xml=simplexml_load_file("http://bar-navig.yandex.ru/u?ver=2&url=http://".$url."/&show=1");
if(!$xml->topics->topic['title'] and !$xml->topics->topic['url']){
echo 'Нет';
}else{
echo 'Да';
}
echo '</td> </tr></table>';
echo '
<br>-<a href="https://yandex.ru/yandsearch?text='.$user['url'].'&amp;lr=0&amp;noreask=1">Упоминания сайта в поиске </a><br>-
<a href="https://images.yandex.ru/yandsearch?itype=any&amp;site='.$user['url'].'">Картинки сайта в поиске</a><br>-
<a href="https://yandex.ru/yandsearch?text=host:'.$user['url'].'+|+host:www.'.$user['url'].'&amp;how=tm">Индекс с датой индексации</a></div></div>
<div class="why"><div class="lt"><tr class="navi4">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr class="table_name2"><td>Анализ Google</td><td></td></div><tr class="main2"><td>Google PageRank</td> <td>'.$user['pr'].'</td> </tr>
<tr class="main2"><td>DMOZ каталог</td> <td>';
$file = file_get_contents('http://search.dmoz.org/cgi-bin/search?search=u:'.$url);
if(preg_match('#<strong>Open\s*Directory\s*Sites</strong>#ui',$file)){
echo'Да';
}else{
echo'Нет';
}
echo '</td> </tr>';










// гугл  индекс,description,keywords



if (isset($user['url'])){

$_url = $user['url'];
$_url = preg_replace('!^https?://!i', '', $_url);
$_url = preg_replace('!^http?://!i', '', $_url);
$_url = str_replace('/', '', $_url);




$_pars = hornbeam('https://a.pr-cy.ru/'.$_url.'/');
$_seo = hornbeam('http://'.$_url);

preg_match('<meta name="description" content="(.*)/>', $_seo, $_description); 
preg_match('<meta name="keywords" content="(.*)/>', $_seo, $_keywords);

$_description = str_replace('"', '', $_description);
$_keywords = str_replace('"', '', $_keywords);

$_pars = preg_replace('|<!DOCTYPE html>(.*?)Google</div>|is', '', $_pars);
$_pars = preg_replace('|<img class="chart" src="/assets/img/test-chart.svg" >(.*?)</html>|is', '', $_pars);
$_pars = str_replace('</div>', '', $_pars);
$_pars = str_replace('<div class="col-sm-8 content-test">', '', $_pars);
$_pars = str_replace('<span class="red">', '<b>', $_pars);
$_pars = str_replace('</span>', '</b>', $_pars);
}
// гугл  индекс,description,keywords





if ($_description[1])$_desc = $_description[1]; else $_desc = 'Не заполнены';
if ($_keywords[1])$_key = $_keywords[1]; else $_key = 'Не заполнены';

echo '<tr class="main2"><td>Проиндексировано Google</td> <td>'.$_pars.'</td> </tr>


</table><br>-
<a href="https://www.google.com/search?q=link:'.$user['url'].'">Ссылаются на сайт</a><br>-
<a href="https://www.google.ru/search?q=site:'.$user['url'].'&amp;tbm=isch">Картинки сайта на google.com</a><br>-
<a href="https://www.google.com/search?hl=ru&amp;q=info:'.$user['url'].'">Проверка склейки домена</a><br>-
<a href="https://www.google.ru/search?q=related:'.$user['url'].'/&amp;filter=0">Похожие сайты в поисковике</a></div></div>


<div class="why"><div class="lt"><b>Мета теги</b><br>

<b>Описание:</b> '.$_desc.'<br/><br/><b>Ключевые слова:</b> '.$_key.'</div></div></table>';
$_live = hornbeam('https://www.liveinternet.ru/stat/'.$_url.'/');

$_imgLive = '</table><img src="https://www.liveinternet.ru/stat/'.$_url.'/index.gif?avgraph=yes&graph=yes" width="100%"/>';

$_live = preg_replace('|<html(.*?)по месяцам|is', '', $_live);
$_live = preg_replace('|перестроить(.*?)</html>|is', '', $_live);
$_live = preg_replace('|<input(.*?)"|is', '', $_live);
$_live = preg_replace('|<td>id_(.*?)</td>|is', '<td></td>', $_live);
$_live = preg_replace('|<a href="(.*?)">|is', '', $_live);

$_live = str_replace('width=520', 'width=100%', $_live);

if (strripos($_live, 'Просмотры'))
echo $_live.$_imgLive;  
else echo '<div class="why"><center><B>Данных об статистике LiveInternet не найдено.</B></center><br/></div>';

}


break;
case 'reputation_za':
$title = 'Рейтинг сайта '.$user['url'].'';
require_once('head.php');
echo '<div class="why"><div class="lt">Рейтинг сайта</div>';
$proverka_reputation = mysql_num_rows(mysql_query("SELECT * FROM `reputation` WHERE `ip` = '".$ip."' AND `time` > '".(time()-86400)."' AND `id_sait` = '".$id."'"));
if($proverka_reputation == 0)
{
$repa = mysql_query("INSERT INTO `reputation` SET `type` = 'plus', `ip` = '".$ip."', `time` = '".time()."', `id_sait` = '".$id."'");
if($repa)
{
echo '<div class="why"><div class="lt">';
echo '<center>Репутация сайта успешно повышена на +1 единицу</center>';
echo '</div></div>';
}
else
{
echo '<div class="why"><div class="lt">';
echo '<center>Репутация не изменена</center>';
echo '</div></div>';
}
}
else
{
echo '<div class="why"><div class="lt">';
echo '<center>Вы уже голосовали за этот сайт, голосовать можно 1 раз в 24 часа</center>';
echo '</div></div>';
}
break;

case 'reputation_protiv':
$title = 'Рейтинг сайта '.$user['url'].'';
require_once('head.php');
echo '<div class="why"><div class="lt">Рейтинг сайта</div></div>';
$proverka_reputation = mysql_num_rows(mysql_query("SELECT * FROM `reputation` WHERE `ip` = '".$ip."' AND `time` > '".(time()-86400)."' AND `id_sait` = '".$id."'"));
if($proverka_reputation == 0)
{
$repa = mysql_query("INSERT INTO `reputation` SET `type` = 'minus', `ip` = '".$ip."', `time` = '".time()."', `id_sait` = '".$id."'");
if($repa)
{
echo '<div class="why"><div class="lt">';
echo '<center>Репутация сайта изменена!</center>';
echo '</div></div>';
}
else
{
echo '<div class="why"><div class="lt">';
echo '<center>Репутация не изменена</center>';
echo '</div></div>';
}
}
else
{
echo '<div class="why"><div class="lt">';
echo '<center>Вы уже голосовали за этот сайт, голосовать можно 1 раз в 24 часа</center>';
echo '</div></div>';
}
break;
}
require_once('foot.php');
?>