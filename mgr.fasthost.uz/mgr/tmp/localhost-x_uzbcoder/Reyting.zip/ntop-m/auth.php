<?php
define('MTOP', 1);
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
unreg();
$user_isset = mysql_query("SELECT * FROM `users` WHERE `login` = '".filter($_POST['login'])."' AND `password` = '".filter($_POST['password'])."'");
if(mysql_num_rows($user_isset) > 0){
SetCookie('login',filter($_POST['login']),time()+3600*24*365, '/');
SetCookie('password',filter($_POST['password']),time()+3600*24*365, '/');
}
$title = 'Страница авторизации';
require_once ('head.php');
echo '<div class="main">';
$avtoriz = '<form action="" method="POST">Ваш логин:<br/>
<input type="text" class="input" name="login" maxlength="30" value="" size="20" maxlength="50" /><br/>Ваш пароль:<br/>
<input type="password" class="input" name="password" maxlength="30" value="" size="20" maxlength="50" /><br/>
<input name="ok" type="submit" value="Войти" /><br/></form></div>
</div><div class="why"><div class="lt"><a href="/m/registration">Регистрация</a></div></div>';
if($_POST['ok'] != null){
if(empty($_POST['login']) OR empty($_POST['password']))
$error = '<div class="error">Не заполнено одно или несколько полей</div>';
if(isset($error)){
echo $error;
echo $avtoriz;
}
else{
$login = filter($_POST['login']);
$password = filter($_POST['password']);
$user_isset = mysql_query("SELECT * FROM `users` WHERE `login` = '".$login."' AND `password` = '".$password."'");
if(mysql_num_rows($user_isset) > 0){
$row = mysql_fetch_array($user_isset);
echo '<br/>Добро пожаловать, <font color="green">'.$row['login'].'</font>!<br/><a href="/m/office">Перейти в кабинет</a><br/></div>';
}else{
echo '<div class="error">Неправильный логин или пароль</div>';
echo $avtoriz;
}
}
}
else echo $avtoriz;
require_once ('foot.php');
?>