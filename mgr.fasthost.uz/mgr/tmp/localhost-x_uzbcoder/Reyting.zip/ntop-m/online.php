<?php
session_start();
define('MTOP', 1);
require_once('system/connect.php');
require_once('system/core.php');
require_once('system/function.php');
$title = 'Все сайты - онлайн пользователей';
require_once('head.php');
echo '<div class="title2">'.$title.'</div>';
$all = mysql_num_rows(mysql_query("SELECT * FROM `sait_online`"));
if($all != 0){
echo '<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr class="main"><td>IP</td><td>Браузер</td><td>Время</td></tr>';
$total=intval(($all-1)/$pages)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($all/$pages);
$start=$page*$pages-$pages;
$onl = mysql_query("SELECT * FROM `sait_online` LIMIT ".$start.",".$pages."");
while($row = mysql_fetch_array($onl)) echo '<tr class="main"><td>'.$row['ip'].'</td> <td>'.$row['ua'].'</td> <td>'.data($row['time']).'</td></tr>';
echo '</table>';
navigation($all,$pages,$page,'infos.php?act=online&id='.$id.'&',$total);
}
else {
echo '<div class="main"><center>бай ямус</center></div>';
}
require_once('foot.php');
?>