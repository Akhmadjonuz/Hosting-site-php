<?php
define('MTOP', 1);
$title = 'Статистика рейтинга';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
$plaforms_moder = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `status` = '0' AND `ban` = '0'"));
$plaforms_akt = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `status` = '1' AND `ban` = '0' AND `hosts` > '0'"));
$news_all = mysql_num_rows(mysql_query("SELECT * FROM `".$prefix."news`"));
$plaforms_ban = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `ban` = '1'"));
$plaforms_all = mysql_num_rows(mysql_query("SELECT * FROM `sait`"));
$users_all = mysql_num_rows(mysql_query("SELECT * FROM `users`"));
$cat_all = mysql_num_rows(mysql_query("SELECT * FROM `cat`"));
$saits = mysql_query("SELECT * FROM `sait` ORDER BY `id`");
while($sait = mysql_fetch_array($saits)){
$day_host = $day_host + $sait['hosts'];
$day_hit = $day_hit + $sait['hits'];
$yday_host = $yday_host  + $sait['hosts2'];
$yday_hit = $yday_hit + $sait['hits2'];
$all_host = $all_host + $sait['all_hosts'];
$all_hit = $all_hit + $sait['all_hits'];
$day_in = $day_in + $sait['in'];
$day_out = $day_out + $sait['out'];
$yday_in = $yday_in + $sait['in2'];
$yday_out = $yday_out + $sait['out2'];
$all_in = $all_in + $sait['all_in'];
$all_out = $all_out + $sait['all_out'];
}
$online = mysql_num_rows(mysql_query("SELECT * FROM `sait_online`"));
echo '<div class="why"><div class="lt"><b>Общее</b><br>
Всего пользователей: <b>'.$users_all.'</b><br/>
Всего площадок: <b>'.$plaforms_all.'</b><br/>
Активных сегодня: <b>'.$plaforms_akt.'</b><br/>
На модерации: <b>'.$plaforms_moder.'</b><br/>
Заблокированных: <a href="/m/ban"><b>'.$plaforms_ban.'</a></b><br/>
Всего категорий: <b>'.$cat_all.'</b><br/>
Всего новостей: <b>'.$news_all.'</b></br>
Сейчас на сайтах сидит:<b> '.$online.' </b>человек(а)<br />';
echo '<b>Сегодня </b><br>
Хостов: <b>'.$day_host.'</b><br/>
Хитов: <b>'.$day_hit.'</b><br/>
В топ: <b>'.$day_in.'</b><br/>
Из топа: <b>'.$day_out.'</b>
<br><b>Вчера </b><br>
Хостов: <b>'.$yday_host.'</b><br/>
Хитов: <b>'.$yday_hit.'</b><br/>
В топ: <b>'.$yday_in.'</b><br/>
Из топа: <b>'.$yday_out.'</b>
<br><b>ЗА МЕСЯЦ</b><br>
Хостов: <b>'.$all_host.'</b><br/>
Хитов: <b>'.$all_hit.'</b><br/>
В топ: <b>'.$all_in.'</b><br/>
Из топа: <b>'.$all_out.'</b></div></div>';
require_once ('foot.php');
?>