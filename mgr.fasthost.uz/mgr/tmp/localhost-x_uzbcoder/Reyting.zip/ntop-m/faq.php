<?php
define('MTOP', 1);
$title = 'Другие разделы';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
echo '<div class="why"><div class="lt"><b>Разделы сайта </b><br>
Сайт '.$set['home'].' стремится стать полезным ресурсом для wap/web - мастеров. Мы добавляем полезные разделы и модули, которые помогут Вам проанализировать ваш сайт,
либо поднять популярность вашего сайта в поисковиках. <br><br>
<b>Другие разделы '.$set['home'].' :</b><br><a href="/m/global_stat.php">Статистика топа </a> | <a href="/m/ban">Бан-лист </a> |
<a href="/m/rules">Правила </a> | <a href="/m/info.php">Помощь </a> | <a href="/contacts.php">Контакты </a></div></div>';
require_once ('foot.php');
?>