<?php
header('Location: /?error=error');
exit;
?>