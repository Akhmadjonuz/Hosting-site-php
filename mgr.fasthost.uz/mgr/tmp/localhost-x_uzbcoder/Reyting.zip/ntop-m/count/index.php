<?php
define('MTOP', 1);
require_once ('../system/connect.php');
require_once ('../system/core.php');
require_once ('../system/function.php');
error_reporting(0);
header('Content-Type: image/png'); 
$sait_t = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'");
if(mysql_num_rows($sait_t) > 0){
$sait = mysql_fetch_array($sait_t);
if($sait['status'] == 0){
header('Content-Type: image/png'); 
$img = '../images/noactiv.png';
$image = imagecreatefrompng($img);
imagepng($image);
imageDestroy($image);
exit;
}
if($sait['ban'] == 1){
header('Content-Type: image/png'); 
$img = '../images/block.png';
$image = imagecreatefrompng($img);
imagepng($image);
imageDestroy($image);
exit;
}
if($_GET['size'] == 'small') $img = '../images/small/'.$sait['image_s'].'.png';
$image = imagecreatefrompng($img);
$type_img = mysql_fetch_array(mysql_query("SELECT * FROM `images` WHERE `name` = '".$sait['image']."'"));
$old_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
$operator_id = mysql_query("SELECT `id` FROM `ip` WHERE INET_ATON('".$ip."') BETWEEN `start` AND `finish`");
if(mysql_num_rows($sql) > 0){
$arr = mysql_fetch_array($operator_id);
$operator = $arr['id'];
}
else $operator = 0;
$isset = mysql_query("SELECT * FROM `hosts` WHERE `id_sait` = '".$id."' AND `ip` = '".$ip."' AND `time` > '".$old_day."'");
if (mysql_num_rows($isset) == 0){
mysql_query("INSERT INTO `hosts` SET `time` = '".time()."', `id_sait` = '".$id."', `ip` = '".$ip."',`browser` = '".browser()."', `operator` = '".$operator."'");
mysql_query("UPDATE `sait` SET `hosts` = (`hosts` + 1), `all_hosts` = (`all_hosts` + 1) WHERE `id` = '".$id."'");
mysql_query("INSERT INTO `hits` SET `time` = '".time()."', `id_sait` = '".$id."' ,`ip` = '".$ip."',`browser` = '".browser()."', `operator` = '".$operator."'");
mysql_query("UPDATE `sait` SET `hits` = (`hits` + 1), `all_hits` = (`all_hits` + 1) WHERE `id` = '".$id."'");
}
else{
mysql_query("INSERT INTO `hits` SET `time` = '".time()."', `id_sait` = '".$id."' ,`ip` = '".$ip."',`browser` = '".browser()."', `operator` = '".$operator."'");
mysql_query("UPDATE `sait` SET `hits` = (`hits` + 1), `all_hits` = (`all_hits` + 1) WHERE `id` = '".$id."'");
}
if (mysql_num_rows(mysql_query("SELECT * FROM `sait_online` WHERE `ip` = '".$ip."' AND `ua` = '".$ua."' AND `time` > '".(time()-180)."' AND `id_sait` = '".$id."'")) == 1)
mysql_query("UPDATE `sait_online` SET `time` = '".time()."' WHERE `ip` = '".$ip."' AND `ua` = '".$ua."' AND `id_sait` = '".$id."' LIMIT 1");
else{
mysql_query("DELETE FROM `sait_online` WHERE `time` < '".(time()-180)."' AND `id_sait` = '".$id."'");
mysql_query("INSERT INTO `sait_online` (`id_sait`,`ip`, `ua`, `time`) values('".$id."','".$ip."', '".$ua."', ".time().")");
}
if($_GET['size'] == 'big'){
$img = '../images/big/'.$sait['image'].'.png';
$image = imagecreatefrompng($img);
$real_stat = mysql_fetch_array(mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'"));
$hits = 70 - (strlen($real_stat['hits']) * 5);
$hosts = 32 - (strlen($real_stat['hosts']) * 5);
$black = imagecolorallocate($image, 000, 000, 000);
$font ="../style/counters.ttf"; 
imagettftext($image,6,0,25,22,$black,$font,$real_stat['hosts']); 
}
}
else{
$img = '../images/noactiv.png';
$image = imagecreatefrompng($img);
}
imagepng($image);
imageDestroy($image);
?>