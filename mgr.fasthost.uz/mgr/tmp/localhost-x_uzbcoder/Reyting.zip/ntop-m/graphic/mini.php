<?php
define('MTOP', 1);
require_once ('../system/connect.php');
require_once ('../system/core.php');
require_once ('../system/function.php');

$sait_t = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'");
if(mysql_num_rows($sait_t) == 0){
$img = imageCreate(32, 32);
$color = imageColorAllocate($img, 255, 255, 255);
$black = ImageColorAllocate($img, 0, 0, 0);
$trans = imagecolortransparent($img, $black); 
imageFilledRectangle($img, 0, 0, 31, 31, $trans);
header("Content-type: image/png");
$color = imageColorAllocate($img, 255,175,3);
imageLine($img, 1, 30, 30, 30, $color);
imagepng($img);
imagedestroy($img);

}else{

$img = imageCreate(32, 32);
$color = imageColorAllocate($img, 255, 255, 255);
$black = ImageColorAllocate($img, 0, 0, 0);
$trans = imagecolortransparent($img, $black); 
imageFilledRectangle($img, 0, 0, 31, 31, $trans);
header("Content-type: image/png");
$sait = mysql_fetch_array(mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'"));
$max = $sait['hosts7'];
if($sait['hosts2'] > $max) $max = $sait['hosts2'];
if($sait['hosts3'] > $max) $max = $sait['hosts3'];
if($sait['hosts4'] > $max) $max = $sait['hosts4'];
if($sait['hosts5'] > $max) $max = $sait['hosts5'];
if($sait['hosts6'] > $max) $max = $sait['hosts6'];
if($max != 0) $umn = 30 / $max; else $umn = 0;
$hosts   = 30 - ( $sait['hosts7'] * $umn); if($hosts   < 0) $hosts  = 0;
$hosts2 = 30 - ( $sait['hosts6'] * $umn); if($hosts2 < 0) $hosts2 = 0;
$hosts3 = 30 - ( $sait['hosts5'] * $umn); if($hosts3 < 0) $hosts3 = 0;
$hosts4 = 30 - ( $sait['hosts4'] * $umn); if($hosts4 < 0) $hosts4 = 0;
$hosts5 = 30 - ( $sait['hosts3'] * $umn); if($hosts5 < 0) $hosts5 = 0;
$hosts6 = 30 - ( $sait['hosts2']   * $umn); if($hosts6 < 0) $hosts6 = 0;
if($sait['hosts2'] > $sait['hosts3']) $color = imageColorAllocate($img, 0,255,0);
else $color = imageColorAllocate($img, 255,0,0);
imageLine($img, 1, $hosts, 7, $hosts2, $color);    
imageLine($img, 7, $hosts2, 13, $hosts3, $color);    
imageLine($img, 13, $hosts3, 19, $hosts4, $color);    
imageLine($img, 19, $hosts4, 25, $hosts5, $color);    
imageLine($img, 25, $hosts5, 30, $hosts6, $color);
imagepng($img);
imagedestroy($img);

}
?>