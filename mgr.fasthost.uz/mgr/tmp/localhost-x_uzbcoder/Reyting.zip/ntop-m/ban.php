<?php
define('MTOP', 1);
$title = 'БАН - Лист';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
$count = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `ban` = '1'"));
if($count > 0){
$total=intval(($count-1)/$page_sait)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total)$page = $total;
$past=intval($count/$page_sait);
$start=$page*$page_sait-$page_sait;
echo '<div class="why"><div class="lt"><b>Заблокированные сайты</b><br>';
$saits = mysql_query("SELECT * FROM `sait` WHERE `ban` = '1' ORDER BY `id` DESC LIMIT ".$start.",".$page_sait."");
while($row = mysql_fetch_array($saits)){
$start++;
echo '<b>'.$start.' . </b><strong> '.$row['url'].' [ ID : '.$row['id'].' ]</strong> <br>';
echo 'Причина блокировки: '.$row['ban_reason'].'';
echo '<br/><br><br>--------<br/>';
}
echo '</div></div>';
navigation($count,$page_sait,$page,'ban.php?sort='.$sort.'&',$total);
}
else {
echo '<div class="why"><div class="lt"><b>Заблокированные сайты</b><br>';
echo '<br><center>Нет заблокированных сайтов</center></div></div>';
}
require_once ('foot.php');
?>