<?php
session_start();
define('MTOP', 1);
$title = 'Поиск сайта';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once('head.php');
echo '<br/><font color="#fff">Поиск сайта</font><div class="main">';
echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST" name="form">
Введите запрос <small>[min 4 , max 60 символов]</small><br/>
<input type="text" name="search" maxlenght="110" value="'.htmlspecialchars($_POST['search']).'"/><br/>
Параметры поиска :<br/>
<select name="m">
<option value="1">url</option>
<option value="2">Название сайта</option>
<option value="3">Описание сайта</option>
</select><br/>
<input name="n" type="checkbox" value="1"/> Точный поиск<br/>
<input type="submit" name="go"value="Поиск">
</form></div>';
if (isset($_POST['go']) ) {
if (mb_strlen($_POST['search']) < 3 || mb_strlen($_POST['search']) > 60 ) {
$error[2] = 'Длина запроса должна быть не менее 4 символов и не привышать 60 символов';
}
}
if (!empty($error)) {
echo '<font color="#fff">';
foreach($error as $value) {
echo "<center>$value<br /></center>";
}
echo '</font>';
require_once ('foot.php');
exit();
}

$mm = isset ($_POST['m']) ? intval($_POST['m']) : '';
$mm = $mm ? $mm : rawurldecode(trim($_GET['m']));
$n = isset ($_POST['n']) ? $_POST['n'] : '';
$n = $n ? $n : rawurldecode(trim($_GET['n']));

$search = isset ($_POST['search']) ? trim($_POST['search']) : '';
$search = strtr($search, array('_' => '\\_', '%' => ' ','$' => ' ', '*' => '%'));
$search = $search ? $search : rawurldecode(trim($_GET['search']));
if ($search) {
$search_db = 'LIKE \'' . mysql_real_escape_string('%' . $search . '%') . '\'';
if ($_POST['n'] == false) $search_db = 'LIKE \'' . mysql_real_escape_string('%' . $search . '%') . '\'';
if ($_POST['n'] == true) {
$search_db = '= "'.mysql_real_escape_string($search).'"';
}
$zap = '`about`';
if ($_POST['m'] == 1 || $_GET['mm'] == 1) $zap = '`url`';
if ($_POST['m'] == 2 || $_GET['mm'] == 2) $zap = '`name`';
if ($_POST['m'] == 3 || $_GET['mm'] == 3) $zap = '`about`';

$count = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE ".$zap." ".$search_db." "));
if($count > 0)
{
$total=intval(($count-1)/$page_sait)+1; 
$page=abs(intval($_GET['page'])); 
if(empty($page) OR $page < 0)
{
$page = 1; 
}
if($page > $total)
{
$page = $total; 
}
$past=intval($count/$page_sait);  
$start=$page*$page_sait-$page_sait; 
$saits = mysql_query("SELECT * FROM `sait` WHERE ".$zap." ".$search_db." ORDER BY `id` DESC LIMIT ".$start.",".$page_sait."");
while($row = mysql_fetch_array($saits)) 

{
$start++;
   $category = mysql_fetch_array(mysql_query("SELECT * FROM `cat` WHERE `id` = '".$row['category']."'"));
    if($row['hosts']<$row['hosts2']){
        $value = $row['hosts2']-$row['hosts'];
        $active_hosts = '<font color="red">-'.$value.'</font>';
    }elseif($row['hosts']>$row['hosts2']){
        $value = $row['hosts']-$row['hosts2'];
        $active_hosts = '<font color="green">+'.$value.'</font>';
    }





echo '
	</div><div class="why"><div class="lt">





<div class="cn">


'.$start.'</div>



 <a href="/out.php?id='.$row['id'].'" title="Переход на сайт '.$row['url'].'">'.$row['url'].'</a> '.$active_hosts.'<div class="cnt"><b></small>

[

'.$row['hosts'].'/'.$row['hits'].' ]</small></b>
</b></div> <div class="c">
<a href="/stats/'.$row['id'].'"><br><img src="/graphic/mini/'.$row['id'].'.png"></a></div>

<br/><small>'.$row['about'].'</small><br/></font></b>Категория: <a href="/m/category/view/'.$row['category'].'">'.$category['name'].'</a>
</font></font></div></div>';
}
navigation($all,$page_top,$page,'http://'.$set['home'].'/search?search='.$search.'&n=0&mm='.$mm.'&page=',$total);
}
else {
echo '<font color="#fff"><center>Ничего не найдено</center></font>';
}
}

require_once('foot.php');
?>