<?php
define('MTOP', 1);
$title = 'Контакты';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
echo '<div class="why"><div class="lt"><b>Контакты</b><br>Telegram: @bossiks
<br>E-MAIL: virusdizer@gmail.com (не рек.)<br>
VK: <u><a href="https://vk.com/id492815571">Иван Крымский</a></u> (рек.)</div></div>';
require_once ('foot.php');
?>