<?php
session_start();
$width=75;
$height=20;
$im=imagecreatetruecolor($width, $height);
imagefill($im, 0, 0, imagecolorallocate($im, 255, 255, 255));
$str=NULL;
for($i=0; $i<5; $i++){
$y=rand(2, 5);
$x+=rand(8, 14);
$str.=rand(1, 9);
imagestring($im, rand(1, 10), $x, $y, $str[$i],
imagecolorallocate($im, rand(90, 150), rand(90, 150), rand(90, 150)));
}
$_SESSION['kod'] = $str;
header('Content-type: image/jpeg');
imagepng($im);
imagedestroy($im);
?>