<?php
define('MTOP', 1);
$title = 'Выход';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
reg();
$nouser = 1;
SetCookie('login','',time(), '/');
SetCookie('password','',time(), '/');
require_once ('head.php');
echo '<div class="main"><br>Вы успешно вышли!</div>';
require_once ('foot.php');
?>