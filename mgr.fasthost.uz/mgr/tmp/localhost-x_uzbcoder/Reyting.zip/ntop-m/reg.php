<?php
session_start();
define('MTOP', 1);
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
unreg();
$title = 'Регистрация';
require_once ('head.php');
echo'<div class="why"><div class="lt"><b>Регистрация</b></div></div>';
$registr = '<form action="" method="post">
Логин: [A-Za-z0-9_-] (max.30)<br/>
<input name="login" type="text" maxlength="30" value="" /><br/>
Пароль(max.30):<br/>
<input name="password" type="text" maxlength="30" value="" /><br/>
Ваш e-mail адрес:<br/>
<input name="mail" type="text" maxlength="50" value="" /><br/>
Код с картинки: <img src="/captha.jpg" maxlength="5" alt="*" /><br/>
<input name="kod" type="text" value="" /><br/>
<input name="ok" type="submit" value="Регистрировать" /></form><div class="why"><div class="lt"><small>Все поля ОБЯЗАТЕЛЬНЫ к заполнению.</small><br/>
<small>Регистрируясь, вы соглашаетесь с <a href="/m/rules">ПРАВИЛАМИ</a> рейтинга.</small></div></div>';
if($set['power_reg'] == 0){
echo '<div class="main"><center>Регистрация закрыта</center></div>';
require_once ('foot.php');
exit;
}
if(isset($_POST['ok'])){
$login = filter($_POST['login']);
$pass = filter($_POST['password']);
$mail = filter($_POST['mail']);
$kod = (int)$_POST['kod'];
$error = '';
if(empty($login) or empty($pass) or empty($mail) or empty($kod))
$error .= '<div class="error">Не заполнено одно или несколько полей</div>';
else {
if($_SESSION['kod']!=$kod)
$error .= '<div class="error">Код с картинки введен неверно</div>';
if(mb_strlen($login) > 30 OR mb_strlen($login) < 5)
$error .= '<div class="error">Длина логина должна быть не короче 5 и не длиннее 30 символов</div>';
if (mysql_num_rows(mysql_query("SELECT * FROM `users` WHERE `login` = '".$login."' LIMIT 1")) != 0)
$error .= '<div class="error">Такой логин уже зарегистрирован</div>';
if (!preg_match('|^[a-z0-9\-_]+$|i',$login))
$error .= '<div class="error">В логине можно использовать только буквы английского алфавита и цифры</div>';
if(mb_strlen($mail) > 50 OR mb_strlen($mail) < 5)
$error .= '<div class="error">Длина e-mail должна быть не короче 5 и не длиннее 50 символов</div>';
if(mb_strlen($pass) > 30 OR mb_strlen($pass) < 4)
$error .= '<div class="error">Длина пароля должна быть не короче 4 и не длиннее 30 символов</div>';
elseif (!empty($mail) and !preg_match('#^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+(\.([A-Za-z0-9])+)+$#', $mail))
$error .= '<div class="error">E-mail введен неверно</div>';
if (!empty($mail) and (mysql_num_rows(mysql_query("SELECT * FROM `users` WHERE `mail` = '".$mail."' LIMIT 1")) != 0))
$error .= '<div class="error">Такой e-mail уже зарегистрирован в системе</div>';
}
if(!empty($error)){
echo $error;
echo $registr;
}
else{
unset($_SESSION['kod']);
$reg = mysql_query("INSERT INTO `users` SET `login` = '".$login."', `password` = '".$pass."', `mail` = '".$mail."', `page_sait` = '".$set['page_sait']."', `page_platforms` = '".$set['page_platforms']."', `page_top` = '".$set['page_top']."', `pages` = '".$set['pages']."', `level` = '1', `time_reg` = '".time()."'");
if($reg){
echo '<div class="main">Вы успешно зарегистрировались в Топ-Рейтинге ! Теперь войдите под своими данными и добавьте площадку.<br />
<a href="/m/authentication">Вход</a></div>';
$subject = "Регистрация в топ-рейтинге ".$set['home'];
$body = "Вы успешно зapeгиcтриpoвaны в топ-рейтинге ".$set['home']."!<br/><br/>
Логин: ".$login."<br/>
Пароль: ".$pass."<br/><br/>
С уважением, администрация топ-рейтинга http://boomtop.ru<br/>";
$headers = "From: ".$set['mail']." \n";
$headers .= "Content-Type: text/html; charset=utf-8\n";
mail($mail, $subject, $body, $headers);
unset($_SESSION["kod"]);
}
else{
echo '<div class="error">Ошибка при регистрации</div>';
echo $registr;
}
}
}
else echo $registr;
require_once ('foot.php');
?>