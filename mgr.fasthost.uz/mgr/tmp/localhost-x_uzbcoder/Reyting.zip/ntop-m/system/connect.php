<?
define("MYSQLHOST", "localhost");
define("DBNAME", "a67977b3_1");
define("DBUSER", "a67977b3_1");
define("DBPASS", "123456");
$connect = mysql_connect(MYSQLHOST,DBUSER,DBPASS);
if(!$connect) exit('Нет соединения с базой данных MYSQL. Попробуйте зайти позже!');
if(!mysql_select_db(DBNAME,$connect)) exit('Нет соединения с базой данных MYSQL. Попробуйте зайти позже!');
mysql_query('set character_set_results=utf8');
mysql_query('set character_set_client=utf8');
mysql_query('set character_set_connection=utf8');
mb_internal_encoding('UTF-8');
?>