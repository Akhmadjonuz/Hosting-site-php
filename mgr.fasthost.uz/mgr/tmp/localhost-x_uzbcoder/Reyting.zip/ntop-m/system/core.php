<?php
defined('MTOP') or die('Ошибка: Доступ ограничен');
$systema = mysql_query("SELECT * FROM `settings`");
$set = array();
while ($query = mysql_fetch_array($systema))
$set[$query[0]] = $query[1];
if(isset($_COOKIE['login']) AND isset($_COOKIE['password'])){
$user = mysql_query("SELECT * FROM `users` WHERE `login`='".mysql_real_escape_string(nl2br(htmlspecialchars(trim($_COOKIE['login']))))."' AND `password`='".mysql_real_escape_string(nl2br(htmlspecialchars(trim($_COOKIE['password']))))."'");
if(mysql_num_rows($user) > 0) $user_data = mysql_fetch_array($user);
}
$pages = $set['pages'];
$page_platforms = $set['page_platforms'];
$page_sait = $set['page_sait'];
$page_top = $set['page_top'];
$page_users = $set['page_users'];
$page_news = $set['page_news'];
if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) and preg_match('|^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$|',$_SERVER['HTTP_X_FORWARDED_FOR']))
$ip = trim(htmlspecialchars(mysql_real_escape_string($_SERVER['HTTP_X_FORWARDED_FOR'])));
elseif(isset($_SERVER['HTTP_CLIENT_IP']) and preg_match('|^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$|',$_SERVER['HTTP_CLIENT_IP']))
$ip = trim(htmlspecialchars(mysql_real_escape_string($_SERVER['HTTP_CLIENT_IP'])));
elseif(isset($_SERVER['REMOTE_ADDR']) and preg_match('|^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$|',$_SERVER['REMOTE_ADDR']))
$ip = trim(htmlspecialchars(mysql_real_escape_string($_SERVER['REMOTE_ADDR'])));
else $ip = 'Скрыт';
if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA']))
$ua = trim(htmlspecialchars(mysql_real_escape_string($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])));
elseif (isset($_SERVER['HTTP_USER_AGENT']))
$ua = trim(htmlspecialchars(mysql_real_escape_string($_SERVER['HTTP_USER_AGENT'])));
else $ua = 'Скрыт';
$ua=strtok($ua, '/');
$ua=strtok($ua, ' ');
if (mysql_num_rows(mysql_query("SELECT * FROM `online` WHERE `ip` = '".$ip."' AND `ua` = '".$ua."' AND `time` > '".(time()-180)."'")) == 1)
mysql_query("UPDATE `online` SET `time` = '".time()."' WHERE `ip` = '".$ip."' AND `ua` = '".$ua."' LIMIT 1");
else{
mysql_query("DELETE FROM `online` WHERE `time` < '".(time()-180)."'");
mysql_query("INSERT INTO `online` (`ip`, `ua`, `time`) values('".$ip."', '".$ua."', ".time().")");
}
$online = mysql_num_rows(mysql_query("SELECT * FROM `online` WHERE `time` > '".(time()-180)."'"));
$id = isset($_GET['id']) ? abs(intval($_GET['id'])) : '';
$act = isset($_GET['act']) ? htmlspecialchars(mysql_real_escape_string($_GET['act'])) : '';
?>