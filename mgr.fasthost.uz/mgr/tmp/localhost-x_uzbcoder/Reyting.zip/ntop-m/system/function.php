<?php
function unreg(){
global $user_data;
if($user_data){
header("Location: /404.php");
exit;
}
}

function reg(){
global $user_data;
if(!$user_data){
header("Location: /404.php");
exit;
}
}

function level($level){
global $user_data;
if($user_data AND $user_data['level'] < $level OR !$user_data){
header("Location: /404.php");
exit;
}
}

function data($time){
$month = array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
$month_rus = array('Янв','Фев','Мар','Апр','Мая','Июн','Июл','Авг','Сен','Окт','Ноя','Дек');
$timep = date("j M Y - H:i:s", $time);
$timep = str_replace($month,$month_rus,$timep);
return $timep;
}

function navigation($all,$napage,$page,$url,$total){
if(!($all<=$napage)){
if($page-3>0)$first='<u><a href="'.$url.'page=1">1</a></u> [...]';
if($page-2>0)$page2left='<span class="aut"><a href="'.$url.'page='.($page-2).'">'.($page-2).'</a></span>';
if($page-1>0)$page1left='<span class="aut"><a href="'.$url.'page='.($page-1).'">'.($page-1).'</a></span>';
if($page+3<=$total)$last=' <u><a href="'.$url.'page='.($total).'">'.($total).'</a></u>';
if($page+2<=$total)$page2right='<span class="aut"><a href="'.$url.'page='.($page+2).'">'.($page + 2).'</a></span>';
if($page+1<=$total)$page1right='<span class="aut"><a href="'.$url.'page='.($page+1).'">'.($page + 1).'</a></span>'; 
echo '<div class="fon"><center><b>'.$first.'</b></span>'.$page2left.$page1left.'<b><u>'.$page.'</b></u>'.$page1right.$page2right.$last.'</center></div>';
}
}


function filter($t){
$t = mysql_real_escape_string(nl2br(htmlspecialchars(trim($t))));
$t = str_replace("\'", "&#39;", $t);
$t = str_replace('\\', "&#92;", $t);
$t = str_replace("|", "I", $t);
$t = str_replace("||", "I", $t);
$t = str_replace("/\\\$/", "&#36;", $t);
return $t;
}

function browser(){
global $ua;
if (preg_match('/opera min/i', $ua)) $browser = 'Opera Mini';
else if (preg_match('/Chrome/i', $ua))$browser = 'Chrome';
else if (preg_match('/Opera/i', $ua)) $browser = 'Opera';
else if (preg_match('/MSIE/i', $ua)) $browser = 'IE';
else if (preg_match('/Mozilla/i', $ua)) $browser = 'Mozilla';
else if (preg_match('/ucweb/i', $ua)) $browser = 'UCWeb';
else $browser = 'Неизвестно';
return $browser;
}



function hornbeam($site){ 
$hornbeam = curl_init(); 
curl_setopt($hornbeam, CURLOPT_URL, $site); 
curl_setopt($hornbeam,CURLOPT_USERAGENT,'Opera mini 4.3'); 
curl_setopt($hornbeam, CURLOPT_REFERER, 'http://google.ru/'); 
curl_setopt($hornbeam, CURLOPT_RETURNTRANSFER,1); 
curl_setopt($hornbeam, CURLOPT_TIMEOUT, 60); 
$loading = curl_exec($hornbeam); 
curl_close($hornbeam); 
return $loading; 
}
 function getCI($url)
    {
     	$url = str_replace("http://", "", $url);
     	$url = str_replace("www.", "", $url);
     	$url = str_replace("wap.", "", $url);
     	$ci_url = "http://bar-navig.yandex.ru/u?ver=2&show=32&url=http://www.".$url."/";
     	$ci_data = implode("", file("$ci_url"));
     	preg_match("/value=\"(.\d*)\"/", $ci_data, $ci);
		if ($ci[1] == "")
      	return 0; // Если не смогли определить ТИЦ...
     	else
      	return $ci[1]; // Вот оно счастье...
    }
///////////////////PR

$googlehost='toolbarqueries.google.com';
$googleua='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.0.6) Gecko/20060728 Firefox/1.5';

function StrToNum($Str, $Check, $Magic) {
    $Int32Unit = 4294967296;
    $length = strlen($Str);
    for ($i = 0; $i < $length; $i++) {
        $Check *= $Magic;
        if ($Check >= $Int32Unit) {
            $Check = ($Check - $Int32Unit * (int) ($Check / $Int32Unit));
            $Check = ($Check < -2147483648) ? ($Check + $Int32Unit) : $Check;
        }
        $Check += ord($Str{$i});
    }
    return $Check;
}

function HashURL($String) {
    $Check1 = StrToNum($String, 0x1505, 0x21);
    $Check2 = StrToNum($String, 0, 0x1003F);

    $Check1 >>= 2;
    $Check1 = (($Check1 >> 4) & 0x3FFFFC0 ) | ($Check1 & 0x3F);
    $Check1 = (($Check1 >> 4) & 0x3FFC00 ) | ($Check1 & 0x3FF);
    $Check1 = (($Check1 >> 4) & 0x3C000 ) | ($Check1 & 0x3FFF);

    $T1 = (((($Check1 & 0x3C0) << 4) | ($Check1 & 0x3C)) <<2 ) | ($Check2 & 0xF0F );
    $T2 = (((($Check1 & 0xFFFFC000) << 4) | ($Check1 & 0x3C00)) << 0xA) | ($Check2 & 0xF0F0000 );

    return ($T1 | $T2);
}

function CheckHash($Hashnum) {
    $CheckByte = 0;
    $Flag = 0;

    $HashStr = sprintf('%u', $Hashnum) ;
    $length = strlen($HashStr);

    for ($i = $length-1; $i >= 0;  $i--) {
        $Re = $HashStr{$i};
        if (1 === ($Flag % 2)) {
            $Re += $Re;
            $Re = (int)($Re / 10) + ($Re % 10);
        }
        $CheckByte += $Re;
        $Flag ++;
    }

    $CheckByte %= 10;
    if (0 !== $CheckByte) {
        $CheckByte = 10 - $CheckByte;
        if (1 === ($Flag % 2) ) {
            if (1 === ($CheckByte % 2)) {
                $CheckByte += 9;
            }
            $CheckByte >>= 1;
        }
    }

    return '7'.$CheckByte.$HashStr;
}

function getch($url) { return CheckHash(HashURL($url)); }

function getpr($url) {
    global $googlehost,$googleua;
    $ch = getch($url);
    $fp = fsockopen($googlehost, 80, $errno, $errstr, 30);
    if ($fp) {
        $out = "GET /tbr?features=Rank&sourceid=navclient-ff&client=navclient-auto-ff&ch=$ch&q=info:$url HTTP/1.1\r\n";
        $out .= "User-Agent: $googleua\r\n";
        $out .= "Host: $googlehost\r\n";
        $out .= "Connection: Close\r\n\r\n";

        fwrite($fp, $out);
        while (!feof($fp)) {
            $data = fgets($fp, 128);
            $pos = strpos($data, "Rank_");
            if($pos === false){

			} else{
                $pr=substr($data, $pos + 9);
                $pr=trim($pr);
                $pr=str_replace("\n",'',$pr);
				if ($pr == "") {return 0;}
				else {
                return $pr;
				}
            }
         }
         fclose($fp);
     }
}
	


?>