<?php
define('MTOP', 1);
require_once ('connect.php');
require_once ('core.php');
require_once ('function.php');

$users = mysql_query("SELECT * FROM `users");

while($user = mysql_fetch_array($users)){
if($user['platforms_count'] == 0) mysql_query("UPDATE `users` SET `auto_del` = (`auto_del` + 1) WHERE `id` = '".$user['id']."'");
if($user['auto_del'] >= 45){
$subject = "Уведомление об удалении аккаунта";
$body = "Вы, ".$user["login"]."!<br/>
Уведомляем вас, что ваш аккаунт был удален в топе http://".$set["home"]."<br/>
Причина удаления: Отсутствие площадок в течении 45 дней<br/>
С уважением, администрация топ-рейтинга http://".$set["home"];
$headers = "From: ".$set['mail']." \n";
$headers .= "Content-Type: text/html; charset=utf-8\n";
mail($user['mail'], $subject, $body, $headers);
mysql_query("DELETE FROM `users` WHERE `id` = '".$user['id']."'");
}
}

$saits = mysql_query("SELECT * FROM `sait");
while($row = mysql_fetch_array($saits)){
if($row['ban'] == 1) mysql_query("UPDATE `sait` SET `auto_del` = (`auto_del` + 1) WHERE `id` = '".$row['id']."'");
if($row['auto_del'] >= 30){
$polzovatel = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$row['id_user']."'"));
$subject = "Уведомление об удалении площадки";
$body = "Вы, ".$polzovatel["login"]."!<br/>
Уведомляем вас, что ваш сайт http://".$row["url"]." был автоматически удален в топе http://".$set["home"]."<br/>
С уважением, администрация топ-рейтинга http://".$set["home"];
$headers = "From: ".$set['mail']." \n";
$headers .= "Content-Type: text/html; charset=utf-8\n";
mail($polzovatel['mail'], $subject, $body, $headers);
mysql_query("DELETE FROM `sait` WHERE `id` = '".$row['id']."'");
mysql_query("UPDATE `users` SET `platforms_count` = (`platforms_count` - 1) WHERE `id` = '".$row['id_user']."'");
}
if($row['ban'] == 0){
if($row['hosts'] == 0) mysql_query("UPDATE `sait` SET `auto_ban` = (`auto_ban` + 1) WHERE `id` = '".$row['id']."'");
if($row['auto_ban'] == 29){
$polzovatel = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$row['id_user']."'"));
$subject = "Уведомление о скорой блокировке площадки";
$body = "Вы, ".$polzovatel["login"]."!<br/>
Уведомляем вас, что ваш сайт http://".$row["url"]." завтра будет автоматически заблокирован в топе http://".$set["home"]."<br/>
Причина блокировки: Нулевая посещаемость в течении 29 дней<br/>
Возможно у вас не установлен код счетчика или ваш сайт недоступен<br/>
Просим вас установить счетчик на своем сайте/вернуть работоспособность своему сайту<br/>
С уважением, администрация топ-рейтинга http://".$set["home"];
$headers = "From: ".$set['mail']." \n";
$headers .= "Content-Type: text/html; charset=utf-8\n";
mail($polzovatel['mail'], $subject, $body, $headers);
}
if($row['auto_ban'] >= 30){
mysql_query("UPDATE `sait` SET `ban` = '1', `ban_time` = '".time()."', `ban_reason` = 'Нулевая посещаемость в течении 30 дней', `auto_ban` = '0' WHERE `id` = '".$row['id']."'");
$polzovatel = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$row['id_user']."'"));
$subject = "Уведомление о блокировки площадки";
$body = "Вы, ".$polzovatel["login"]."!<br/>
Уведомляем вас, что ваш сайт http://".$row["url"]." был автоматически заблокирован в топе http://".$set["home"]."<br/>
Причина блокировки: Нулевая посещаемость в течении 30 дней<br/>
Возможно у вас не установлен код счетчика или ваш сайт недоступен<br/>
С уважением, администрация топ-рейтинга http://".$set["home"];
$headers = "From: ".$set['mail']." \n";
$headers .= "Content-Type: text/html; charset=utf-8\n";
mail($polzovatel['mail'], $subject, $body, $headers);
}
if($row['auto_ban'] != 0 AND $row['hosts'] > 0)
mysql_query("UPDATE `sait` SET `auto_ban` = '0' WHERE `id` = '".$row['id']."'");
}


mysql_query("UPDATE `sait` SET `pk30` = (`pk30` + ".$row['pk2']."), `mob30` = (`mob30` + ".$row['mob2']."), `hosts30` = (`hosts30` + ".$row['hosts2']."), `hits30` = (`hits30` + ".$row['hits2']."), `in30` = (`in30` + ".$row['in2']."), `out30` = (`out30` + ".$row['out2'].") WHERE `id` = '".$row['id']."'");

mysql_query("UPDATE `sait` SET `pk2` = '".$row['pk']."', `mob2` = '".$row['mob']."', `hosts2` = '".$row['hosts']."', `hits2` = '".$row['hits']."', `in2` = '".$row['in']."', `out2` = '".$row['out']."' WHERE `id` = '".$row['id']."'");

}

mysql_query("UPDATE `sait` SET `hosts` = '0', `hits` = '0', `in` = '0', `out` = '0', `mob` = '0', `pk` = '0'");
mysql_query("TRUNCATE TABLE `online`");
mysql_query("TRUNCATE TABLE `sait_online`");
mysql_query("OPTIMIZE TABLE  `online`");
mysql_query("OPTIMIZE TABLE  `sait_online`");
mysql_query("OPTIMIZE TABLE  `cat`");
mysql_query("OPTIMIZE TABLE  `go`");
mysql_query("TRUNCATE hits");
mysql_query("TRUNCATE hosts");
mysql_query("TRUNCATE in");
mysql_query("TRUNCATE out");
mysql_query("OPTIMIZE TABLE  `images`");
mysql_query("OPTIMIZE TABLE  `ip`");
mysql_query("OPTIMIZE TABLE  `ip_name`");
mysql_query("OPTIMIZE TABLE  `sait`");
mysql_query("OPTIMIZE TABLE  `settings`");
mysql_query("OPTIMIZE TABLE  `users`");
?>