<?php
ob_start();
define('MTOP', 1);
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
reg();
$mod = isset($_GET['mod']) ? (string)$_GET['mod'] : '';
switch($act){
default:
$title = 'Мой кабинет';
require_once ('head.php');
$platforms = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user_data['id']."'"));
if($user_data['level'] == 3) {
echo '<div class="why"><div class="lt"><b><a href="/adm/">Админка</a></b></div></div>';
}
echo '<div class="why"><div class="lt"><b><a href="/m/office/addPlatform">Добавить сайт</a></b><br/>';
echo '<a href="/m/office/platforms">Мои площадки</a> <font color="##228B22">('.$platforms.' из '.$set['max_platforms'].')</font><br/>';
echo '<a href="/exit"> Выйти из кабинета</a></div></div>';
break;
case 'platforms':
$title = 'Площадки';
require_once ('head.php');
$platforms = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user_data['id']."'"));
echo '<div class="why"><div class="lt"><small>Всего площадок:  '.$platforms.' из '.$set['max_platforms'].'</small></div></div>';
$platform = mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user_data['id']."'");
$platforms = mysql_num_rows($platform);
if($platforms == 0){
echo '<div class="main"><center>У вас нет площадок</center></div>';
}
else{
$total=intval(($platforms-1)/$page_platforms)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($platforms/$page_platforms);
$start=$page*$page_platforms-$page_platforms;
$platform = mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user_data['id']."' ORDER BY `id` DESC LIMIT ".$start.",".$page_platforms."");
while($row = mysql_fetch_array($platform))
{
$status = $row['status'] == 1 ? '<font color="green">Проверена</font>' : '<font color="red">На проверке</font>';
$start++;
echo '<div class="main"><a href="/out/'.$row['id'].'"><strong>'.$row['url'].'</strong></a> [ID: '.$row['id'].' | '.$status.'] <a href="/stats/'.$row['id'].'"> (STATA)</a> <br/> '.$row['about'].'!<br/><a href="/m/office/editPlatform/'.$row['id'].'">Ред</a> |
<a href="/m/office/code/'.$row['id'].'"> Счетчик</a></div>';
}

navigation($platforms,$page_platforms,$page,'m/office/platforms?sort='.$sort.'&',$total);
}
break;
case 'add_platform':
$title = 'Мой кабинет';
require_once ('head.php');
$platform = mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user_data['id']."'");
$platforms = mysql_num_rows($platform);
if($platforms >= $set['max_platforms']){
echo '<div class="main"><center>Достигнут лимит площадок</center></div>';
}
else{

$dobavsait .= '<form action="" method="post"><div class="why"><div class="lt">
URL сайта (без http:// и т.п) [max. 35]:<br/>
<input type="text"  class="input" name="url" maxlength="35" value="" /><br/>
Описание сайта [max. 80]:<br/>
<textarea name="about" cols="38" rows="8" maxlength="80"></textarea></br>
Категория:<br/>
<select name="cat">';
$cats = mysql_query("SELECT * FROM `cat` ORDER BY `id` ASC");
if(mysql_num_rows($cats) > 0) while($cat = mysql_fetch_assoc($cats)) $dobavsait .= '<option value="'.$cat['id'].'">'.$cat['name'].'</option>';
$dobavsait .= '</select><br />
<b>Для главной страницы сайта: *</b><br/>
<input type="radio" name="image" checked="checked" value="1"> <img src="/images/big/1.png" alt=""><br/>
<input type="radio" name="image" value="2"> <img src="/images/big/2.png" alt=""><br/>
<input type="radio" name="image" value="3"> <img src="/images/big/3.png" alt=""><br/>
<input type="radio" name="image" value="4"> <img src="/images/big/4.png" alt=""><br/>
<input type="radio" name="image" value="5"> <img src="/images/big/5.png" alt=""><br/>
<input type="radio" name="image" value="6"> <img src="/images/big/6.png" alt=""><br/>
<input type="radio" name="image" value="7"> <img src="/images/big/7.png" alt=""><br/>
<input type="radio" name="image" value="8"> <img src="/images/big/8.png" alt=""><br/>
<input type="radio" name="image" value="9"> <img src="/images/big/9.png" alt=""><br/>
<hr />
<b>Для остальных страниц сайта: *</b><br/>
<input type="radio" name="image_s" checked="checked" value="1"> <img src="/images/small/1.png" alt=""><br/>
<input type="radio" name="image_s" value="2"> <img src="/images/small/2.png" alt=""><br/>
<input type="radio" name="image_s" value="3"> <img src="/images/small/3.png" alt=""><br/>
<input type="radio" name="image_s" value="4"> <img src="/images/small/4.png" alt=""><br/>
<input type="radio" name="image_s" value="5"> <img src="/images/small/5.png" alt=""><br/>
<input type="radio" name="image_s" value="6"> <img src="/images/small/6.png" alt=""><br/>
<input type="radio" name="image_s" value="7"> <img src="/images/small/7.png" alt=""><br/>
<input type="radio" name="image_s" value="8"> <img src="/images/small/8.png" alt=""><br/>
<input type="radio" name="image_s" value="9"> <img src="/images/small/9.png" alt=""><br/>
<br />
<br /><input name="skrit" type="checkbox" value="1"> Скрыть статистику<br /></br>
* - Все поля обязательные к заполнению<br /><br />
<input name="ok" type="submit" value="Добавить"/></form><br />
* - Все поля обязательные к заполнению.<br />
** - Описание сайта должно быть адекватное, иначе модерация будет отклонена!</div>';
if(!isset($_POST['ok'])) echo $dobavsait;
else{
$platform = mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user_data['id']."'");
$platforms_count = mysql_num_rows($platform);
$url = filter($_POST['url']);
$url = str_replace("http://","",$url);
$url = str_replace("https://","",$url);
$about = filter($_POST['about']);
$cat = intval($_POST['cat']);
$skrit =(isset($_POST['skrit']))? 1 : 0;
$image = filter($_POST['image']);
$image_s = filter($_POST['image_s']);
$error = '';
$isset_cat = mysql_num_rows(mysql_query("SELECT `id` FROM `cat` WHERE `id` = '".$cat."'"));
if(empty($url)  OR empty($about) OR empty($cat) OR empty($image) OR empty($image_s)) $error .= '<div class="main">Незаполнено одно или несколько полей</div>';
else{
if($image < 1 OR $image > 9) $error .= '<div class="main">Нет такого счетчика</div>';
if($image_s < 1 OR $image_s > 9) $error .= '<div class="main">Нет такого счетчика</div>';
if($isset_cat == 0)
$error .= '<div class="main">Нет такой категории</div>';
if(mb_strlen($about) > 80 OR mb_strlen($about) < 5)
$error .= '<div class="main">Длина описания должна быть не короче 50 и не длиннее 80 символов</div>';
if(mb_strlen($url) > 35 OR mb_strlen($url) < 3)
$error .= '<div class="main">Длина адреса должна быть не короче 3 и не длиннее 35 символов</div>';
if (mysql_num_rows(mysql_query("SELECT * FROM `".$prefix."sait` WHERE `url` = '".$url."' LIMIT 1")) != 0)
$error .= '<div class="main">Такой сайт уже есть в базе</div>';
}
if(!empty($error)){
echo $error;
echo $dobavsait;
}
else{
$insert_platform = mysql_query("INSERT INTO `sait` SET `id_user` = '".$user_data['id']."',  `about` = '".$about."', `skrit` = '".$skrit."', `category` = '".$cat."', `url` = '".$url."', `image` = '".$image."', `image_s` = '".$image_s."',`status` = '".$set['moderacia']."', `time_reg` = '".time()."'");
if($insert_platform){
$plosh = mysql_fetch_array(mysql_query("SELECT * FROM `sait` WHERE `url` = '".$url."'"));
echo '<div class="main"><b><font color="green">Сайт успешно добавлен и отправлен на проверку.</font></b><br />
Пожалуйста, установите счётчик!<br />
Модерация длится от 5 минут до 12 часов.<br />
<a href="/m/office/platforms">К площадкам</a></div>';
}
else{
echo '<div class="main">Площадка не добавлена</div>';
echo $dobavsait;
}
}
}
}
break;
case 'edit_platform':
$title = 'Редактирование площадки';
require_once ('head.php');

$platform = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."' AND `id_user` = '".$user_data['id']."' LIMIT 1");
$platform_count = mysql_num_rows($platform);
$user_platform = mysql_fetch_array($platform);
$redsait .= '
<form action="" method="post"><div class="why"><div class="lt">
Описание сайта [max. 80]:<br/>
<textarea name="about" cols="38" rows="8" maxlength="80">'.$user_platform['about'].'</textarea><br/>
Категория:<br/>
<select name="cat">';
$cats = mysql_query("SELECT * FROM `cat` ORDER BY `id` ASC");
if(mysql_num_rows($cats) > 0){
while($cat = mysql_fetch_assoc($cats)){
$selected = ($user_platform['category'] == $cat['id']) ? ' selected="selected"' : '';
$redsait .= '<option value="'.$cat['id'].'"'.$selected.'>'.$cat['name'].'</option>';
}
$redsait .= '</select><br /><br />';
$redsait .= '<b>Для главной страницы сайта: *</b><br/>';
$redsait .= '';
for ($big=0; $big++<9;){
if ($user_platform['image'] == $big)
$redsait .= '<input type="radio" name="image" value="'.$big.'" checked="checked"> <img src="/images/big/'.$big.'.png" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="'.$big.'"> <img src="/images/big/'.$big.'.png" alt=""><br/>';
}
$redsait .= '<hr /><b>Для остальных страниц сайта: *</b><br/>';
for ($small=0; $small++<9;){
if ($user_platform['image_s'] == $small)
$redsait .= '<input type="radio" name="image_s" value="'.$small.'" checked="checked"> <img src="/images/small/'.$small.'.png" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="'.$small.'"> <img src="/images/small/'.$small.'.png" alt=""><br/>';
}
if($user_platform['skrit'] == 1) $cheked = 'checked="checked"';
$redsait .= '<br/><br /><input name="skrit" type="checkbox" '.$cheked.' value="'.$user_platform['skrit'].'"> Скрыть статистику<br /></br> * - Все поля обязательные к заполнению<br /><br />
<input name="ok" type="submit" value="Изменить" /></div></form>';
}
else{
$redsait .= '<div class="error">Данной площадки не существует</div>';
$redsait .= '';
}

if(!isset($_POST['ok'])) echo $redsait;
else{
$cat = intval($_POST['cat']);
$image = filter($_POST['image']);
$image_s = filter($_POST['image_s']);
$skrit =(isset($_POST['skrit']))? 1 : 0;
$about = filter($_POST['about']);
$platform_isset = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."' AND `id_user` = '".$user_data['id']."' LIMIT 1"));
$error = '';
$isset_cat = mysql_num_rows(mysql_query("SELECT `id` FROM `cat` WHERE `id` = '".$cat."'"));
if(empty($cat) OR empty($image) OR empty($image_s) OR empty($about))
$error .= '<div class="error">Не заполнено одно или несколько полей</div>';
else{
if($image < 1 OR $image > 9) $error .= '<div class="error">Нет такого счетчика</div>';
if($image_s < 1 OR $image_s > 9) $error .= '<div class="error">Нет такого счетчика</div>';
if($isset_cat == 0)
$error .= '<div class="error">Нет такой категории</div>';
if($platform_isset == 0)
$error .= '<div class="error">У вас нет такой площадки</div>';
if(mb_strlen($about) > 80 OR mb_strlen($about) < 5)
$error .= '<div class="error">Длина описания должна быть не короче 5 и не длиннее 80символов</div>';
}
if(!empty($error)){
echo $error;
echo $redsait;
}
else{
$update_platform = mysql_query("UPDATE `sait` SET `category` = '".$cat."', `image` = '".$image."', `image_s` = '".$image_s."', `skrit` = '".$skrit."', `status` = '0', `about` = '".$about."' WHERE `id` = '".$id."'");
if($update_platform){
echo '<div class="main"><br/>Сайт успешно отредактирован и отправлен на модерацию<br />
На время проверки, ваш сайт не будет отображаться в топе!<br /></div>';
}
else {
echo '<div class="error">Площадка не отредактирована потому что yamus так захотел</div>';
echo $redsait;
}
}
}
break;
case 'code':
$title = 'Код счетчика';
require_once ('head.php');
if($id == null) $idplosh = 'ID_ПЛОЩАДКИ'; else $idplosh = $id;

echo '<div class="main"><br />Код счётчика для главной страницы [ID площадки: '.$idplosh.']:
<br /><strong>&lt;a href="'.$set['home'].'/go/'.$idplosh.'">&lt;img src="http://'.$set['home'].'/image/'.$idplosh.'" alt="*" />&lt;/a><br/></strong>
<hr />
Код счётчика для остальных страниц [ID площадки: '.$idplosh.']:<br />
<strong>&lt;a href="http://'.$set['home'].'/go/'.$idplosh.'">&lt;img src="http://'.$set['home'].'/imageOther/'.$idplosh.'" alt="*" />&lt;/a><br/></strong>';
echo '</div>';
break;
}
require_once ('foot.php');
?>