<?
$plaforms_all = mysql_num_rows(mysql_query("SELECT * FROM `sait`"));
$plaforms_akt = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `status` = '1' AND `ban` = '0' AND `hosts` > '0'"));
if ($_SERVER['PHP_SELF']!='/index.php')
{
}
echo '<div class="footer">Сайтов с нами<br/>
<font size="3px"><b>'.$plaforms_all.'</b></font><br/>
<br/>Активных сегодня<br/>
<font size="3px"><b>'.$plaforms_akt.'</b></font><br/>
<br/>'.$set['home'].' - статистика и аналитика вашего сайта. Анализ сайта, определение статистики, диаграммы liveinternet и многое другое<br/>
<br/><b><a href="#">Copyright by 2018 '.$set['home'].'</a></b><center>
<div style="padding: 22px 0 0 0;"><a href="https://vk.com/id492815571">
<img src="/style/img/vk.png" alt="*"></a>&nbsp; 
<img src="/style/img/tv.png" alt="*">&nbsp; <img src="/style/img/fa.png" alt="*">
<br><br><a href="http://a67977b3.beget.tech/go/1"><img src="http://a67977b3.beget.tech/image/1" alt="*" /></a>
</div></center></div></center></div>';
echo '</body></html>';
?>