<?php
include 'connect.php';
$t = time();
$sql=mysql_query('SELECT `url`,`name`,`color`,`bold`,`italic`,`type`,`open` FROM `rekl` WHERE `time` > '.$t.' and `type` = 1 and `open` = 1 ORDER BY RAND() LIMIT 5');

if(mysql_num_rows($sql)>0)
echo'<div class="why"><br><div class="lt"><b>Рекламные ссылки:</b><br> '; 
{

while($a=mysql_fetch_assoc($sql)){
echo'<a '.(($a['color'] || $a['bold'] || $a['italic']) ? 'style="'.($a['bold']?'font-weight:bold;':'').($a['italic']?'font-style:italic;':'').($a['color']?'color:'.$a['color']:'').'" ' : '' ).'href="'.$a['url'].'" >'.$a['name'].'</a> | ';
}
}
echo'</div></div>'; 
?>