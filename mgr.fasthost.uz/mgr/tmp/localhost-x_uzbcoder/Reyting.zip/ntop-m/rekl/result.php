<?php
require_once 'connect.php';
include_once 'config.php';

$id = intval($_POST['idd']);
$uu = mysql_fetch_assoc(mysql_query("SELECT * FROM `rekl` WHERE `id` = '".$id."'"));

if (isset($_POST['LMI_PREREQUEST'])){

if(!$uu)$err = 'Нет такого платежа';

if (isset($err))
{
echo $_POST['LMI_HASH'];
exit;
}

echo 'YES';
exit;
}



mysql_unbuffered_query("UPDATE `rekl` SET `open` = '1' WHERE `id` = ".$id." ");
exit();


?>