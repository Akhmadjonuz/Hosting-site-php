<?php
define('MTOP', 1);
$title = 'Купить рекламу';
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
require_once 'config.php';
require_once('../head.php');

if(isset($_POST['submit']))

{
$url=mysql_real_escape_string(htmlspecialchars($_POST['url']));
$name=mysql_real_escape_string(htmlspecialchars($_POST['name']));
$ilu=mb_strlen($url);
$iln=mb_strlen($name);
$days=abs(intval($_POST['days']));
$type=abs(intval($_POST['type']));

if($type == '0'){ $с_day = $с_day; $type2 = 'Сверху'; }
if($type == '1'){ $с_day = $с_day_n; $type2 = 'Снизу'; }


if($days >= 7){ $summa=($с_day*$days)*2/100; $tt = '2'; }
if($days >= 30){ $summa=($с_day*$days)*8/100; $tt = '8'; }
if($days >= 180){ $summa=($с_day*$days)*15/100; $tt = '15'; }
if($days >= 365){ $summa=($с_day*$days)*35/100; $tt = '35'; }


$day = time()+(86400*$days);
if(empty($_POST['url']) || empty($_POST['name']) || empty($_POST['days'])){$error = 'Не заполнено одно из полей';}
if($ilu<2 || $ilu>50){$error = 'Предельная длина URL 2-50';}
if($iln<5 || $iln>50){$error = 'Предельная длина названия 3-50';}
if($type != '0' && $type != '1'){$error = 'Выберите тип рекламы';}
if($days<0 || $days>$max_day){$error = 'Предельное количество дней 1-'.$max_day.'</div>';}

if(!empty($_POST['color'])){
$color=mysql_real_escape_string(htmlspecialchars($_POST['color']));
}

$skidka = $summa;
$summa2 = $с_day*$days+$с_color+$с_bold;
$summa = $summa2-$skidka;

if(empty($_POST['bold'])){$b='0';
}else{
$b='1';
}
if(empty($_POST['italic'])){$k='1';
}else{
$k='0';
}

$num = mysql_num_rows(mysql_query("SELECT `id` FROM `rekl`"));
if(empty($error)){

$time = time()+(86400*$days);
mysql_unbuffered_query("INSERT INTO `rekl` SET `summa` = ".$summa.", `date` = ".time().", `time` = ".$time.",`url` = '".$url."', `name` = '".$name."',`color` = '".$color."',`bold` = ".$b.",`italic` = ".$k.",`type` = ".$type." ");
$idd = mysql_insert_id();
echo '<div class="why"><div class="lt"><form id=pay name=pay method="POST" action="https://merchant.webmoney.ru/lmi/payment.asp"> 
<p>Вы собираетесь оплатить рекламу на сайте <b>'.$_SERVER['HTTP_HOST'].'</b></br>';
echo 'URL: '.$url.'</br>';
echo 'Название: '.$name.'</br>';
echo 'Цвет: '.$color.'</br>';
echo 'Кол-во дней '.$days.' дн.</br>';
echo 'Тип: '.$type2.'</br></br>';

echo 'Процент скидки '.$tt.'%</br>';
echo 'Стоимость скидки '.$skidka.' руб.</br>';
echo 'Полная цена без скидки '.$summa2.' руб.</br>';
echo 'Цена оплаты '.$summa.' руб.</br>';

echo '
<p>
<input name="url" type="hidden" value="'.$url.'"/>
<input name="summa" type="hidden" value="'.$summa.'"/>
<input name="color" type="hidden" value="'.$color.'"/>
<input name="name" type="hidden" value="'.$name.'"/>
<input name="days" type="hidden" size="5" value="'.$days.'"/>
<input name="day" type="hidden" size="5" value="'.$day.'"/>
<input name="bold" type="hidden" value="'.$b.'"/>
<input name="italic" type="hidden" value="'.$i.'"/>
<input name="idd" type="hidden" value="'.$idd.'"/>
<input type="hidden" name="LMI_PAYMENT_AMOUNT" value="'.$summa.'">
<input type="hidden" name="LMI_PAYMENT_DESC" value="'.$_SERVER['HTTP_HOST'].'">
<input type="hidden" name="LMI_PAYMENT_NO" value="'.($num+1).'">
<input type="hidden" name="LMI_PAYEE_PURSE" value="'.$wmr.'">
</p> 
<p>
 <input type="submit" value="Оплата">
 </p> 
</form> </div></div>';
		

require_once('../foot.php');
exit;
}}

if($error){
echo'<div class="main"><br> '.$error.' </div>';
}elseif(isset($_GET['success'])){
echo'<div class="main"><br> Реклама успешно куплена </div>';
}elseif(isset($_GET['error'])){
echo'<div class="main"><br> Произошла ошибка при покупке</div>';
}

echo'<div class="why"><div class="lt"><b>Покупка рекламы </b><br>
<form action="index.php" method="post">
<b>Ссылка [2 - 30] (http://site.ru)</b>:<br/><input name="url" type="text" maxlength="50" value="http://"/><br/>
<b>Название [5 - 50]</b><br/><input name="name" type="text" maxlength="50"/><br/>
<b>Длительность рекламы </b>:<br/><input name="days" type="text" maxlength="5" size="5" value="7"/><br/>

Тип рекламы:<br/>
<select name="type">';
echo'<option value="0">Верх главной ('.$с_day.'руб/сутки)</option>';
echo'<option value="1">Низ главной ('.$с_day_n.'руб/сутки)</option>';
echo'</select></br>

<b>Цвет ссылки (+ '.$с_color.'руб.)</b>:<br/>
<select name="color">';
echo'<option value="none">Без цвета</option>';
foreach($alc as $slc=>$slv){
echo'<option value="'.$slc.'">'.$slv.'</option>';
}
echo'</select><br/>
<input name="bold" type="checkbox" value="1"/> <b>Жирность  (+ '.$с_bold.'руб.)</b> <br/>
<input type="submit" name="submit" value="Купить"/></form>';
echo '</div></div>';
require_once('../foot.php');
?>