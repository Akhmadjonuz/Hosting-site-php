<?php
$con=array(
'user'=>'a67977b3_1',
'pass'=>'123456',
'base'=>'a67977b3_1',
'host'=>'localhost'
);

$connect = mysql_connect($con['host'],$con['user'],$con['pass']);
if(!$connect)
	{
		exit('Нет подключения к базе данных MYSQL');
	}
if(!mysql_select_db($con['base'],$connect))
	{
		exit('Не найдена база данных. Попробуйте зайти позже');
	}
mysql_query('set character_set_results=utf8');
mysql_query('set character_set_client=utf8');
mysql_query('set character_set_connection=utf8');
mb_internal_encoding('UTF-8');
?>