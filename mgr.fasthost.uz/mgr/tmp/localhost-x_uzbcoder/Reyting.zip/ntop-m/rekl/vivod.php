<?php
include 'connect.php';
$t = time();
$sql=mysql_query('SELECT `url`,`name`,`color`,`bold`,`italic`,`type`,`open` FROM `rekl` WHERE `time` > '.$t.' and `type` = 0 and `open` = 1 ORDER BY RAND() LIMIT 5');
echo  '<ul class="hr"><li>';
if(mysql_num_rows($sql)>0){
while($a=mysql_fetch_assoc($sql)){
echo'<a '.(($a['color'] || $a['bold'] || $a['italic']) ? 'style="'.($a['bold']?'font-weight:bold;':'').($a['italic']?'font-style:italic;':'').($a['color']?'color:'.$a['color']:'').'" ' : '' ).'href="'.$a['url'].'">
'.$a['name'].'</a></br>';
}
}
echo'<a href="/rekl"><font - color="#6e6e6e"><b>Купить рекламу</b> </a></font><ul class="c"><a>★★★</a></ul></ul>';
?>