<?php
define('MTOP', 1);
$title = 'Переадрисация';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
$id = abs(intval($_GET['id']));
if(!$id OR $id < 1)
	{
		exit('Не верно введен ID');
	}
$isset = mysql_query("SELECT * FROM `".$prefix."sait` WHERE `status` != '0' AND `id` = '".$id."'");
if(mysql_num_rows($isset) == 0)
	{
		exit('Нет такого сайта!');
	}
$sait = mysql_fetch_array($isset);
		mysql_query("INSERT INTO `".$prefix."go` SET `id_sait` = '".$id."', `type` = 'out',`time` = '".time()."'");
		mysql_query("UPDATE `".$prefix."sait` SET `out` = (`out` + 1), `all_out` = (`all_out` + 1) WHERE `id` = '".$id."'");
echo '<meta http-equiv="refresh" content="3; url=http://'.$sait['url'].'"/>';
echo '<div class="why"><div class="lt"><font color="red"><b>Внимание! </b></font><br>Администрация '.$set['home'].' не несет ответственности за содержимое сайта 
<a href = "http://'.$sait['url'].'">'.$sait['url'].'</a></b></br>Вы будете перенаправленны через несколько секунд. Удачного просмотра :)</div></div>';		
require_once ('foot.php');		
?>
