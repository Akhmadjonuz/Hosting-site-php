<?php
define('MTOP', 1);
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
switch($act){
default:
$title = 'Категории';
require_once ('head.php');
$cats = mysql_query("SELECT * FROM `cat` ORDER BY `position`");
while($cat = mysql_fetch_array($cats)){
$count_sites = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `category` = '".$cat['id']."' AND `status` = '1' AND `ban` = '0' AND `hosts` > '0'"));
if($cat['id'] != 4) {
echo '<div class="why"><div class="lt"><ul class="cn">'.$count_sites.'</ul>
<a href = "/m/category/view/'.$cat['id'].'">'.$cat['name'].'</a> <br> '.$cat['about'].'</div></div>';
}
}
break;
case 'view':
$isset = mysql_query("SELECT * FROM `cat` WHERE `id` = '".$id."'");
if(mysql_num_rows($isset) > 0){
$catt = mysql_fetch_array($isset);
$title = 'Категории';
require_once ('head.php');
$count = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `category` = '".$id."' AND `status` = '1'AND `ban` = '0' AND `hosts` > '0'"));

if($count > 0){
$total=intval(($count-1)/$page_sait)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($count/$page_sait);
$start=$page*$page_sait-$page_sait;
$saits = mysql_query("SELECT * FROM `sait` WHERE `category` = '".$id."' AND `status` = '1' AND `ban` = '0' AND `hosts` > '0' ORDER BY `hosts` DESC LIMIT ".$start.",".$page_sait."");

while($row = mysql_fetch_array($saits)){
$start++;
if($row['id'] == $_GET['id_site']) {
$red = '<font color="red">'.$row['url'].'</font>';
} else {
$red = $row['url'];
}
echo '</div><div class="why"><div class="lt"><div class="cn">
'.$start.'</div><a href="/out.php?id='.$row['id'].'" title="Переход на сайт '.$row['url'].'">'.$red.'</a><ul class="cnt"><b><small>['.$row['hosts'].'/'.$row['hits'].' ]</small></b>
</b></ul><div class="c">
<a href="/stats/'.$row['id'].'"><br><img src="/graphic/mini/'.$row['id'].'.png"></a></div>
<br/><small>'.$row['about'].'</small><br/></font></b></font></div></div>';
if(mb_strlen($row['about']) > 150){
$text = mb_substr($row['about'], 0, 150, 'utf-8');
echo ''.$text.'..';
}
else
{
}
}
navigation($count,$page_sait,$page,'/cat.php?act=view&id='.$id.'&sort='.$sort.'&',$total);
}
else{
echo '<div class="main"><br/>Сайтов в данной категории нет!<br/><a href="m/category">К списку категорий</a><br/></div>';
}
}
else{
$title = 'Ошибка';
require_once ('head.php');
echo '<div class="title3">Ошибка</div>';
echo '<div class="title"><center>Данной категории не существует</center></div>';
}
break;
}
require_once ('foot.php');
?>