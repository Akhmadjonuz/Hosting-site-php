<?php
define('MTOP', 1);
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
include $_SERVER['DOCUMENT_ROOT'].'/rekl/vivod.php';
$page_top = $set['page_top'];
$all = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `status` = '1' AND `ban` = '0' AND `hosts` > '0'"));
if($all != 0){
$total=intval(($all-1)/$page_top)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($all/$page_top);
$start=$page*$page_top-$page_top;
$top = mysql_query("SELECT * FROM `sait` WHERE `status` = '1' AND `ban` = '0' AND `hosts` > '0' ORDER BY `hosts` DESC LIMIT ".$start.",".$page_top."");

while($row = mysql_fetch_array($top)){
    $category = mysql_fetch_array(mysql_query("SELECT * FROM `cat` WHERE `id` = '".$row['category']."'"));
    if($row['hosts']<$row['hosts2']){
        $value = $row['hosts2']-$row['hosts'];
        $active_hosts = '<font color="red">-'.$value.'</font>';
    }elseif($row['hosts']>$row['hosts2']){
        $value = $row['hosts']-$row['hosts2'];
        $active_hosts = '<font color="green">+'.$value.'</font>';
    }
if($row['category'] != 4 AND $row['category'] != 8 AND $row['category'] != 15) {
$start++;
if($row['id'] == $_GET['id_site']) {
$red = '';
} else {
$red = $row['url'];
}

echo '	</div>
<div class="why"><div class="lt"><div class="cn">'.$start.'</div>
<a href="/out.php?id='.$row['id'].'" title="Переход на сайт '.$row['url'].'">'.$red.'</a> '.$active_hosts.'<div class="cnt"><b><small>['.$row['hosts'].'/'.$row['hits'].' ]</small></b>
</b></div> <div class="c"><a href="/stats/'.$row['id'].'"><br><img src="/graphic/mini/'.$row['id'].'.png"></a></div>
<br/><small>'.$row['about'].'</small><br/></font></b>Категория: <a href="/m/category/view/'.$row['category'].'">'.$category['name'].'</a></font></div></div>';

if(mb_strlen($row['about']) > 65){
$text = mb_substr($row['about'], 0, 65, 'utf-8');
echo ''.$text.'..';
}
else
{

}
}
}
include $_SERVER['DOCUMENT_ROOT'].'/rekl/vivod2.php';	
navigation($all,$page_top,$page,'index.php?sort='.$sort.'&',$total);
}
else
{
echo '<div class="main">Сайтов в TOP-100 не обнаружено!</div>';
}
	
require_once ('foot.php');
?>