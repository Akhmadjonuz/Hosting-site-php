<?php
define('MTOP', 1);
$title = 'Переадрисация';
require_once ('system/connect.php');
require_once ('system/core.php');
require_once ('system/function.php');
require_once ('head.php');
if(!$id OR $id < 1){
echo '<div class="why"><div class="lt">Не верно введен ID.</div></div>';
require_once ('foot.php');
exit;
}
$isset = mysql_query("SELECT * FROM `sait` WHERE `status` != '0' AND `id` = '".$id."'");
if(mysql_num_rows($isset) == 0){
echo '<div class="why"><div class="lt">Данного сайт нет , либо он не активирован.</div></div>';
require_once ('foot.php');
exit;
}
$sait = mysql_fetch_array($isset);
$nakrut = mysql_query("SELECT * FROM `out` WHERE `id_sait` = '".$id."' AND `ip` = '".$ip."'");
if (mysql_num_rows($nakrut) == 0){
mysql_query("INSERT INTO `out` (`id_sait`,`ip`) values('".$id."','".$ip."')");
mysql_query("UPDATE `sait` SET `out` = (`out` + 1), `all_out` = (`all_out` + 1) WHERE `id` = '".$id."'");
}
echo '<meta http-equiv="refresh" content="3; url=http://'.$_SERVER['HTTP_HOST'].'/stats/'.$id.'"/>';
echo '<div class="why"><div class="lt">Выполняется переход на <a href="http://'.$_SERVER['HTTP_HOST'].'/stats/'.$id.'"><b>страницу статистики</b> </a>
сайта '.$sait['url'].'. <br><br><small>Страница сгенерированна автоматически. <br>Powered by '.$set['home'].' </small></div></div>';
require_once ('foot.php');	
?>