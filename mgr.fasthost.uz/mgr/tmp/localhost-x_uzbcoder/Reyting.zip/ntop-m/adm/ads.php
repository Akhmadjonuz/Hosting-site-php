<?php
define('MTOP', 1);
$title = 'Админ панель';
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
require_once('../head.php');
$item = isset($_GET['item']) ? (string) $_GET['item'] : 'index';
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

switch($item)
{
default:

$rek = mysql_query("SELECT * FROM `rekl` WHERE `open` = '1'");

echo '<a href="ads.php?item=add">Добавить рекламу</a></br></br>';


while($q = mysql_fetch_assoc($rek))
{
echo 'URL: <a href = "'.$q['url'].'">'.$q['url'].'</a> <a href="/adm/ads.php?item=del&id='.$q['id'].' " >[уд]</a> <a href="/adm/ads.php?item=red&id='.$q['id'].' " >[ред]</a></br>Название: '.$q['name'].'</br>Жить до: '.date('d.m.y H:i:s',$q['time']).'</br></br>';
}

break;
case 'add':

$max_day = '365';
//Доступные цвета
$alc=array(
'red'=>'Красный',
'blue'=>'Синий',
'black'=>'Чёрный',
'green'=>'Зелёный',
'orange'=>'Оранжевый',
//
'brown'=>'Коричневый',
'indigo'=>'Индиго',
'crimson'=>'Малиновый',
'purple'=>'Пурпурный',
'maroon'=>'Каштановый',
'olive'=>'Оливковый',
'chocolate'=>'Шоколадный',
'sienna'=>'Охра',
'firebrick'=>'огнеупорный кирпич',
'saddlebrown'=>'Старая кожа',
'seagreen'=>'Зелёное море',
'forestgreen'=>'Лесная зелень',
//
);

if(isset($_POST['submit'])){
$url=mysql_real_escape_string(htmlspecialchars($_POST['url']));
$name=mysql_real_escape_string(htmlspecialchars($_POST['name']));
$ilu=mb_strlen($url);
$iln=mb_strlen($name);
$days=abs(intval($_POST['days']));
$type=abs(intval($_POST['type']));

if(empty($_POST['bold'])){$b='0';
}else{
$b='1';
}
if(empty($_POST['italic'])){$k='1';
}else{
$k='0';
}

if(!empty($_POST['color'])){
$color=mysql_real_escape_string(htmlspecialchars($_POST['color']));
}

$day = time()+(86400*$days);
if(empty($_POST['url']) || empty($_POST['name']) || empty($_POST['days'])){$error = 'Не заполнено одно из полей';}
if($ilu<11 || $ilu>50){$error = 'Предельная длина URL 11-50';}
if($iln<3 || $iln>32){$error = 'Предельная длина названия 3-32';}
if($type != '0' && $type != '1'){$error = 'Выберите тип рекламы';}
if($days<0 || $days>$max_day){$error = 'Предельное количество дней 1-'.$max_day.'</div>';}
$time = time()+(86400*$days);
if(empty($error)){
mysql_unbuffered_query("INSERT INTO `rekl` SET `date` = ".time().", `time` = ".$time.",`url` = '".$url."', `name` = '".$name."',`open` = '1', `color` = '".$color."',`bold` = ".$b.",`italic` = ".$k.",`type` = ".$type." ");

echo'<div class="success"> Реклама успешно добавлена </div>';
}
else
{
echo'<div class="error"> '.$error.' </div>';
}

}

echo'<form action="" method="post">Добавление рекламы<br/>
URL сайта(50):<br/><input name="url" type="text" maxlength="50" value="http://"/><br/>
Название ссылки(32):<br/><input name="name" type="text" maxlength="32"/><br/>
Дни(1-'.$max_day.'):<br/><input name="days" type="text" maxlength="5" size="5" value="7"/><br/>

Тип рекламы:<br/>
<select name="type">';
echo'<option value="0">Сверху</option>';
echo'<option value="1">Снизу</option>';
echo'</select></br>

Цвет ссылки:<br/>
<select name="color">';
echo'<option value="none">Без цвета</option>';
foreach($alc as $slc=>$slv){
echo'<option value="'.$slc.'">'.$slv.'</option>';
}
echo'</select><br/>
<input name="bold" type="checkbox" value="1"/> <b>Жирный</b><br/>

<br/>
<input type="submit" name="submit" value="Добавить"/></form>';

break;
case 'red':

$id = intval($_GET['id']);
$uu = mysql_fetch_assoc(mysql_query("SELECT * FROM `rekl` WHERE `id` = '".$id."'"));

if(!$uu){ die('Нет такой рекламы'); }

if($_REQUEST['submit']){

$name = mysql_real_escape_string($_POST['name']);
$url = mysql_real_escape_string($_POST['url']);
$type = ($_POST['type']);

if(!$name){ echo 'Введите название ссылки'; }
if(!$url){ echo 'Введите URL ссылки'; }
if($type != '1' && $type != '0'){ echo 'Введите тип рекламы'; }

mysql_query("UPDATE `rekl` SET `name` = '".$name."',`url` = '".$url."',`type` = '".$type."' WHERE `id` = '".$id."'");
echo 'Успешно обновлено</br><a href = "/adm/ads.php">Назад</a>';
}

echo(
"<div class='form'>\n".
"<form action='' method='post'>\n".
"Имя:<br />\n".
"<input type='text' name='name' maxlength='60' value='".$uu['name']."' /><br />\n".
"URL:<br />\n".
"<input type='text' name='url' maxlength='60' value='".$uu['url']."' /><br />\n".
"Тип рекламы:<br/>
<select name='type'>
<option value='0'>Сверху</option>
<option value='1'>Снизу</option>
</select></br>".
"<input type='hidden' name='action' value='1' />\n".
"<input type='submit' name = 'submit' value='Обновить' />\n".
"</form></div><br />\n");

break;
case 'del':

$id = intval($_GET['id']);
$uu = mysql_fetch_assoc(mysql_query("SELECT * FROM `rekl` WHERE `id` = '".$id."'"));

if(!$uu){ die('Нет такой рекламы'); }

mysql_query("DELETE FROM `rekl` WHERE `id` = '".$id."'");
echo 'Реклама успешно удалена</br><a href = "/adm/ads.php">Назад</a></a>';

break;
}
 


echo(
"---<br />\n".
"<a href='/adm/'>Панель управления</a><br />\n");
require_once('../foot.php');
?>