<?php
define('MTOP', 1);
$title = 'Админка - Управление новостями';
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
require_once('../head.php');

level(3);
switch($act)
	{
			default:
			echo '<div class="layout-cell content">
                        <article class="post article">
                            <section><div class="block">Новости</div>';
			
			$count = mysql_num_rows(mysql_query("SELECT * FROM `news`"));
			if($count > 0)
				{
					$total=intval(($count-1)/$page_top)+1; 
					$page=abs(intval($_GET['page'])); 
					if(empty($page) OR $page < 0)
						{
							$page = 1; 
						}
					if($page > $total)
						{
							$page = $total; 
						}
					$past=intval($count/$page_news);  
					$start=$page*$page_news-$page_news; 
					$news = mysql_query("SELECT * FROM `news` ORDER BY `time` DESC LIMIT ".$start.",".$page_top."");
					while($row = mysql_fetch_array($news)) 
						{
							$start++;
							$count_comment = mysql_num_rows(mysql_query("SELECT * FROM `news_comments` WHERE `id_news` = '".$row['id']."'"));
							echo '<div class="l1"><b>'.$row['name'].'</b> ['.data($row['time']).']<br>';
							echo '<li>';
							echo $row['text'].'<li>';
							echo '<hr>';
							echo 'Добавил: '.$row['author'].'';
							
							echo '<a href="http://'.$set['home'].'/mtop_panel/news.php?act=del_news&id='.$row['id'].'">Удалить Новость</a> :: <a href="http://'.$set['home'].'/mtop_panel/news.php?act=edit_news&id='.$row['id'].'">Изменить Новость</a><br/>';
							echo '</div>';
						}
					navigation($count,$page_news,$page,'http://'.$set['home'].'/adm/news.php/',$total);
				}
			else
				{
					echo '<div class="main">';
					echo 'Новостей нет!<br/>';
					echo '</div>';
				}
		break;
		case 'add':
		if(!isset($_POST['ok']))
			{
				echo '
				<div class="main">
				<form action="news.php?act=add" method="post">
				Название новости(max. 30):<br/>
				<input type="text" name="name" class="input" maxlength="30" /><br />
				Текст новости(max. 200):<br/>
				<textarea name="text" cols="38" rows="8"></textarea><br/>
				<input name="ok" type="submit" value="Добавить" />
				</form>
				</div>
				';
			}
		else
			{
				$name = htmlspecialchars(trim($_POST['name']));
				$text = htmlspecialchars(trim($_POST['text']));
				$error = '';
				if(empty($name) OR empty($text))
					{
						$error .= 'Ошибка! Не заполнены поля! <br/>';
					}
				if(mb_strlen($name) > 30)
					{
						$error .= 'Ошибка! Поле "Название новости" больше 30 символов! <br/>';
					}
				if(mb_strlen($text) > 1000)
					{
						$error .= 'Ошибка! Поле "Текст новости" больше 1000 символов! <br/>';
					}
				if(!empty($error))
					{
						echo '<div class="topni">';
						echo $error;
						echo '</div>';
					}
				else
					{
						$insert = mysql_query("INSERT INTO `news` SET 
                `name` = '" . mysql_real_escape_string($name) . "',
                `text` = '" . mysql_real_escape_string($text) . "', 
                `time` = '" . time() . "',
                `author` = '" . mysql_real_escape_string($user_data['login']) . "'");
						if($insert)
							{
								echo '<div class="main">';
								echo 'Новость успешно добавлена! <br/>';
								echo '</div>';
							}
						else
							{
								echo '<div class="topni">';
								echo 'Новость не добавлена! <br/>';
								echo '</div>';
							}
					}			
			}
		break;
		case 'del_news':
		if($id)
			{
				$del_comm = mysql_query("DELETE FROM `news_comments` WHERE `id_news` = '".$id."'");
				$del_news = mysql_query("DELETE FROM `news` WHERE `id` = '".$id."'");
				if($del_news AND $del_comm)
					{
						echo '<div class="main">';
						echo 'Новость успешно удалена! <br/>';
						echo '</div>';
					}
				else
					{
						echo '<div class="topni">';
						echo 'Новость не удалена! <br/>';
						echo '</div>';
					}
			}
		else
			{
				echo '<div class="topni">';
				echo 'Не выбрана новость! <br/>';
				echo '</div>';
			}
		break;
		case 'edit_news':
		if($id)
			{
				$isset = mysql_query("SELECT * FROM `news` WHERE `id` = '".$id."'");
				if(mysql_num_rows($isset) > 0)
					{
						$news = mysql_fetch_array($isset);
						echo '<div class="title">Изменение новости</div>';
						if(!isset($_POST['ok']))
							{
								echo '
								<div class="main">
								<form action="news.php?act=edit_news&id='.$id.'" method="post">
								Название новости(max.30):<br/>
								<input type="text" name="name" maxlength="30" value="'.$news['name'].'"/><br/>
								Текст новости(max.200):<br/>
								<textarea name="text" cols="38" rows="8">'.$news['text'].'</textarea><br/>
								<input type="submit" name="ok" value="Изменить"/>
								</form></div>';
							}
						else
							{
								$name = htmlspecialchars(trim($_POST['name']));
								$text = htmlspecialchars(trim($_POST['text']));
								$error = '';
								if(empty($name) OR empty($text))
									{
										$error .= 'Ошибка!Не заполнены поля!<br/>';
									}
								if(mb_strlen($name) > 30)
									{
										$error .= 'Ошибка!Поле "Название новости" больше 30 символов<br/>';
									}
								if(mb_strlen($text) > 1000)
									{
										$error .= 'Ошибка!Поле "Текст новости" больше 1000 символов<br/>';
									}
								if(!empty($error))
									{
										echo '<div class="error">';
										echo $error;
										echo '</div>';
									}
								else
									{
										$up = mysql_query("UPDATE `news` SET
               `name` = '" . mysql_real_escape_string($name) . "',
               `text` = '" . mysql_real_escape_string($text) . "' 
                WHERE `id` = '" .$id. "'");
										if($up)
											{
												echo '<div class="main">';
												echo 'Новость успешно изменена<br/>';
												echo '</div>';
											}
										else
											{
												echo '<div class="topni">';
												echo 'Новость не изменена<br/>';
												echo '</div>';
											}
									}
							}
					}
				else
					{
						echo '<div class="topni">';
						echo 'Данной новости нет!<br/>';
						echo '</div>';
					}
			}
		else
			{			
				echo '<div class="topni">';
				echo 'Не выбрана новость!<br/>';
				echo '</div>';
			}
		break;
	
	}

echo '<div class="main">';
echo '<a href="http://'.$set['home'].'/adm/news.php?act=add">Добавить Новость</a><br/>';
echo '<a href="http://'.$set['home'].'/mtop_panel/news.php">К управлению новостями</a><br/>';
echo '<a href="http://'.$set['home'].'/mtop_panel/index.php">В Админку</a><br/>';
echo '</div>';

require_once('../foot.php');
?>