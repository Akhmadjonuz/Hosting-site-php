<?php
define('MTOP', 1);
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
$title = 'Модерация сайтов';
require_once('../head.php');
echo '<div class="title2">Модерация сайтов</div>';
switch($act){
default:
$count = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `status` = '0'"));
if($count > 0){
$total=intval(($count-1)/$set['page_moderacia'])+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0)$page = 1;
if($page > $total) $page = $total;
$past=intval($count/$set['page_moderacia']);
$start=$page*$set['page_moderacia']-$set['page_moderacia'];
$moder = mysql_query("SELECT * FROM `sait` WHERE `status` = '0' ORDER BY `id` DESC LIMIT ".$start.",".$set['page_moderacia']."");
while($row = mysql_fetch_array($moder)){
$start++;
echo '<div class="main"><a href="http://'.$set['home'].'/out/'.$row['id'].'.php"><b>'.$row['url'].'</b></a><br/>';
if(mb_strlen($row['about']) > 150){
$text = mb_substr($row['about'], 0, 150, 'utf-8');
echo ''.$text.'..<hr>';
}
else {
echo ''.$row['about'].'<hr>';
}
echo '<a href="moderacia.php?act=activate&id='.$row['id'].'">Активировать</a> | <a href="platforms.php?act=edit_sait&id='.$row['id'].'">Редактировать</a> | <a href="platforms.php?act=ban&id='.$row['id'].'">Заблокировать</a> | <a href="platforms.php?act=del_sait&id='.$row['id'].'">Удалить</a></div>';
}
navigation($count,$set['page_moderacia'],$page,'moderacia.php?',$total);
}
else
echo '<div class="main"><center>Нет непромодерированных сайтов</center></div>';
break;

case 'activate':
$up = mysql_query("UPDATE `sait` SET  `status` = '1',  `id_mod` = '".$user_data["id"]."', `time_activ` = '".time()."' WHERE `id` = '".$id."'");
if($up){
echo '<div class="main"><center>Сайт успешно активирован</center></div>';
}
else{
echo '<div class="main">Сайт не активирован</div>';
}
}
echo '<div class="lt"><a href="/yamuska/">Назад в админку</a></div>';
require_once('../foot.php');
?>