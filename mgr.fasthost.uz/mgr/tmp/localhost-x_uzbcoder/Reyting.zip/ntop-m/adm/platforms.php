<?php
define('MTOP', 1);
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
switch($act){
default:
$title = 'Управление площадками';
require_once('../head.php');
echo '<div class="title2">Управление площадками</div>';
$count = mysql_num_rows(mysql_query("SELECT * FROM `sait`"));
if($count > 0){
$total=intval(($count-1)/$page_sait)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($count/$page_sait);
$start=$page*$page_sait-$page_sait;
if($_GET['sort'] == 'hits') $sort= 'hits';
elseif($_GET['sort'] == 'in') $sort= 'in';
elseif($_GET['sort'] == 'out') $sort= 'out';
else $sort= 'hosts';
$saits = mysql_query("SELECT * FROM `sait` ORDER BY `".$sort."` DESC LIMIT ".$start.",".$page_sait."");
echo '<div class="main">Сортировать по: ';
if($_GET['sort'] == 'hosts'  OR $_GET['sort']==null) echo 'Хостам'; else echo '<a href="platforms.php?sort=hosts">Хостам</a>'; echo ' | ';
if($_GET['sort'] == 'hits') echo 'Хитам'; else echo '<a href="platforms.php?sort=hits">Хитам</a>'; echo ' | ';
if($_GET['sort'] == 'in') echo 'В топ'; else echo '<a href="platforms.php?sort=in">В топ</a>'; echo ' | ';
if($_GET['sort'] == 'out') echo 'Из топа'; else echo '<a href="platforms.php?sort=out">Из топа</a>';
echo '</div>';
while($row = mysql_fetch_array($saits)){
$start++;
if($row['ban'] == 1) $ban  = '<a href="platforms.php?act=ban&id='.$row['id'].'">Разблокировать</a>';
else $ban = '<a href="platforms.php?act=ban&id='.$row['id'].'">Заблокировать</a>';
if($row['status'] == 0)  $ban .= ' | <a href="moderacia.php?act=activate&id='.$row['id'].'">Активировать</a>';
$zabanen = ($row['ban'] == 0) ? '' : '[<font color="red">Заблокирована</font>]';
$status = $row['status'] == 1 ? '' : '[<font color="red">На модерации</font>]';
echo '<div class="main"><a href="http://'.$set['home'].'/out/'.$row['id'].'.php"><b>'.$row['url'].'</b></a> (<b><a href="http://'.$set['home'].'/infos.php?id='.$row['id'].'">'.$row['hosts'].'/'.$row['hits'].'</a></b>) '.$zabanen.''.$status.'</a><br/>';
if(mb_strlen($row['about']) > 150){
$text = mb_substr($row['about'], 0, 150, 'utf-8');
echo ''.$text.'..';
}
else {
echo ''.$row['about'].'..</a>';
}
echo '<hr>';
echo '<a href="platforms.php?act=edit_sait&id='.$row['id'].'">Редактировать</a> | <a href="platforms.php?act=del_sait&id='.$row['id'].'">Удалить</a> | '.$ban.'</div>';
}
navigation($count,$page_sait,$page,'platforms.php?sort='.$sort.'&',$total);
}
else {
echo '<div class="main"><center>Площадок нет</center></div>';
}
break;

case 'edit_sait':
$title = 'Редактирование площадки';
require_once('../head.php');
echo '<div class="title2">Редактирование площадки</div>';
$platform = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."' LIMIT 1");
$platform_count = mysql_num_rows($platform);
$user_platform = mysql_fetch_array($platform);
if($platform_count > 0){
$redsait = '<form action="platforms.php?act=edit_sait&id='.$id.'" method="post">
<div class="main">Адрес сайта(без http:// и т.п):<br/>
<input type="text"  class="input" name="url" maxlength="55" value="'.$user_platform['url'].'" /><br/>
Описание сайта:<br/>
<textarea name="about" cols="38" rows="8" maxlength="210">'.$user_platform['about'].'</textarea><br/>
Категория:<br/>
<select name="cat">';
$cats = mysql_query("SELECT * FROM `cat` ORDER BY `id` ASC");
if(mysql_num_rows($cats) > 0){
while($cat = mysql_fetch_assoc($cats)){
$selected = ($user_platform['category'] == $cat['id']) ? ' selected="selected"' : '';
$redsait .= '<option value="'.$cat['id'].'"'.$selected.'>'.$cat['name'].'</option>';
}
$redsait .= '</select></div>';
$redsait .= '<div class="main">Выберите счётчик:<br/>';
if ($user_platform['image'] == 1)
$redsait .= '<input type="radio" name="image" value="1" checked="checked"> <img src="/images/big/1.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="1"> <img src="/images/big/1.gif" alt=""><br/>';
if ($user_platform['image'] == 2)
$redsait .= '<input type="radio" name="image" value="2" checked="checked"> <img src="/images/big/2.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="2"> <img src="/images/big/2.gif" alt=""><br/>';
if ($user_platform['image'] == 3)
$redsait .= '<input type="radio" name="image" value="3" checked="checked"> <img src="/images/big/3.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="3"> <img src="/images/big/3.gif" alt=""><br/>';
if ($user_platform['image'] == 4)
$redsait .= '<input type="radio" name="image" value="4" checked="checked"> <img src="/images/big/4.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="4"> <img src="/images/big/4.gif" alt=""><br/>';
if ($user_platform['image'] == 5)
$redsait .= '<input type="radio" name="image" value="5" checked="checked"> <img src="/images/big/5.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="5"> <img src="/images/big/5.gif" alt=""><br/>';
if ($user_platform['image'] == 6)
$redsait .= '<input type="radio" name="image" value="6" checked="checked"> <img src="/images/big/6.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image" value="6"> <img src="/images/big/6.gif" alt=""><br/>';
$redsait .= '</div><div class="main">Выберите счётчик:<br/>';
if ($user_platform['image_s'] == 1)
$redsait .= '<input type="radio" name="image_s" value="1" checked="checked"> <img src="/images/small/1.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="1"> <img src="/images/small/1.gif" alt=""><br/>';
if ($user_platform['image_s'] == 2)
$redsait .= '<input type="radio" name="image_s" value="2" checked="checked"> <img src="/images/small/2.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="2"> <img src="/images/small/2.gif" alt=""><br/>';
if ($user_platform['image_s'] == 3)
$redsait .= '<input type="radio" name="image_s" value="3" checked="checked"> <img src="/images/small/3.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="3"> <img src="/images/small/3.gif" alt=""><br/>';
if ($user_platform['image_s'] == 4)
$redsait .= '<input type="radio" name="image_s" value="4" checked="checked"> <img src="/images/small/4.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="4"> <img src="/images/small/4.gif" alt=""><br/>';
if ($user_platform['image_s'] == 5)
$redsait .= '<input type="radio" name="image_s" value="5" checked="checked"> <img src="/images/small/5.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="5"> <img src="/images/small/5.gif" alt=""><br/>';
if ($user_platform['image_s'] == 6)
$redsait .= '<input type="radio" name="image_s" value="6" checked="checked"> <img src="/images/small/6.gif" alt=""><br/>';
else $redsait .= '<input type="radio" name="image_s" value="6"> <img src="/images/small/6.gif" alt=""><br/>';
$redsait .= '</div>
<div class="main"><input name="ok" type="submit" value="Изменить" /></div></form>';
}
else $redsait .= '<div class="error">Данной площадки не существует</div>';
if(!isset($_POST['ok'])) echo $redsait;
else{
$url = filter($_POST['url']);
$url = str_replace("http://","",$url);
$url = str_replace("https://","",$url);
$about = filter($_POST['about']);
$cat = intval($_POST['cat']);
$image = filter($_POST['image']);
$image_s = filter($_POST['image_s']);
$error = '';
if(empty($cat) OR empty($image) OR empty($image_s) OR empty($url) OR empty($about))
$error .= '<div class="error">Незаполнено одно или несколько полей</div>';
else{
if($image < 1 OR $image > 6) $error .= '<div class="error">Нет такого счетчика</div>';
if($image_s < 1 OR $image_s > 6) $error .= '<div class="error">Нет такого счетчика</div>';
$isset_cat = mysql_num_rows(mysql_query("SELECT `id` FROM `cat` WHERE `id` = '".$cat."'"));
if($isset_cat == 0)
$error .= '<div class="error">Нет такой категории</div>';
$platform_isset = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."' LIMIT 1"));
if($platform_isset == 0)
$error .= '<div class="error">Нет такой площадки</div>';
if(mb_strlen($about) > 200 OR mb_strlen($about) < 10)
$error .= '<div class="error">Длина описания должна быть не короче 10 и не длиннее 200 символов</div>';
if(mb_strlen($url) > 50 OR mb_strlen($url) < 3)
$error .= '<div class="error">Длина адреса должна быть не короче 3 и не длиннее 50 символов</div>';
}
if(!empty($error)){
echo $error;
echo $redsait;
}
else{
$edit = mysql_query("UPDATE `sait` SET `category` = '".$cat."', `image` = '".$image."', `image_s` = '".$image_s."', `about` = '".$about."', `url` = '".$url."' WHERE `id` = '".$id."'");
if($edit) echo '<div class="main"><center>Площадка успешно отредактирована</center></div>';
else {
echo '<div class="main"><center>Площадка не отредактирована</center></div>';
}
}
}
}
else {
echo '<div class="main">Данной площадки несуществует</div>';
}
break;

case 'del_sait':
if($user_data AND $user_data['level'] < 3 OR !$user_data){
$title = 'Ошибка';
require_once('../head.php');
echo '<div class="title2">Ошибка</div>';
echo '<div class="main"><center>Вы не администратор</center></div>';
require_once('../foot.php');
exit;
}

$title = 'Удаление площадки';
require_once('../head.php');
echo '<div class="title2">Удаление площадки</div>';
$sait_isset = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'LIMIT 1");
$sait_isset_c = mysql_num_rows($sait_isset);
if($sait_isset_c > 0){
$sait = mysql_fetch_array($sait_isset );
if(!isset($_GET['ok'])){
echo '<div class="main">Вы действительно хотите удалить площадку <b>'.$sait['url'].'</b>?<hr>';
echo '<center><a href="platforms.php?act=del_sait&id='.$id.'&ok"">Да</a> | ';
echo '<a href="platforms.php">Нет</a><center></div>';
}
else{
$del_hosts = mysql_query("DELETE FROM `hosts` WHERE `id_sait` = '".$id."'");
$del_hits = mysql_query("DELETE FROM `hits` WHERE `id_sait` = '".$id."'");
$del_in = mysql_query("DELETE FROM `in` WHERE `id_sait` = '".$id."'");
$del_out = mysql_query("DELETE FROM `out` WHERE `id_sait` = '".$id."'");
$del_online = mysql_query("DELETE FROM `sait_online` WHERE `id_sait` = '".$id."'");
$del_platform = mysql_query("DELETE FROM `sait` WHERE `id` = '".$id."'");
if($del_hosts AND $del_hits AND $del_in AND $del_out AND $del_online AND $del_platform)
echo '<div class="main"><center>Площадка не удалена</center></div>';
else {
echo '<div class="main"><center>Площадка успешно удалена</center></div>';
}
}
}
else {
echo '<div class="main"><center>Нет такой площадки</center></div>';
}
break;

case 'ban':
$title = 'Блокировка площадки';
require_once('../head.php');
echo '<div class="title2">Блокировка площадки</div>';
if($id){
$checking = mysql_query("SELECT * FROM `sait` WHERE `id` = '".$id."'");
if(mysql_num_rows($checking) > 0){
$check = mysql_fetch_array($checking);
if($check['ban'] == 0){
$blok =  '<form action="platforms.php?act=ban&id='.$id.'" method="post">
<div class="main">Причина блокировки:<br/>
<input type="text" name="reason" maxlength="85" value=""/><br/>
<input type="submit" name="ok" value="Заблокировать"/></div></form>';
if(!isset($_POST['ok'])) echo $blok;
else{
$reason = filter($_POST['reason']);
$error = '';
if(empty($reason)) $error .= '<div class="error">Не введена причина блокировки</div>';
else if(mb_strlen($reason) > 80 OR mb_strlen($reason) < 5 )
$error .= '<div class="error">Причина блокировки должна быть не короче 5 и не длиннее 80 символов</div>';
if(!empty($error)){
echo $error;
echo $blok;
}
else{
$ban = mysql_query("UPDATE `sait` SET `ban` = '1',`status` = '1', `ban_reason` = '".$reason."', `ban_who` = '".$user_data['id']."', `ban_time` = '".time()."' WHERE `id` = '".$id."'");
if($ban) echo '<div class="main"><center>Площадка успешно заблокирована</center></div>';
else {
echo '<div class="main"><center>Площадка не заблокирована</center></div>';
}
}
}
}
else{
$unban = mysql_query("UPDATE `sait` SET `ban` = '0', `ban_reason` = '', `ban_who` = '' WHERE `id` = '".$id."'");
if($unban)  echo '<div class="main"><center>Площадка успешно разблокирована</center></div>';
else {
echo '<div class="main"><center>Площадка не разблокирована</center></div>';
}
}
}
else {
echo '<div class="main"><center>Данной площадки не существует</center></div>';
}
}
break;
}
echo '<div class="lt"><a href="/yamuska/">Назад в админку</a></div>';
require_once('../foot.php');
?>