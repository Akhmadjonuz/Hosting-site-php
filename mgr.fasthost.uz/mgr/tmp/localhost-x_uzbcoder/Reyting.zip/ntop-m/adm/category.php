<?php
define('MTOP', 1);
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
switch($act){
default:
$title = 'Управление категориями';
require_once('../head.php');
echo '<div class="title2">Управление категориями</div>';
$cat = mysql_query("SELECT * FROM `cat` ORDER BY `position` ASC");
if(mysql_num_rows($cat) > 0){
while($row = mysql_fetch_assoc($cat)){
$count_sites = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `category` = '".$row['id']."' AND `status` = '1'"));
echo '<div class = "main"><a class="link" href = "/cat.php?act=view&id='.$row['id'].'">'.$row['name'].'</a> <small>(Сайтов: '.$count_sites.')<br/>'.$row['about'].'</small><hr>
<a href="category.php?act=del&id='.$row['id'].'">Удалить</a> | <a href="category.php?act=edit&id='.$row['id'].'">Изменить</a></div>';
}
}
else {
echo '<div class="main"><center>Нет категорий</center></div>';
}
echo'<div class="main"><a href="category.php?act=add">Добавить категорию</a></div>';
break;

case 'del':
$title = 'Удаление категории';
require_once('../head.php');
echo '<div class="title2">Удаление категории</div>';
$proverka = mysql_query("SELECT * FROM `cat` WHERE `id` = '".$id."'");
if(mysql_num_rows($proverka) > 0) $array = mysql_fetch_array($proverka);
else {
echo '<div class="main"><center>Данной категории нет</center></div>';
}
if(!isset($_POST['ok'])){
echo '<form action="category.php?act=del&id='.$id.'" method="post">
<div class="main">При удалении категории "'.$array['name'].'", переместить все сайты в категорию:<br/><select name="cid">';
$cats = mysql_query("SELECT * FROM `cat` WHERE `id` != '".$id."' ORDER BY `id` ASC");
if(mysql_num_rows($cats) > 0){
while($cat = mysql_fetch_array($cats))
echo '<option value="'.$cat['id'].'">'.$cat['name'].'</option>';
}
echo '</select></div>
<div class="main"><input type="submit" name="ok" value="Удалить" /></div></form>';
}
else{
$cat_id = isset($_POST['cid']) ? abs(intval($_POST['cid'])) : '';
if($cat_id == 0) echo '<div class="error">Не выбрана категория в которую нужно переместить сайты</div>';
$test_new_cat = mysql_query("SELECT * FROM `cat` WHERE `id` = '".$cat_id."'");
if(mysql_num_rows($test_new_cat) == 0) echo '<div class="error">Категория, в которую нужно переместить сайты не существует</div>';
else{
$up = mysql_query("UPDATE `sait` SET `category` = '".$cat_id."' WHERE `category` = '".$id."'");
$del = mysql_query("DELETE FROM `cat` WHERE `id` = '".$id."'");
if($up AND $del) echo '<div class="main"><center>Категория успешно удалена</center></div>';
else {
echo '<div class="main"><center>Категория не удалена</center></div>';
}
}
}
break;

case 'add':
$title = 'Добавление категории';
require_once('../head.php');
echo '<div class="title2">Добавление категории</div>';
$pluscat = '<form action="category.php?act=add" method="post">
<div class="main">Название категории:<br/>
<input type="text" name="name" maxlength="35" value=""/><br/>
Позиция:<br/>
<input type="text" name="position" maxlength="2" value=""/><br/>
<input type="submit" name="ok" value="Добавить"/>
</div></form>';
if(!isset($_POST['ok'])) echo $pluscat;
else{
$name = filter($_POST['name']);
$position = (int)$_POST['position'];
$error = '';
if($name == null OR $position == nul)
$error .= '<div class="error">Не заполнено одно или несколько полей</div>';
else{
if(mb_strlen($name) > 30 OR mb_strlen($name) < 5)
$error .= '<div class="error">Имя категории должно быть не короче 5 и не длиннее 30 символов</div>';
if($position > 30 )
$error .= '<div class="error">Позиция категории должна быть не выше 30</div>';
}
if(!empty($error)){
echo $error;
echo $pluscat;
}
else{
$create = mysql_query("INSERT INTO `cat` SET `name` = '".$name."', `position` = '".$position."'");
if($create) echo '<div class="main"><center>Категория успешно создана</center></div>';
else{
echo '<div class="main"><center>Категория не создана</center></div>';
echo $pluscat;
}
}
}
break;

case 'edit':
$title = 'Редактирование категории';
require_once('../head.php');
echo '<div class="title2">Редактирование категории</div>';
if($id){
$isset = mysql_query("SELECT * FROM `cat` WHERE `id` = '".$id."'");
if(mysql_num_rows($isset) > 0){
$cat = mysql_fetch_array($isset);
$redkat = '<form action="category.php?act=edit&id='.$id.'" method="post">
<div class="main">Название категории:<br/>
<input type="text" name="name" maxlength="35" value="'.$cat['name'].'"/><br/>
Позиция:<br/>
<input type="text" name="position" maxlength="2" value="'.$cat['position'].'"/><br/>
<input type="submit" name="ok" value="Изменить"/>
</div></form>';
if(!isset($_POST['ok']))
echo $redkat;
else{
$name = filter($_POST['name']);
$position = (int)$_POST['position'];
$error = '';
if($name == null OR $position == nul)
$error .= '<div class="error">Не заполнено одно или несколько полей</div>';
else{
if(mb_strlen($name) > 30 OR mb_strlen($name) < 5)
$error .= '<div class="error">Имя категории должно быть не короче 5 и не длиннее 30 символов</div>';
if($position > 30 )
$error .= '<div class="error">Позиция категории должна быть не выше 30</div>';
}
if(!empty($error)){
echo $error;
echo $redkat;
}
else{
$up = mysql_query("UPDATE `cat` SET `name` = '".$name."', `position` = '".$position."' WHERE `id` = '".$id."'");
if($up)echo '<div class="main"><center>Категория успешно отредактирована</center></div>';
else echo '<div class="main"><center>	</center></div>';
}
}
}
else {
echo '<div class="error">Данной категории не существует</div>';
}
}
else {
echo '<div class="error">Не выбрана категория</div>';
}
break;
}
echo '<div class="lt"><a href="/yamuska/">Назад в админку</a></div>';
require_once('../foot.php');
?>