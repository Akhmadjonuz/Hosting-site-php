<?php
define('MTOP', 1);
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
switch($act){
default:
$title = 'Управление пользователями';
require_once('../head.php');
echo '<div class="title2">Управление пользователями</div>';
$count = mysql_num_rows(mysql_query("SELECT * FROM `users`"));
if($count > 0){
echo '<div class="main">Сортировать по: ';
if($_GET['sort'] == 'id'  OR $_GET['sort'] == null) echo 'ID'; else echo '<a href="users.php?sort=id">ID</a>'; echo ' | ';
if($_GET['sort'] == 'login') echo 'Логину'; else echo '<a href="users.php?sort=login">Логину</a>';
echo '</div>';
if($_GET['sort'] == 'login') $sort= 'login';
else $sort= 'id';
$total=intval(($count-1)/$page_users)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($count/$page_users);
$start=$page*$page_users-$page_users;
$users = mysql_query("SELECT * FROM `users` ORDER BY `".$sort."` ASC LIMIT ".$start.",".$page_users."");
while($row = mysql_fetch_array($users)){
$start++;
$platforms_c = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$row['id']."'"));
echo '<div class="main"><b>'.$start.'. <a href="users.php?act=user&id='.$row['id'].'"> '.$row['login'].'</a></b> ['.$platforms_c.']</div>';
}
navigation($count,$page_users,$page,'users.php?sort='.$sort.'&',$total);
}
else{
echo '<div class="main"><center>Пользователей нет</center></div>';
}
break;

case 'user':
$title = 'Информация о пользователе';
require_once('../head.php');
echo '<div class="title2">Информация о пользователе</div>';
$isset = mysql_query("SELECT * FROM `users` WHERE `id` = '".$id."'");
if(mysql_num_rows($isset) == 0) echo '<div class="main"><center>Пользователь не найден</center></div>';
else{
$users = mysql_query("SELECT * FROM `users` WHERE `id` = '".$id."' LIMIT 1");
$user = mysql_fetch_array($users);
$platforms = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$user['id']."'"));
if($user['level'] == 3) $dolzhnost = 'Администратор';
else if($user['level'] == 2) $dolzhnost = 'Модератор';
else $dolzhnost = 'Пользователь';
echo '<div class="main">ID: '.$user['id'].'<br/>';
echo 'Логин: '.$user['login'].'<br/>';
echo 'Email: '.$user['mail'].'<br/>';
echo 'Должность: '.$dolzhnost.'<br/>';
echo 'Дата регистрации: '.data($user['time_reg']).'<hr>';
echo '<a href="users.php?act=platforms&id='.$id.'">Площадки пользователя</a> ['.$platforms.'/'.$set['max_platforms'].'] | ';
echo '<a href="users.php?act=del_user&id='.$id.'">Удалить пользователя</a></div>';
}
break;

case 'platforms':
$title = 'Площадки пользователя';
require_once('../head.php');
echo '<div class="title2">Площадки пользователя</div>';
$count = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$id."'"));
if($count > 0){
$total=intval(($count-1)/$page_sait)+1;
$page=abs(intval($_GET['page']));
if(empty($page) OR $page < 0) $page = 1;
if($page > $total) $page = $total;
$past=intval($count/$page_sait);
$start=$page*$page_sait-$page_sait;
if($_GET['sort'] == 'hits') $sort= 'hits';
elseif($_GET['sort'] == 'in') $sort= 'in';
elseif($_GET['sort'] == 'out') $sort= 'out';
else $sort= 'hosts';
$saits = mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$id."' ORDER BY `".$sort."` DESC LIMIT ".$start.",".$page_sait."");
echo '<div class="main">Сортировать по: ';
if($_GET['sort'] == 'hosts'  OR $_GET['sort']==null) echo 'Хостам'; else echo '<a href="users.php?act=platforms&id='.$id.'&sort=hosts">Хостам</a>'; echo ' | ';
if($_GET['sort'] == 'hits') echo 'Хитам'; else echo '<a href="users.php?act=platforms&id='.$id.'&sort=hits">Хитам</a>'; echo ' | ';
if($_GET['sort'] == 'in') echo 'В топ'; else echo '<a href="users.php?act=platforms&id='.$id.'&sort=in">В топ</a>'; echo ' | ';
if($_GET['sort'] == 'out') echo 'Из топа'; else echo '<a href="users.php?act=platforms&id='.$id.'&sort=out">Из топа</a>';
echo '</div>';
while($row = mysql_fetch_array($saits)){
$start++;
$zabanen = ($row['ban'] == 0) ? '' : '[<font color="red">Заблокирована</font>]';
$status = $row['status'] == 1 ? '' : '[<font color="red">На модерации</font>]';
echo '<div class="main"><b><a href="/out/'.$row['id'].'.php">'.$row['url'].'</a></b> (<b><a href="http://'.$set['home'].'/infos.php?id='.$row['id'].'">'.$row['hosts'].'/'.$row['hits'].'</a></b>) '.$zabanen.''.$status.'</a><hr>';
if(mb_strlen($row['about']) > 150){
$text = mb_substr($row['about'], 0, 150, 'utf-8');
echo ''.$text.'..';
}
else{
echo ''.$row['about'].'..';
}
echo '<hr>';
echo '<a href="/yamuska/platforms.php?act=edit_sait&id='.$row['id'].'">Редактировать</a> | ';
if($row['ban'] == 1) echo '<a href="/yamuska/platforms.php?act=ban&id='.$row['id'].'">Разблокировать</a> ';
else echo '<a href="/yamuska/platforms.php?act=ban&id='.$row['id'].'">Заблокировать</a> ';
if($row['status'] == 0)  echo ' <a href="/yamuska/moderacia.php?act=activate&id='.$row['id'].'"> | Активировать</a>';
echo '<a href="/yamuska/platforms.php?act=del_sait&id='.$row['id'].'"> | Удалить</a></div>';
}
navigation($count,$page_sait,$page,'users.php?act=platforms&id='.$id.'&sort='.$sort.'&',$total);
}
else echo '<div class="main"><center>У пользователя нет площадок</center></div>';
break;

case 'del_user':
$title = 'Удаление пользователя';
require_once('../head.php');
echo '<div class="title2">Удаление пользователя</div>';
$user_isset = mysql_query("SELECT * FROM `users` WHERE `id` = '".$id."' LIMIT 1");
$user_isset_c = mysql_num_rows($user_isset);
if($user_isset_c > 0){
$user = mysql_fetch_array($user_isset );
if(!isset($_GET['ok'])){
echo '<div class="main">Вы действительно хотите удалить пользователя <b>"'.$user['login'].'"</b>?<hr>';
echo '<center><a href="users.php?act=del_user&id='.$id.'&ok">Да</a> | ';
echo '<a class="link" href="users.php">Нет</a><center></div>';
}
else{
$platforms = mysql_query("SELECT * FROM `sait` WHERE `id_user` = '".$id."' LIMIT 1");
while($sait = mysql_fetch_array($platforms)){
$del_hosts = mysql_query("DELETE FROM `hosts` WHERE `id_sait` = '".$platforms['id']."'");
$del_hits = mysql_query("DELETE FROM `hits` WHERE `id_sait` = '".$platforms['id']."'");
$del_online = mysql_query("DELETE FROM `sait_online` WHERE `id_sait` = '".$platforms['id']."'");
$del_platform = mysql_query("DELETE FROM `sait` WHERE `id` = '".$platforms['id']."'");
}
$del_user = mysql_query("DELETE FROM `users` WHERE `id` = '".$id."'");
if($del_user) echo '<div class="main"><center>Пользователь успешно удален</center></div>';
else {
echo '<div class="main"><center>Пользователь не удален</center></div>';
}
}
}
else {
echo '<div class="main"><center>Пользователь не существует</center></div>';
}
break;
}
echo '<div class="lt"><a href="/yamuska/">Назад в админку</a></div>';
require_once('../foot.php');
?>