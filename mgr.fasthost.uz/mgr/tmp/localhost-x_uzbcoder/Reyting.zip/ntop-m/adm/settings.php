<?php
define('MTOP', 1);
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
$title = 'Настройка системы';
require_once('../head.php');
echo '<div class="title2">Настройка системы</div>';
$nastroiki = '<form action="settings.php" method="post" name="form">
<div class="main">Название топ-рейтинга:<br/>
<input type="text" name="top_name" maxlength="30" class="do_button" value="'.$set['top_name'].'"/><br/>
Адрес , куда установлен скрипт (без http:// и т.п):<br/>
<input type="text" name="home" maxlength="30" class="do_button" value="'.$set['home'].'"/><br/>
Максимальное количество площадок у пользователя:<br/>
<input type="text" name="max_platforms" maxlength="2" class="do_button" value="'.$set['max_platforms'].'"/><br/>
Площадок на страницу в кабинете:<br/>
<input type="text" name="page_platforms" maxlength="2" class="do_button" value="'.$set['page_platforms'].'"/><br/>
Сайтов на страницу в категориях:<br/>
<input type="text" name="page_sait" maxlength="2" class="do_button" value="'.$set['page_sait'].'"/><br/>
Сайтов на страницу TOP-100:<br/>
<input type="text" name="page_top" maxlength="2" class="do_button" value="'.$set['page_top'].'"/><br/>
Элементов на страницу в статистике сайта:<br/>
<input type="text" name="pages" maxlength="2" class="do_button" value="'.$set['pages'].'"/><br/>
Сайтов на страницу в модерации:<br/>
<input type="text" name="page_moderacia" maxlength="2" class="do_button" value="'.$set['page_moderacia'].'"/><br/>
Новостей на страницу:<br/>
<input type="text" name="page_news" maxlength="2" class="do_button" value="'.$set['page_news'].'"/><br/>
Регистрация включена:<br/>
<select name="power_reg">';
if ($set['power_reg'] == 0){
$nastroiki .= '<option value="0">Нет</option><br/>';
$nastroiki .= '<option value="1">Да</option><br/>';
}
else{
$nastroiki .= '<option value="1">Да</option><br/>';
$nastroiki .= '<option value="0">Нет</option><br/>';
}
$nastroiki .= '</select><br/>
Модерация включена:<br/>
<select name="power_moder">';
if ($set['moderacia'] == 0){
$nastroiki .= '<option value="0">Да</option><br/>';
$nastroiki .= '<option value="1">Нет</option><br/>';
}
else{
$nastroiki .= '<option value="1">Нет</option><br/>';
$nastroiki .= '<option value="0">Да</option><br/>';
}
$nastroiki .= '</select><br/><input name="ok" type="submit" value="Сохранить" /></div></form>';
if(!isset($_POST['ok'])) echo $nastroiki;
else{
$top_name = filter($_POST['top_name']);
$home = filter($_POST['home']);
$home = trim(str_replace("http://","",$home));
$max_platforms = abs(intval($_POST['max_platforms']));
$page_platforms = abs(intval($_POST['page_platforms']));
$page_sait = abs(intval($_POST['page_sait']));
$page_top = abs(intval($_POST['page_top']));
$pages = abs(intval($_POST['pages']));
$page_moderacia = abs(intval($_POST['page_moderacia']));
$power_reg = abs(intval($_POST['power_reg']));
$page_news = abs(intval($_POST['page_news']));
$moderacia = abs(intval($_POST['power_moder']));
$error = '';
if(empty($home))
$error .= '<div class="error">Не заполнено одно или несколько полей</div>';
else{
}
if(!empty($error)){
echo $error;
echo $nastroiki;
}
else{

mysql_query("UPDATE `settings` SET `value` = '".$page_news."' WHERE `name` = 'page_news'");
mysql_query("UPDATE `settings` SET `value` = '".$top_name."' WHERE `name` = 'top_name'");
mysql_query("UPDATE `settings` SET `value` = '".$home."' WHERE `name` = 'home'");
mysql_query("UPDATE `settings` SET `value` = '".$max_platforms."' WHERE `name` = 'max_platforms'");
mysql_query("UPDATE `settings` SET `value` = '".$page_platforms."' WHERE `name` = 'page_platforms'");
mysql_query("UPDATE `settings` SET `value` = '".$page_sait."' WHERE `name` = 'page_sait'");
mysql_query("UPDATE `settings` SET `value` = '".$page_top."' WHERE `name` = 'page_top'");
mysql_query("UPDATE `settings` SET `value` = '".$pages."' WHERE `name` = 'pages'");
mysql_query("UPDATE `settings` SET `value` = '".$page_moderacia."' WHERE `name` = 'page_moderacia'");
mysql_query("UPDATE `settings` SET `value` = '".$power_reg."' WHERE `name` = 'power_reg'");
mysql_query("UPDATE `settings` SET `value` = '".$moderacia."' WHERE `name` = 'moderacia'");
echo '<div class="main"><center>Настройки успешно сохранены</center></div>';
}
}
echo '<div class="lt"><a href="/yamuska/">Назад в админку</a></div>';
require_once('../foot.php');
?>