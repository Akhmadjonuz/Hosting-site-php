<?php
define('MTOP', 1);
$title = 'Админ панель';
require_once('../system/connect.php');
require_once('../system/core.php');
require_once('../system/function.php');
level(3);
require_once('../head.php');
echo '<div class="title2">Админ панель</div>';
$plaforms_no_moder = mysql_num_rows(mysql_query("SELECT * FROM `sait` WHERE `status` = '0'"));
$plaforms_all = mysql_num_rows(mysql_query("SELECT * FROM `sait`"));
$users_all = mysql_num_rows(mysql_query("SELECT * FROM `users`"));
$cat_all = mysql_num_rows(mysql_query("SELECT * FROM `cat`"));
echo '<div class="main"><a href="moderacia.php">Модерация сайтов</a> ['.$plaforms_no_moder.']</div>';
echo '<div class="main"><a href="category.php">Управление категориями</a> ['.$cat_all.']</div>';

echo '<div class="main"><a href="news.php">Управление новостями</a></div>';
echo '<div class="main"><a href="settings.php">Настройка системы</a></div>';
echo '<div class="main"><a href="ads.php">Управление рекламы</a></div>';
echo '<div class="main"><a href="users.php">Управление пользователями</a> ['.$users_all.']</div>';
echo '<div class="main"><a href="platforms.php">Управление площадками</a> ['.$plaforms_all.']</div>';
require_once('../foot.php');
?>