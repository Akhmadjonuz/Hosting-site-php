<?php
/**
 * @ObmenBot obmen bot kodi library
 * @author ShaXzod Jomurodov <shah9409@gmail.com>
 * @contact https://t.me/idFox 
 * @contact Channel https://t.me/PCode
 * @rules ruxsatsiz koddan muallif nomini o'zgartirish yaxshi oqibatga olib kelmaydi!
 */

function checkUID($uid){
  $userId = file_get_contents('data/user.db');
  if(mb_stripos($userId,"$uid") !== false ){
    return true; 
  }
}

function addUser($uid){
  $userId = 'data/user.db';

  $id = "$uid\n";

  $handle = fopen($userId, 'a+');
  fwrite($handle, $id);
  fclose($handle);

  return true; 
}


function addRef($chat_id, $ref2){
  if (strlen($ref2) > 3) {

  	file_put_contents("user/$chat_id.ref", $ref2);

    $userFile = "user/$ref2.ref";

    $id = "$chat_id\n";
    $handle = fopen($userFile, 'a+');
    fwrite($handle, $id);
    fclose($handle);

    return true; 
  } else {
    return false;
  }
}

function getUID(){
  $efede = file_get_contents('data/pay.db');
  $efede = $efede+1;
  file_put_contents("data/pay.db", $efede);
    return $efede;
}















?>