<?php
/**
 * @ObmenBot obmen bot kodi
 * @author ShaXzod Jomurodov <shah9409@gmail.com>
 * @contact https://t.me/idFox or @ads_buy 
 * @contact Channel https://t.me/PCode
 * @rules ruxsatsiz koddan muallif nomini o'zgartirish yaxshi oqibatga olib kelmaydi!
 */

ob_start();
ini_set('date.timezone','ASIA/Tashkent');

//sozlash
require 'Telegram.php';
require 'efede.lib.php';

$bot_token = "1078297721:AAH901g1qYyHxqGqazegpisqHaZUTLPaffQ";   //bot tokenini kiriting
$bot_name = "AllObmenBot";            //bot @username sini yozing
$chek_efede = "@AllObmenBlog";                //chek tushadigan kanal nomini yoki ID raqami yozasi
$choyxona = "@AllObmenBlog";    //chek tushadigan kanal nomini yoki ID raqami yozasiz
$choyxona2 = "@AllObmenBlog";  //chek tushadigan kanal nomini yoki ID raqami yozasiz

$admin = '543379036';
$admin2 = '543379036';
//$admin = '543379036';
$ads_buy = '368844346';

$telegram = new Telegram($bot_token);
$efede3 = $telegram->getData();

//basic
$text = $efede3["message"]["text"];
$foto = $efede3["message"]["photo"];
$sana = $efede3["message"]["date"];

$mesid = $efede3["message"]["message_id"];

$chat_id = $efede3["message"]["chat"]["id"];
$fileclass = $efede3["message"]["document"]["file_name"];
$file_id = $efede3["message"]["document"]["file_id"];

// chat
$cfname = $efede3['message']['chat']['first_name'];
$cid = $efede3["message"]["chat"]["id"];
$clast_name = $efede3['message']['chat']['last_name'];
$turi = $efede3["message"]["chat"]["type"];
$username = $efede3['message']['chat']['username'];
$cusername = $efede3['message']['chat']['username'];
$ctitle = $efede3['message']['chat']['title'];

//user info
$ufname = $efede3['message']['from']['first_name'];
$uname = $efede3['message']['from']['last_name'];
$ulogin = $efede3['message']['from']['username'];
$uid = $efede3['message']['from']['id'];
$user_id = $efede3['message']['from']['id'];

//reply info
$sreply = $efede3['message']['reply_to_message']['text'];

$fromid =  $efede3['message'] ['reply_to_message'] ['from']['id'];
$fname =  $efede3['message'] ['reply_to_message'] ['from']['first_name'];
$msgrep =  $efede3['message'] ['reply_to_message'] ['message_id'];
$fsname =  $efede3['message'] ['reply_to_message'] ['from']['last_name'];
$fusername =  $efede3['message'] ['reply_to_message'] ['from']['username'];

//new_chat_participant info
$nfname = $efede3['message']['new_chat_participant']['first_name'];
$nbot = $efede3['message']['new_chat_participant']['is_bot'];
$nlogin = $efede3['message']['new_chat_participant']['username'];
$nid = $efede3['message']['new_chat_participant']['id'];

// channel post
$chid = $efede3['channel_post']['chat']['id'];
$chtitle = $efede3['channel_post']['chat']['title'];
$chturi = $efede3['channel_post']['chat']['type'];
$chusername = $efede3['channel_post']['chat']['username'];

$chwhois = $efede3['channel_post']['author_signature'];
$chdate = $efede3['channel_post']['date'];
$chpost = $efede3['channel_post']['message_id'];
$chtext = $efede3['channel_post']['text'];

// contact 
$contact = $efede3['message']['contact'];
$connumber = $efede3['message']['contact']['phone_number'];
$conID = $efede3['message']['contact']['user_id'];

// Test CallBack
$callback_query = $efede3['callback_query'];
$Callback_ID = $efede3['callback_query']['id'];
$Callback_msgID = $efede3['callback_query']['message']['message_id'];
$Callback_FromID = $efede3['callback_query']['from']['id'];
$Callback_ChatID = $efede3['callback_query']['message']['chat']['id'];

$photo = $efede3["message"]['reply_to_message']["photo"];


$home_ru = [["🔄 Обмен"],["📊 Курс/💰 Резерв","📂 Данные"],["💱 Обмены","📞 Связь"],["👥 Реферал","💬 О нас ⁉️"]];
$home_uz = [["🔄 Almashtirish"],["📊Kurs / 💰Zahira","📂 Ma'lumotlar"],["👥 Referal","💬 Biz haqimizda ⁉️"],["💱 Almashuvlar","📞 Aloqa"]];


//$home_uz = [["🔄 Almashtirish"],["📊Kurs / 💰Zahira","📂 Ma'lumotlar"],["👥 Referal","💬 Biz haqimizda ⁉️"],["💱 Almashuvlar","📞 Aloqa"],["🕘 Ish Vaqti"]];
//$home_ru = [["🔄 Обмен"],["📊 Курс/💰 Резерв","📂 Данные"],["💱 Обмены","📞 Связь"],["👥 Реферал","💬 О нас ⁉️"],["🕘 График работы"]];

$change_uz = [["🗂Mening almashuvlarim","📃Barcha almashuvlar"],["🔙Bosh menu"]];
$change_ru = [["🗂Мои обмены","📃Все операции"],["🔙Главное меню"]];

$danny_uz = [["🗂 Hamyonlaringiz","👤 F.I.O o'zgartirish"],["🌐 Tilni o'zgartirish"],["🔙Bosh menu"]];
$danny_ru = [["🗂 Ваши Кошельки","👤 Ф.И.О изменить"],["🌐 Изменить язык"],["🔙Главное меню"]];
//new 

$hamyon_uz = [["➕UZCARD","➕YANDEX"],["➕WMZ","➕QIWI"],["➕FORMULA55"],["🔙Bosh menu"]];
$hamyon_ru = [["➕UZCARD","➕YANDEX"],["➕WMZ","➕QIWI"],["➕FORMULA55"],["🔙Главное меню"]];


/*
if (!(isset($channel_post)) && $turi == 'private') {

  // logging JSON
  $content = ['chat_id' => $logjson, 'from_chat_id' => $chat_id, 'message_id' => $mesid];
  $send = $telegram->forwardMessage($content);
}

*/
if ($callback_query !== null && $callback_query != '') {
    $data = $efede3['callback_query']['data'];

    $inreg = explode("#",$data);

    $intype  = $inreg[0];
    $id  = $inreg[1];
    $tree  = $inreg[2];
    $foo  = $inreg[3];


    if ($intype == 'nowork') {
      $reply = "Vaqtincha mavjud emas";
      $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
      $telegram->answerCallbackQuery($content);
      exit;
    }

    if ($intype == 'paynet1') {
      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if ($tree == 'ru') {
        $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
        $mtext = "*Обращайтесь на @admin_bog'lanish!*";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;
      } elseif ($tree == 'uz') {

        $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
        $mtext = "*@admin_bog'lanish ga murojaat qiling!*";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;
      }
      exit;
    }

    if ($intype == 'naqd') {
      if ($tree == 'ru') {
        $reply = "СКОРО!";
        $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
        $telegram->answerCallbackQuery($content);
        exit;
      } elseif ($tree == 'uz') {

        $reply = "TEZ KUNDA!";
        $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
        $telegram->answerCallbackQuery($content);
        exit;
      }
      exit;
    }
    
    if ($intype == 'select') {
      if ($tree == 'ru') {
        $reply = "Oldin ⏫berishni tanlang";
        $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
        $telegram->answerCallbackQuery($content);
        exit;
      } elseif ($tree == 'uz') {

        $reply = "Oldin ⏫berishni tanlang";
        $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
        $telegram->answerCallbackQuery($content);
        exit;
      }
      exit;
    }

    if ($intype == 'setlang') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if ($id == 'ru') {
        file_put_contents("lang/$Callback_FromID.lang", 'ru');
        /*
        $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
        $mtext = "@ObmenBot - это сервис по обмену валют на территории Узбекистана.";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        */

        //send phone number
        $keyb = '{"keyboard":[[{"text":"Отправьте номер","request_contact":true}]],"one_time_keyboard":true,"resize_keyboard":true}';
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => "*Пожалуйста отправьте номер телефона!!*",'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;
      } elseif ($id == 'uz') {
        file_put_contents("lang/$Callback_FromID.lang", 'uz');
        /*
        $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
        $mtext = "@ObmenBot  - Bu, O'zbekiston hududidagi valyuta ayirboshlash xizmati.";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        */

        //send phone number
        $keyb = '{"keyboard":[[{"text":"📲 Telefon raqamni yuborish","request_contact":true}]],"one_time_keyboard":true,"resize_keyboard":true}';
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => "*Iltimos telefon raqamingizni yuboring!*",'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;
      }
      exit;
    }

    if ($intype == 'setlang2') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if ($id == 'ru') {
        file_put_contents("lang/$Callback_FromID.lang", 'ru');

        $keyb = $telegram->buildKeyBoard($danny_ru, $onetime = false, $resize = true);
        $mtext = "Главное меню:";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        exit;
      } elseif ($id == 'uz') {
        file_put_contents("lang/$Callback_FromID.lang", 'uz');

        $keyb = $telegram->buildKeyBoard($danny_uz, $onetime = false, $resize = true);
        $mtext = "Bosh menu:";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        exit;
      }
      exit;
    }

    if ($intype == 'home') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if ($id == 'ru') {

        $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
        $mtext = "Главное меню";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
        $telegram->sendMessage($content);
      } elseif ($id == 'uz') {

        $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
        $mtext = "Bosh menu";
        $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
        $telegram->sendMessage($content);
      }
      exit;
    }

    if ($intype == 'delinfo') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if (file_exists("user/$Callback_FromID.UZCARD")) {
        unlink("user/$Callback_FromID.UZCARD");
      }

      if (file_exists("user/$Callback_FromID.YANDEX")) {
        unlink("user/$Callback_FromID.YANDEX");
      }

      if (file_exists("user/$Callback_FromID.QIWI")) {
        unlink("user/$Callback_FromID.QIWI");
      }

      if (file_exists("user/$Callback_FromID.WMZ")) {
        unlink("user/$Callback_FromID.WMZ");
      }

      if (file_exists("user/$Callback_FromID.FORMULA55")) {
        unlink("user/$Callback_FromID.FORMULA55");
      }

        $mtext = "Все ваши данные удалены.";
        $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
        $telegram->sendMessage($content);

      exit;
    }

    if ($intype == 'infofull') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if ($id == 'ru') {

        $mtext = "Партнерская программа. \nЭта функция поможет вам зарабатывать на привлечении партнеров. Для приглашения партнеров используйте ссылку выданную вам. Вы будите получать 10% от дохода обменника за каждую успешную заявку вашего партнера. Доход обменника равен разнице курсов(т.е Продажа = 100 UZS а Покупка = 120 UZS то доход обменника составит 20 UZS) \n\nБасланс можно вывести: \nНа счет мобильного телефона \nНа Карту UZCARD";
        $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
        $telegram->sendMessage($content);
      } elseif ($id == 'uz') {

        $mtext = "Нamkorlik dasturi. \nBu dastur sheriklarni jalb qilish orqali pul topishingizga yordam beradi. Нamkorlarni taklif qilish uchun sizga taqdim etilgan taklif-linkidan foydalaning. Sizning hamkoringizning har bir muvaffaqiyatli buyurtmasi uchun botning daromadidan 10% olasiz. Bot daromadi kurslar orasidagi farqga teng (ya'ni Sotish 100 uzs Olish esa 120 uzs bo'lsa botning daromadi 20 uzsga teng bo'ladi). \n\nHisobingizdagi mablag'ni yechish yollari: \nMobil telefon raqamiga \nUZCARD karta hisobiga.";
        $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
        $telegram->sendMessage($content);
      }
      exit;
    }

    if ($intype == 'cutref') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);
      
      if ($id >= '10000') {

        if ($tree == 'ru') {


        } elseif ($tree == 'uz') {


        }
      } else {

        if ($tree == 'ru') {

          $mtext = "Минимальная сумма вывода 10000 UZS";
          $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
          $telegram->sendMessage($content);
        } elseif ($tree == 'uz') {

          $mtext = "Yechish uchun eng kam mablag' miqdori 10000 UZS";
          $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
          $telegram->sendMessage($content);
        }
      }
      exit;
    }

    if ($intype == 'refcount') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if (file_exists("user/$Callback_FromID.ref")) {
        $hisob = file_get_contents("user/$Callback_FromID.ref");

        $hisob = explode("\n", $hisob);
        $hisob = count($hisob); $hisob = $hisob - 1;

      } else { $hisob = '0'; }

      if ($id == 'ru') {

        $mtext = "Число ваших рефералов: $hisob";
        $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
        $telegram->sendMessage($content);
      } elseif ($id == 'uz') {

        $mtext = "Sizning referallaringiz soni: $hisob";
        $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
        $telegram->sendMessage($content);
      }
      exit;
    }

    if ($intype == 'zahira') {

      if ($id == 'ru') {

        if (file_exists("data/UZCARD.zahira")) {
          $UZCARD = file_get_contents("data/UZCARD.zahira");
        } else { $UZCARD = '0'; }
        if (file_exists("data/YANDEX.zahira")) {
          $YANDEX = file_get_contents("data/YANDEX.zahira");
        } else { $YANDEX = '0'; }
        if (file_exists("data/QIWI.zahira")) {
          $QIWI = file_get_contents("data/QIWI.zahira");
        } else { $QIWI = '0'; }
        if (file_exists("data/WMZ.zahira")) {
          $WMZ = file_get_contents("data/WMZ.zahira");
        } else { $WMZ = '0'; }
        if (file_exists("data/FORMULA55.zahira")) {
          $FORMULA55 = file_get_contents("data/FORMULA55.zahira");
        } else { $FORMULA55 = '0'; }

        $salom = "💰 Резерв Обменника \n UZCARD = $UZCARD UZS \n QIWI RUB = $QIWI RUB \n YANDEX RUB = $YANDEX RUB \n WMZ = $WMZ USD \n FORMULA55 = $FORMULA55  RUB \n\n 🤖 Бот: @$bot_name";

        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("🔰 Показать Курс", $url = '', $callback_data = 'kurs#ru'),
          ]
        ];
        $keyb = $telegram->buildInlineKeyBoard($option);

        $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $salom];
        $telegram->editMessageText($content);
      } elseif ($id == 'uz') {

        if (file_exists("data/UZCARD.zahira")) {
          $UZCARD = file_get_contents("data/UZCARD.zahira");
          if (mb_stripos($UZCARD,".") !== false) {
            $UZCARD = explode(".", $UZCARD);
            $float_numn = substr ($UZCARD[1], 0, 2);
            $UZCARD = "$UZCARD[0].$float_numn";
          }
        } else { $UZCARD = '0'; }
        if (file_exists("data/YANDEX.zahira")) {
          $YANDEX = file_get_contents("data/YANDEX.zahira");
          if (mb_stripos($YANDEX,".") !== false) {
            $YANDEX = explode(".", $YANDEX);
            $float_numn = substr ($YANDEX[1], 0, 2);
            $YANDEX = "$YANDEX[0].$float_numn";
          }
        } else { $YANDEX = '0'; }
        if (file_exists("data/QIWI.zahira")) {
          $QIWI = file_get_contents("data/QIWI.zahira");
          if (mb_stripos($QIWI,".") !== false) {
            $QIWI = explode(".", $QIWI);
            $float_numn = substr ($QIWI[1], 0, 2);
            $QIWI = "$QIWI[0].$float_numn";
          }
        } else { $QIWI = '0'; }
        if (file_exists("data/WMZ.zahira")) {
          $WMZ = file_get_contents("data/WMZ.zahira");
          if (mb_stripos($WMZ,".") !== false) {
            $WMZ = explode(".", $WMZ);
            $float_numn = substr ($WMZ[1], 0, 2);
            $WMZ = "$WMZ[0].$float_numn";
          }
        } else { $WMZ = '0'; }
        if (file_exists("data/FORMULA55.zahira")) {
          $FORMULA55 = file_get_contents("data/FORMULA55.zahira");
          if (mb_stripos($FORMULA55,".") !== false) {
            $FORMULA55 = explode(".", $FORMULA55);
            $float_numn = substr ($FORMULA55[1], 0, 2);
            $FORMULA55 = "$FORMULA55[0].$float_numn";
          }
        } else { $FORMULA55 = '0'; }

        $salom = "💰Obmennik Zahirasi \n UZCARD = $UZCARD UZS \n QIWI RUB = $QIWI RUB \n YANDEX RUB = $YANDEX RUB \n WMZ = $WMZ USD \n FORMULA55 = $FORMULA55  RUB \n\n 🤖 Bot: @$bot_name";

        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("🔰 Kursni ko'rish", $url = '', $callback_data = 'kurs#uz'),
          ]
        ];
        $keyb = $telegram->buildInlineKeyBoard($option);

        $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $salom];
        $telegram->editMessageText($content);
      }
      exit;
    }

    if ($intype == 'berish') {
      

      if ($tree == 'uz') { 
        if ($id == 'UZCARD') {
            
          $fdmarkup = ['text' => '✅ ⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#uz";
          $UZCARD[] = $fdmarkup;

          $fdmarkup = ['text' => '▫️'];
          $fdmarkup['callback_data'] = "jim#UZCARD#uz";
          $UZCARD[] = $fdmarkup;

          $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '⏬YANDEX RUB',];
          $fdmarkup2['callback_data'] = "olish#YANDEX#uz#UZCARD";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#uz";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '⏬WMZ',];
          $fdmarkup3['callback_data'] = "olish#WMZ#uz#UZCARD";
          $WMZ[] = $fdmarkup3;


          $fdmarkup4 = ['text' => '⏫QIWI RUB',];
          $fdmarkup4['callback_data'] = "berish#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '⏬QIWI RUB',];
          $fdmarkup4['callback_data'] = "olish#QIWI#uz#UZCARD";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '⏬FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "olish#FORMULA55#uz#UZCARD";
          $FORMULA55[] = $fdmarkup5;

        } elseif ($id == 'YANDEX') {
          $fdmarkup = ['text' => '⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#uz";
          $UZCARD[] = $fdmarkup;


          $fdmarkup = ['text' => '⏫UZCARD'];
          $fdmarkup['callback_data'] = "olish#UZCARD#uz#YANDEX";
          $UZCARD[] = $fdmarkup;

          $fdmarkup2 = ['text' => '✅ ⏫YANDEX',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '▫️',];
          $fdmarkup2['callback_data'] = "jim#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#uz";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '▫️',];
          $fdmarkup3['callback_data'] = "jim#WMZ#uz";
          $WMZ[] = $fdmarkup3;


          $fdmarkup4 = ['text' => '⏫QIWI RUB',];
          $fdmarkup4['callback_data'] = "berish#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '▫️',];
          $fdmarkup4['callback_data'] = "jim#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '▫️',];
          $fdmarkup5['callback_data'] = "jim#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;
        } elseif ($id == 'WMZ') {

          $fdmarkup = ['text' => '⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#uz";
          $UZCARD[] = $fdmarkup;


          $fdmarkup = ['text' => '⏫UZCARD'];
          $fdmarkup['callback_data'] = "olish#UZCARD#uz#WMZ";
          $UZCARD[] = $fdmarkup;
      

          $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '▫️',];
          $fdmarkup2['callback_data'] = "jim#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '✅ ⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#uz";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '▫️',];
          $fdmarkup3['callback_data'] = "jim#WMZ#uz";
          $WMZ[] = $fdmarkup3;


          $fdmarkup4 = ['text' => '⏫QIWI RUB',];
          $fdmarkup4['callback_data'] = "berish#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '▫️',];
          $fdmarkup4['callback_data'] = "jim#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '▫️',];
          $fdmarkup5['callback_data'] = "jim#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;
        } elseif ($id == 'QIWI') {
          $fdmarkup = ['text' => '⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#uz";
          $UZCARD[] = $fdmarkup;

          $fdmarkup = ['text' => '⏫UZCARD'];
          $fdmarkup['callback_data'] = "olish#UZCARD#uz#QIWI";
          $UZCARD[] = $fdmarkup;

          $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '▫️',];
          $fdmarkup2['callback_data'] = "jim#YANDEX#uz";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#uz";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '▫️',];
          $fdmarkup3['callback_data'] = "jim#WMZ#uz";
          $WMZ[] = $fdmarkup3;

          $fdmarkup4 = ['text' => '✅ ⏫QIWI',];
          $fdmarkup4['callback_data'] = "berish#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '▫️',];
          $fdmarkup4['callback_data'] = "jim#QIWI#uz";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '▫️',];
          $fdmarkup5['callback_data'] = "jim#FORMULA55#uz";
          $FORMULA55[] = $fdmarkup5;
        } elseif ($id == 'FORMULA55') {

          if ($tree == 'uz') {          
            $suz = "@admin_bog'lanish ga murojaat qiling.";
          } elseif ($tree == 'ru') {          
            $suz = "Пожалуйста, свяжитесь с @admin_bog'lanish";
          }

          $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $suz];
          $telegram->editMessageText($content);
          exit;
        } 

        $fdmarkup6 = ['text' => 'PAYNET UZS(cash to card)♻️QIWI RUB',];
        $fdmarkup6['callback_data'] = "paynet1#PAYNET#uz";
        $PAYNET1[] = $fdmarkup6;

        $fdmarkup7 = ['text' => '♻️NAQT PULGA',];
        $fdmarkup7['callback_data'] = "naqd#NAQT#uz";
        $NAQD1[] = $fdmarkup7;      
      } elseif ($tree == 'ru') {          

        if ($id == 'UZCARD') {
            
          $fdmarkup = ['text' => '✅ ⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#ru";
          $UZCARD[] = $fdmarkup;

          $fdmarkup = ['text' => '▫️'];
          $fdmarkup['callback_data'] = "jim#UZCARD#ru";
          $UZCARD[] = $fdmarkup;

          $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '⏬YANDEX RUB',];
          $fdmarkup2['callback_data'] = "olish#YANDEX#ru#UZCARD";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#ru";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '⏬WMZ',];
          $fdmarkup3['callback_data'] = "olish#WMZ#ru#UZCARD";
          $WMZ[] = $fdmarkup3;


          $fdmarkup4 = ['text' => '⏫QIWI RUB',];
          $fdmarkup4['callback_data'] = "berish#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '⏬QIWI RUB',];
          $fdmarkup4['callback_data'] = "olish#QIWI#ru#UZCARD";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '⏬FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "olish#FORMULA55#ru#UZCARD";
          $FORMULA55[] = $fdmarkup5;

        } elseif ($id == 'YANDEX') {
          $fdmarkup = ['text' => '⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#ru";
          $UZCARD[] = $fdmarkup;


          $fdmarkup = ['text' => '⏫UZCARD'];
          $fdmarkup['callback_data'] = "olish#UZCARD#ru#YANDEX";
          $UZCARD[] = $fdmarkup;

          $fdmarkup2 = ['text' => '✅ ⏫YANDEX',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '▫️',];
          $fdmarkup2['callback_data'] = "jim#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#ru";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '▫️',];
          $fdmarkup3['callback_data'] = "jim#WMZ#ru";
          $WMZ[] = $fdmarkup3;


          $fdmarkup4 = ['text' => '⏫QIWI RUB',];
          $fdmarkup4['callback_data'] = "berish#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '▫️',];
          $fdmarkup4['callback_data'] = "jim#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '▫️',];
          $fdmarkup5['callback_data'] = "jim#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;
        } elseif ($id == 'WMZ') {

          $fdmarkup = ['text' => '⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#ru";
          $UZCARD[] = $fdmarkup;


          $fdmarkup = ['text' => '⏫UZCARD'];
          $fdmarkup['callback_data'] = "olish#UZCARD#ru#WMZ";
          $UZCARD[] = $fdmarkup;
      

          $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '▫️',];
          $fdmarkup2['callback_data'] = "jim#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '✅ ⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#ru";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '▫️',];
          $fdmarkup3['callback_data'] = "jim#WMZ#ru";
          $WMZ[] = $fdmarkup3;


          $fdmarkup4 = ['text' => '⏫QIWI RUB',];
          $fdmarkup4['callback_data'] = "berish#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '▫️',];
          $fdmarkup4['callback_data'] = "jim#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '▫️',];
          $fdmarkup5['callback_data'] = "jim#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;
        } elseif ($id == 'QIWI') {
          $fdmarkup = ['text' => '⏫UZCARD'];   
          $fdmarkup['callback_data'] = "berish#UZCARD#ru";
          $UZCARD[] = $fdmarkup;

          $fdmarkup = ['text' => '⏫UZCARD'];
          $fdmarkup['callback_data'] = "olish#UZCARD#ru#QIWI";
          $UZCARD[] = $fdmarkup;

          $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
          $fdmarkup2['callback_data'] = "berish#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup2 = ['text' => '▫️',];
          $fdmarkup2['callback_data'] = "jim#YANDEX#ru";
          $YANDEX[] = $fdmarkup2;

          $fdmarkup3 = ['text' => '⏫WMZ',];
          $fdmarkup3['callback_data'] = "berish#WMZ#ru";
          $WMZ[] = $fdmarkup3;

          $fdmarkup3 = ['text' => '▫️',];
          $fdmarkup3['callback_data'] = "jim#WMZ#ru";
          $WMZ[] = $fdmarkup3;

          $fdmarkup4 = ['text' => '✅ ⏫QIWI',];
          $fdmarkup4['callback_data'] = "berish#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup4 = ['text' => '▫️',];
          $fdmarkup4['callback_data'] = "jim#QIWI#ru";
          $QIWI[] = $fdmarkup4;

          $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
          $fdmarkup5['callback_data'] = "berish#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;

          $fdmarkup5 = ['text' => '▫️',];
          $fdmarkup5['callback_data'] = "jim#FORMULA55#ru";
          $FORMULA55[] = $fdmarkup5;
        } elseif ($id == 'FORMULA55') {

          if ($tree == 'uz') {          
            $suz = "@admin_bog'lanish ga murojaat qiling.";
          } elseif ($tree == 'ru') {          
            $suz = "Пожалуйста, свяжитесь с @admin_bog'lanish";
          }

          $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $suz];
          $telegram->editMessageText($content);
          exit;
        }

        $fdmarkup6 = ['text' => 'PAYNET UZS(cash to card)♻️QIWI RUB',];
        $fdmarkup6['callback_data'] = "paynet1#PAYNET#ru";
        $PAYNET1[] = $fdmarkup6;

        $fdmarkup7 = ['text' => '♻️НАЛИЧНЫМИ',];
        $fdmarkup7['callback_data'] = "naqd#NAQT#ru";
        $NAQD1[] = $fdmarkup7;
      }
      //
      $fd2 = [];
      $fd2[] = $UZCARD;
      $fd2[] = $YANDEX;
      $fd2[] = $WMZ;
      $fd2[] = $QIWI;
      $fd2[] = $FORMULA55;

      $fd2[] = $PAYNET1;
      $fd2[] = $NAQD1;     
      $keyb = $telegram->buildInlineKeyBoard($fd2);
      if ($tree == 'uz') {          
        $suz = "Valyutalarni tanlang: *⏫Berish* va *⏬Olish*";
      } elseif ($tree == 'ru') {          
        $suz = "Выберите валюты для обмена: *⏫отдача* и *⏬получения*";
      }

      $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
      $telegram->editMessageText($content);
      exit;
    }

    if ($intype == 'olish') {

      $shah = file_get_contents("data/$id.zahira");
      if ($shah >= 1) {
        // run
      } else {
        $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
        $telegram->deletemessage($content);

        if ($tree == 'uz') {      
          $mtext = "Siz tanlagan yo'nalishda almashinuv qilish imkoni hozircha yoq.";
        } elseif ($tree == 'ru') {          
          $mtext = "В данный момент создать заявку на обмен по выбранному вами направлению невозможно.";
        }

        $content = ['chat_id' => $Callback_FromID, 'text' => $mtext];
        $telegram->sendMessage($content);
        exit;
      }
      // END zahirani tekshirish

      if (!file_exists("user/$Callback_FromID.$id") || !file_exists("user/$Callback_FromID.$foo")) {

        $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
        $telegram->deletemessage($content);

        if ($tree == 'uz') {      
          $reply = "Siz tanlagan yo'nalishda almashuvni amalga oshirish uchun oldin o'z hamyon raqamlaringizni  '📂 Ma'lumotlar' bo'limiga kiriting";
        } elseif ($tree == 'ru') {          
          $reply = "Для создания заявок по данному направлению сначала введите номера кошельков а раздел '📂 Данные'";
        }
        $content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $reply, 'show_alert' => true];
        $telegram->answerCallbackQuery($content);
        exit;
      }
      //END user info borligini aniqlash
      $kod = getUID();
      $berish = file_get_contents("user/$Callback_FromID.$foo");
      $olish = file_get_contents("user/$Callback_FromID.$id");

      /*
      if ($tree == 'uz') { 
        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("Berishni kiritish * $foo", $url = '', $callback_data = "inberish#uz#$foo"),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Olishni kiritish * $id", $url = '', $callback_data = "inolish#uz#$id"),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Bekor qilish", $url = '', $callback_data = 'paycancel#uz'),
          ]
        ];

        $suz = "Almashuv: \nID: $kod \nBerish: * $foo \nOlish: * $id \n$foo: $berish \n$id: $olish";
      } elseif ($tree == 'ru') {

        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("Отдаеть * кол-во $foo", $url = '', $callback_data = "inberish#ru#$foo"),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Получить * кол-во $id", $url = '', $callback_data = "inolish#ru#$id"),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Отменить", $url = '', $callback_data = "paycancel#ru"),
          ]
        ];

        $suz = "Ваша заявка: \nID: $kod \nОтдаете: * $foo \nПолучаете: * $id \n$foo: $berish \n$id: $olish";
      }
      */
        if ($foo == 'UZCARD') {
          //$birlik = 'SUM';
        } elseif ($foo == 'YANDEX') {
          $ikkilefede = 'RUB';
        }  elseif ($foo == 'QIWI') {
          $ikkilefede = 'RUB';
        }  elseif ($foo == 'WMZ') {
          $ikkilefede = 'USD';
        }

        if ($id == 'UZCARD') {
          //$birlik = 'SUM';
        } elseif ($id == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($id == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($id == 'WMZ') {
          $birlik = 'USD';
        }

      if ($tree == 'uz') { 
        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("*Berish miqdorini kiritish", $url = '', $callback_data = "inberish#uz#$foo"),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Bekor qilish", $url = '', $callback_data = 'paycancel#uz'),
          ]
        ];

        $suz = "*Almashuv:* \n*ID:* $kod \n*Berasiz:* $foo $ikkilefede\n*Olasiz:* $id $birlik \n*$foo:* $berish \n*$id $birlik:* $olish";
      } elseif ($tree == 'ru') {

        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("*Написать сумму отдачи", $url = '', $callback_data = "inberish#ru#$foo"),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Отменить", $url = '', $callback_data = "paycancel#ru"),
          ]
        ];

        $suz = "*Ваша заявка:* \n*ID:* $kod \n*Отдаете: * $foo $ikkilefede \n*Получаете:* $id $birlik \n*$foo $ikkilefede:* $berish \n*$id $birlik:* $olish";
      }


      file_put_contents("temp/$Callback_FromID.pay", "$Callback_FromID||$kod||$foo||$id");

      $keyb = $telegram->buildInlineKeyBoard($option);

      $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
      $telegram->editMessageText($content);
      exit;
    }

    if ($intype == 'inberish') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);
      
      $mak = file_get_contents("data/$tree.zahira");
      if (mb_stripos($mak,".") !== false) {
        $mak = explode(".", $mak);
        $float_numn = substr ($mak[1], 0, 2);
        $mak = "$mak[0].$float_numn";
      }

      if ($tree == 'UZCARD') {
        $min = '6000';
      } elseif ($tree == 'YANDEX') {
        $min = '50';
      }  elseif ($tree == 'QIWI') {
        $min = '50';
      }  elseif ($tree == 'WMZ') {
        $min = '1';
      }

      if ($id == 'ru') {
        if ($tree == 'UZCARD') {
          $birlik = 'SUM';
        } elseif ($tree == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($tree == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($tree == 'WMZ') {
          $birlik = 'USD';
        }

        $salom = "<b>Введите сумму отдачи!</b> \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";
      } elseif ($id == 'uz') {
        if ($tree == 'UZCARD') {
          $birlik = 'SUM';
        } elseif ($tree == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($tree == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($tree == 'WMZ') {
          $birlik = 'USD';
        }

        $salom = "<b>Berish miqdorini kiriting!</b> \n<b>Minimal</b> <code> $min </code> $tree $birlik \n<b>Maksimal</b> <code> $mak </code> $birlik";
      }


      $keyb = $telegram->buildForceReply($selective=false);
      $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => "$salom",'parse_mode' => 'html'];
      $telegram->sendMessage($content);

      
      //$content = ['message_id' => $Callback_msgID, 'reply_markup' => $keyb, 'chat_id' => $Callback_FromID, 'text' => $salom, 'parse_mode' => 'html'];
      //$telegram->editMessageText($content);
      exit;
    }
    //END berishni kiritish

    if ($intype == 'inolish') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);
      
      $mak = file_get_contents("data/$tree.zahira");
      if (mb_stripos($mak,".") !== false) {
        $mak = explode(".", $mak);
        $float_numn = substr ($mak[1], 0, 2);
        $mak = "$mak[0].$float_numn";
      }

      if ($tree == 'UZCARD') {
        $min = '6000';
      } elseif ($tree == 'YANDEX') {
        $min = '50';
      }  elseif ($tree == 'QIWI') {
        $min = '50';
      }  elseif ($tree == 'WMZ') {
        $min = '1';
      }

      if ($id == 'ru') {
        if ($tree == 'UZCARD') {
          $birlik = 'SUM';
        } elseif ($tree == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($tree == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($tree == 'WMZ') {
          $birlik = 'USD';
        }

        $salom = "Введите сумму получения в $birlik \nМинимум <code> $min </code> $birlik \nМаксимум <code> $mak </code> $birlik";
      } elseif ($id == 'uz') {
        if ($tree == 'UZCARD') {
          $birlik = 'SUM';
        } elseif ($tree == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($tree == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($tree == 'WMZ') {
          $birlik = 'USD';
        }

        $salom = "Olish miqdorini $birlik'da kiriting \nMinimal <code> $min </code> $birlik \nMaksimal <code> $mak </code> $birlik";
      }


      $keyb = $telegram->buildForceReply($selective=false);
      $content = ['chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => "$salom",'parse_mode' => 'html'];
      $telegram->sendMessage($content);

      
      //$content = ['message_id' => $Callback_msgID, 'reply_markup' => $keyb, 'chat_id' => $Callback_FromID, 'text' => $salom, 'parse_mode' => 'html'];
      //$telegram->editMessageText($content);
      exit;
    }
    //END olishni kiritish
    
    if ($intype == 'paycancel') {
      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID-2];
      $telegram->deletemessage($content);

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID-1];
      $telegram->deletemessage($content);
      
      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);
      unlink("temp/$Callback_FromID.pay");
      if ($id == 'ru') {
        $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
        $salom = "Ваша заявка отменена";
      } elseif ($id == 'uz') {
        $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
        $salom = "To'lov bekor qilindi.";
      }

      $content = ['reply_markup' => $keyb, 'chat_id' => $Callback_FromID, 'text' => $salom];
      $telegram->sendMessage($content);
      exit;
    }
    //END OtmenPopolnit schot

    if ($intype == 'paycheck') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);


      $holat = file_get_contents("temp/$Callback_FromID.pay");
      $qism = explode("||", $holat);
      $kod = $qism[1];
      $foo = $qism[2];
      $olishh = $qism[3];
      $berish = $qism[4];
      $olish = $qism[5];

        if ($foo == 'UZCARD') {
          //$birlik = 'SUM';

          $tizim = "ℹ️ PAYME.UZ yoki ℹ️ CLICK.UZ";
          $raqam = '8600 1234 1234 1234';
          $namecrad = 'Palonchaev Pistoncha';
          if ($id == 'uz') { $pay = "E'tibor bering! Boshqa to'lov tizimlaridan (OSON)dan qilingan to'lovlar bir necha soatgacha cho'zilishi mumkin"; } elseif ($id == 'ru') { $pay = "Внимания! Переводы из других ПС как (OSON) могут задержаться до нескольких часов"; }
        } elseif ($foo == 'YANDEX') {
          $birlik = 'RUB';
          $tizim = "MONEY.YANDEX.RU";
          $raqam = '4444444444';
        }  elseif ($foo == 'QIWI') {
          $birlik = 'RUB';
          $tizim = "QIWI.COM;";
          $raqam = '+99890 0000000';
        }  elseif ($foo == 'WMZ') {
          $birlik = 'USD';

          $tizim = "WEBMONEY.COM";
          $raqam = 'Z000000000000';
        }

      if ($id == 'uz') { 
        $keyba = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);

        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("To'lov qildim ✅", $url = '', $callback_data = 'payokey#uz'),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Bekor qilish 🚫", $url = '', $callback_data = 'paycancel#uz'),
          ]
        ];

        $suz = "👆Ko'chirib olish uchun \n\n*Almashuvingiz muvaffaqiyatli bajarilishi uchun quyidagi harakatlarni amalga oshiring:* \n\n1)$tizim - tizimidan ro'yhatdan o'ting; \n2) *Pastda ko'rsatilgan* to'lov miqdorni - ($raqam) $namecrad karta raqamiga o'tkazing; \n3) «To'lov qildim ✅» tugmasini bosing; \n4) Operator tomonidan almashuv tasdiqlanishini kuting. \n\n *To'lov miqdori:* $berish $foo $birlik \n\n*Ushbu almashuv operator tomonidan navbati bilan amalga oshiriladi va 2 daqiqadan 1 soatgacha davom etadi.* \n\n$pay";
      } elseif ($id == 'ru') {

        $keyba = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
        
        $option = [
          [
            $key = $telegram->buildInlineKeyBoardButton("Я оплатил ✅", $url = '', $callback_data = 'payokey#ru'),
          ],[
            $key = $telegram->buildInlineKeyBoardButton("Отменить 🚫", $url = '', $callback_data = 'paycancel#ru'),
          ]
        ];

        $suz = "👆Копировать \n\n*Для успешной обработки вашей заявки пожалуйста выполните следующие действия:* \n\n1) Войдите в приложение $tizim \n2) Переведите указанную *ниже сумму* на номер карты - ($raqam) $namecrad; \n3) Нажмите на кнопку «Я оплатил ✅»; \n4) Ожидайте обработку заявки оператором. \n\n *Сумма платежа:* $berish $foo $birlik \n\n*Данная операция производится оператором по очереди ручном режиме и занимает от 2 до 60 минут в рабочее время.* \n\n$pay";
      }

      $salom = $raqam;
      $content = ['reply_markup' => $keyba, 'chat_id' => $Callback_FromID, 'text' => $salom,'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);

      $keyb = $telegram->buildInlineKeyBoard($option);

      $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_FromID, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);
      exit;
    }
    //END PAYCHECK

    if ($intype == 'payokey') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => "$Callback_msgID-1"];
      $telegram->deletemessage($content);

      $content = ['chat_id' => $Callback_FromID, 'message_id' => "$Callback_msgID-3"];
      $telegram->deletemessage($content);

      $holat = file_get_contents("temp/$Callback_FromID.pay");
      $qism = explode("||", $holat);
      $kod = $qism[1];
      $foo = $qism[2];
      $olishh = $qism[3];
      $berish = $qism[4];
      $olish = $qism[5];

        
        if ($foo == 'UZCARD') {
          //$birlik = 'SUM';
        } elseif ($foo == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($foo == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($foo == 'WMZ') {
          $birlik = 'USD';
        }
        

        if ($olishh == 'UZCARD') {
          //$birlik33 = 'SUM';
        } elseif ($olishh == 'YANDEX') {
          $birlik33 = 'RUB';
        }  elseif ($olishh == 'QIWI') {
          $birlik33 = 'RUB';
        }  elseif ($olishh == 'WMZ') {
          $birlik33 = 'USD';
        }

      if ($id == 'ru') { 

        $suz = "Ожидайте обработку заявки оператором.";
        $suzpay = "*Ваш номер заказа id:$kod отправлен операторам, пожалуйста подождите подтверждения!*";
      } elseif ($id == 'uz') {

        $suz = "Operator javobini kutib turing.";
        $suzpay = "*Sizning id:$kod raqamli almashuv buyurtmangiz operatorlarga yuborildi, iltimos tasdiqlanishini kuting!*";
      }

      //START send Admin Chek

      $content = ['chat_id' => $Callback_FromID, 'text' => $suzpay, 'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);
      //END SEND USER
      $nomer = file_get_contents("phone/$Callback_FromID.phone");
      $ism = file_get_contents("name/$Callback_FromID.name");


      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("To'lov bajarildi", $url = '', $callback_data = "payok#$Callback_FromID#$id#$kod"),
        ],[
          $key = $telegram->buildInlineKeyBoardButton("To'lov tasdiqlanmadi", $url = '', $callback_data = "payno#$Callback_FromID#$id#$kod"),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $foohisob = file_get_contents("user/$Callback_FromID.$foo");
      $olishhisob = file_get_contents("user/$Callback_FromID.$olishh");

      $suz2 = "<b>Yangi to'lov keldi:</b> \n<b>ID:</b> $kod \n<b>Telegram:</b> <a href='tg://user?id=$Callback_FromID'>$Callback_FromID</a> \n<b>Telegram 📱:</b> $nomer\n<b>Telegram 🆔:</b> $Callback_FromID\n<b>F.I.O:</b> $ism \n<b>Sizga o'tqazdi:</b> $berish $foo $birlik \n<b>Berishingiz kerak:</b> $olish $olishh $birlik33 \n<b>$foo $birlik:</b> $foohisob \n<b>$olishh $birlik33:</b> $olishhisob";

      $content = ['chat_id' => $admin, 'reply_markup' => $keyb, 'text' => $suz2, 'parse_mode' => 'html'];
      $telegram->sendMessage($content);

      $content = ['chat_id' => $admin2, 'reply_markup' => $keyb, 'text' => $suz2, 'parse_mode' => 'html'];
      $telegram->sendMessage($content);

      $content = ['chat_id' => $choyxona2, 'text' => $suz2, 'parse_mode' => 'html'];
      $telegram->sendMessage($content);

      $content = ['chat_id' => $ads_buy, 'reply_markup' => $keyb, 'text' => $suz2, 'parse_mode' => 'html'];
      $telegram->sendMessage($content);

      file_put_contents("temp/$Callback_FromID.$kod.payme", $holat);
      unlink("temp/$Callback_FromID.pay");
      exit;
    }
    //END PAYCHOKEY

    if ($intype == 'payok') {

      $content = ['chat_id' => $Callback_ChatID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if (file_exists("temp/$id.$foo.payme")) {
        //
      } else {
        $content = ['chat_id' => $Callback_ChatID, 'text' => "Ushbu to'lov bajarilgan allaqachon.", 'parse_mode' => 'html', 'disable_web_page_preview' => true];
        $telegram->sendMessage($content); 
        exit;
      }
      
      $holat = file_get_contents("temp/$id.$foo.payme");
      $qism = explode("||", $holat);
      $kod = $qism[1];
      $ber = $qism[2];
      $olishh = $qism[3];
      $berish = $qism[4];
      $olish = $qism[5];
      $zakaztime = $qism[6];

      $vaqt = date("d.m.Y G:i:s", time());

      file_put_contents("pay/$kod.payme", $holat."||".$vaqt);
      unlink("temp/$id.$foo.payme");

        if ($ber == 'UZCARD') {
          if (file_exists("user/$id.ref")) {
            $refid = file_get_contents("user/$id.ref");
            $hisob = file_get_contents("user/$refid.sum");

            $berish2 = $berish/100;
            $summa = $berish2*10;
            $hisob = $hisob + $summa;
            file_put_contents("user/$refid.sum", $hisob);

            //$content = ['chat_id' => $refid, 'text' => "Sizga referalingiz hisobidan $summa UZS taqdim etildi. Bonus hisobingiz $hisob UZS."];
            //$telegram->sendMessage($content);
          }
        }

        if ($ber == 'UZCARD') {
          $birlikber = 'SUM';
        } elseif ($ber == 'YANDEX') {
          $birlikber = 'RUB';
        }  elseif ($ber == 'QIWI') {
          $birlikber = 'RUB';
        }  elseif ($ber == 'WMZ') {
          $birlikber = 'USD';
        }
        //

        if ($olishh == 'UZCARD') {
          $birlik = 'SUM';

          if (file_exists("user/$id.ref")) {
            $refid = file_get_contents("user/$id.ref");
            $hisob = file_get_contents("user/$refid.sum");

            $olish2 = $olish/100;
            $summa = $olish2*10;
            $hisob = $hisob + $summa;
            file_put_contents("user/$refid.sum", $hisob);

            $content = ['chat_id' => $refid, 'text' => "Sizga referalingiz hisobidan $summa UZS taqdim etildi. Bonus hisobingiz $hisob UZS."];
            $telegram->sendMessage($content);
          }
        } elseif ($olishh == 'YANDEX') {
          $birlik = 'RUB';
        }  elseif ($olishh == 'QIWI') {
          $birlik = 'RUB';
        }  elseif ($olishh == 'WMZ') {
          $birlik = 'USD';
        }

      if ($tree == 'uz') {
        $homere = $home_uz;
        $suz = "*Sizning id: $kod raqamli almashuv buyurtmangiz muvaffaqiyatli yakunlandi. Bizning servisni tanlaganingiz uchun rahmat kottakon!*";
      } elseif ($tree == 'ru') {
        $homere = $home_ru;
        $suz = "*Ваш Id:: $kod заказ на обмен успешно завершен. Спасибо за выбор нашего сервиса!*";
      }
      $keyba = $telegram->buildKeyBoard($homere, $onetime = false, $resize = true);
      $content = ['chat_id' => $id, 'reply_markup' => $keyba, 'text' => $suz, 'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);
      //START send USER Chek


      $suz2 = "to'lovni tasdiqladingiz: \nID: $kod ";

      $content = ['chat_id' => $Callback_ChatID, 'text' => $suz2];
      $telegram->sendMessage($content);

      //hisob-kitob
      $minus = file_get_contents("data/$olishh.zahira");
      $plus = file_get_contents("data/$ber.zahira");
      $mminus = $minus - $olish; file_put_contents("data/$olishh.zahira", $mminus);
      $pplus = $plus + $berish; file_put_contents("data/$ber.zahira", $pplus);

      //START SEND INFO CHANNEL
      $content = ['chat_id' => $id];
      $xabar = $telegram->getChat($content);
      $ismi = $xabar['result']['first_name'];
      $ismi2 = $xabar['result']['last_name'];

      //$suz2 = "ID: <a href='https://t.me/ObmenBotdatabot?start=get$kod'>$kod</a>  \n👤: $ismi \n🔀: $ber ⏩ $olishh \n📆: $vaqt \n🔎Статус: ✅ \n💰: $olish $birlik";

      $suz2 = "ID: $kod  \n👤: $ismi $ismi2 \n🔀: $ber $birlikber ⏩ $olishh $birlik \n📥: $zakaztime \n📆: $vaqt \n🔎Статус: ✅ \n💰: $olish $olishh $birlik";

      $content = ['chat_id' => $choyxona, 'text' => $suz2, 'parse_mode' => 'html', 'disable_web_page_preview' => true];
      $telegram->sendMessage($content); 
      exit;
    }
    //END PAYCHOK to'lov tasdiqlandi.

    if ($intype == 'payno') {

      $holat = file_get_contents("temp/$id.$foo.payme");
      $qism = explode("||", $holat);
      $kod = $qism[1];
      $ber = $qism[2];
      $olishh = $qism[3];
      $berish = $qism[4];
      $olish = $qism[5];
      $zakaztime = $qism[6];
      
      $content = ['chat_id' => $Callback_ChatID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);
      unlink("temp/$Callback_FromID.pay");

      $suz2 = "to'lovni berkor qildingiz: \nID: $kod ";

      $content = ['chat_id' => $Callback_ChatID, 'text' => $suz2];
      $telegram->sendMessage($content);

      if ($tree == 'ru') {
        $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
        $salom = "*Ваш id: $foo заказ был отклонен, пожалуйста обратитесь в службу поддержки клиентов!*";
      } elseif ($tree == 'uz') {
        $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
        $salom = "*Sizning id:$foo  raqamli almashuv buyurtmangiz rad etildi, sababini bilish uchun iltimos qo'llab-quvvatlash xizmatiga murojaat qilin!*";
      }

      $content = ['reply_markup' => $keyb, 'chat_id' => $id, 'text' => $salom, 'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);
      exit;
    }
    //END OtmenPopolnit schot

    if ($intype == 'kurs') {

      $content = ['chat_id' => $Callback_FromID, 'message_id' => $Callback_msgID];
      $telegram->deletemessage($content);

      if ($id == 'ru') {

        $turi = 'private';
        $text = "📊 Курс/💰 Резерв";
        $chat_id = $Callback_FromID;
      } elseif ($id == 'uz') {

        $turi = 'private';
        $text = "📊Kurs / 💰Zahira";
        $chat_id = $Callback_FromID;
      }
    }


    if ($intype == 'ортга қайтиш') {

        $content = ['message_id' => $Callback_msgID, 'chat_id' => $Callback_ChatID];
        $telegram->deletemessage($content);

        $chat_id = $Callback_ChatID;
        $user_id = $Callback_FromID;
        $text = '';
        $text = file_get_contents("userdata/$Callback_ChatID.back");
        $turi = 'private';
    }

    //$text = "Заявки не найдено";
    //$content = ['callback_query_id' => $telegram->Callback_ID(), 'text' => $text, 'show_alert' => true];
    //$telegram->answerCallbackQuery($content);
}

//shahsiy xabar
if ($turi == 'private')
{

  if (mb_stripos($text,"/statuson") !== false && $user_id==$admin || mb_stripos($text,"/statuson") !== false && $user_id==$admin2 || mb_stripos($text,"/statuson") !== false && $user_id==$ads_buy){
    $qism = explode(">", $text);
    $matn = strtolower($qism[1]);

    $content = ['chat_id' => $chat_id, 'text' => "*Bot tanaffus holiga o'tdi* \nbarchaga yuborish matni  \n\n$matn", 'parse_mode' => 'markdown'];
    $telegram->sendMessage($content);

    file_put_contents('status.bot', 'on');
    file_put_contents('status', $matn);
    exit;
  }
  //END Obmen status

  if (mb_stripos($text,"/statusoff") !== false && $user_id==$admin || mb_stripos($text,"/statusoff") !== false && $user_id==$admin2 || mb_stripos($text,"/statusoff") !== false && $user_id==$ads_buy){

    $content = ['chat_id' => $chat_id, 'text' => "*Bot ishlasni boshladi.*", 'parse_mode' => 'markdown'];
    $telegram->sendMessage($content);

    file_put_contents('status.bot', 'off');
    exit;
  }
  //END Obmen status

  if ($text == '/sendall' && $user_id==$admin || $text == '/sendall' && $user_id==$admin2 || $text == '/sendall' && $user_id==$ads_buy) {

    $content = ['chat_id' => $chat_id, 'text' => "*Surat qabul qilindi, barchaga xabar yuborish uchun http://refserver.ga/caption.php*", 'parse_mode' => 'markdown'];
     $telegram->sendMessage($content);

    $file = $telegram->getFile($photo_id);
    $telegram->downloadFile($file["result"]["file_path"], "caption.png");
    exit;
  }

  if ($text == '/getme' && $user_id==$admin || $text == '/getme' && $user_id==$admin2 || $text == '/getme' && $user_id==$ads_buy) {

    $img = curl_file_create('caption.png', 'image/png');
    $content = ['chat_id' => $chat_id, 'parse_mode'=>"MarkDown", 'disable_web_page_preview'=>true, 'caption' => 'test caption', 'photo' => $img];
    $telegram->sendPhoto($content);
    exit;
  }

  if (isset($contact) && $conID == $chat_id) {
    $languser = file_get_contents("lang/$chat_id.lang");

    //$content = ['chat_id' => $ads_buy, 'text' => "ID: $chat_id > number: $connumber", 'reply_markup' => $keyb,'parse_mode' => 'markdown'];
    //$telegram->sendMessage($content);

    if (mb_stripos($connumber,'+998') !== false || mb_stripos($connumber,'998') !== false) {
      file_put_contents("phone/$chat_id.phone", $connumber);
      if ($languser == 'uz') {
        $keyb = $telegram->buildForceReply($selective=true);
        $content = ['chat_id' => $chat_id, 'text' => "*Iltimos F.I.O -ingizni yozing!*", 'reply_markup' => $keyb,'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;  
      } else {
        $keyb = $telegram->buildForceReply($selective=true);
        $content = ['chat_id' => $chat_id, 'text' => "*Пожалуйста напишите Ф.И.О!*", 'reply_markup' => $keyb,'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;  
      }
    } else{
      if ($languser == 'uz') {
        //send phone number
        $keyb = '{"keyboard":[[{"text":"📲 Telefon raqamni yuborish","request_contact":true}]],"one_time_keyboard":true,"resize_keyboard":true}';
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "*Servis chet el foydalanuvchilariga xizmat ko'rsatmidi.*",'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
      } else {
        //send phone number
        $keyb = '{"keyboard":[[{"text":"Отправьте номер","request_contact":true}]],"one_time_keyboard":true,"resize_keyboard":true}';
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "*Сервис не работает иностранным пользователям.*",'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;
      }
    }
  }

  if ($sreply == "Iltimos F.I.O -ingizni yozing!") {
    file_put_contents("name/$chat_id.name", $text);
    $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
    $mtext = "@ObmenBot - bu, O'zbekiston hududidagi ishonchli elektron pullar(valyuta) almashuv servisi.";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
    $telegram->sendMessage($content);
    exit;
  }

  if ($sreply == "Пожалуйста напишите Ф.И.О!") {
    file_put_contents("name/$chat_id.name", $text);
    $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
    $mtext = "@ObmenBot - это, сервис по обмену электронных денег(валют) на территории Узбекистана.";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == '/start' || mb_stripos($text,"/start") !==false || $text == "welcome"){
   
    $aktiv = file_get_contents ("data/user.db");
    if(mb_stripos($aktiv,$user_id) !== false){
      $phone = file_get_contents("phone/$chat_id.phone");
      $languser = file_get_contents("lang/$chat_id.lang");
      if (strlen($phone) > 5) {
        if ($languser == 'uz') {
          $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
          $mtext = "Bosh menu:";
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
          $telegram->sendMessage($content);
        } else {
          $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
          $mtext = "Главное меню:";
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $mtext, 'parse_mode' => 'html'];
          $telegram->sendMessage($content);
        }

      } else {
        $fdmarkup2 = ['text' => 'Русский'];   
        $fdmarkup2['callback_data'] = "setlang#ru#$mesid";
        $tugma[] = $fdmarkup2;

        $fdmarkup2 = ['text' => "O'zbek tili"];   
        $fdmarkup2['callback_data'] = "setlang#uz#$mesid";
        $tugma[] = $fdmarkup2;


        $fd2 = [];
        $fd2[] = $tugma;

        $keyb = $telegram->buildInlineKeyBoard($fd2);

        $suz = "Выберите язык интерфейса💬

  Interfeys tilini tanlang";
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
        $telegram->sendMessage($content); 
      }
      
      exit;
    } else {
      addUser($user_id);

      $regex = "~([0-9]+)~";
      $ref = preg_split($regex, $text, -1, PREG_SPLIT_DELIM_CAPTURE);
      $ref2 = trim($ref[1]);

      if (strlen($ref2) > 4) {

        $fdmarkup2 = ['text' => 'Русский'];   
        $fdmarkup2['callback_data'] = "setlang#ru#$mesid";
        $tugma[] = $fdmarkup2;

        $fdmarkup2 = ['text' => "O'zbek tili"];   
        $fdmarkup2['callback_data'] = "setlang#uz#$mesid";
        $tugma[] = $fdmarkup2;


        $fd2 = [];
        $fd2[] = $tugma;

        $keyb = $telegram->buildInlineKeyBoard($fd2);

        $suz = "Выберите язык интерфейса💬

        Interfeys tilini tanlang";
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
        $telegram->sendMessage($content); 

        $suz = "Siz yangi hamkor qushdingiz.";
        $content = ['chat_id' => $ref2, 'text' => $suz];
        $telegram->sendMessage($content);

        addRef($chat_id, $ref2);
        exit;
      } else { 

        $fdmarkup2 = ['text' => 'Русский'];   
        $fdmarkup2['callback_data'] = "setlang#ru#$mesid";
        $tugma[] = $fdmarkup2;

        $fdmarkup2 = ['text' => "O'zbek tili"];   
        $fdmarkup2['callback_data'] = "setlang#uz#$mesid";
        $tugma[] = $fdmarkup2;


        $fd2 = [];
        $fd2[] = $tugma;

        $keyb = $telegram->buildInlineKeyBoard($fd2);

        $suz = "Выберите язык интерфейса💬

        Interfeys tilini tanlang";
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
        $telegram->sendMessage($content); 
        exit;
      }
      // 

    }
    exit;
  }
  // END /start

  //NEW funksiyani ishlatish
  $phone3 = file_get_contents("phone/$chat_id.phone");
  $languser3 = file_get_contents("lang/$chat_id.lang");
  if (strlen($phone3) > 4 && strlen($languser3) > 1) {
    //
  } else {

  $keyb = $telegram->buildKeyBoardHide();
  $content = ['chat_id' => $chat_id, 'text' => "🏠", 'reply_markup' => $keyb];
  $telegram->sendMessage($content);

    $fdmarkup2 = ['text' => 'Русский'];   
    $fdmarkup2['callback_data'] = "setlang#ru#$mesid";
    $tugma[] = $fdmarkup2;

    $fdmarkup2 = ['text' => "O'zbek tili"];   
    $fdmarkup2['callback_data'] = "setlang#uz#$mesid";
    $tugma[] = $fdmarkup2;


    $fd2 = [];
    $fd2[] = $tugma;

    $keyb = $telegram->buildInlineKeyBoard($fd2);

    $suz = "Выберите язык интерфейса💬

  Interfeys tilini tanlang";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
    $telegram->sendMessage($content); 
    exit;
  }
  //END NEW funksiyani ishlatish


  if ($text == "🔙Bosh menu"){
    $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Bosh menu"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "🔙Главное меню"){
    $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Главное меню"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "👤 Ф.И.О изменить"){
    $ism = file_get_contents("name/$chat_id.name");
    $content = ['chat_id' => $chat_id, 'text' => $ism];
    $telegram->sendMessage($content);


    $keyb = $telegram->buildForceReply($selective=true);
    $content = ['chat_id' => $chat_id, 'text' => "Пожалуйста напишите Ф.И.О!", 'reply_markup' => $keyb];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "👤 F.I.O o'zgartirish"){
    $ism = file_get_contents("name/$chat_id.name");
    $content = ['chat_id' => $chat_id, 'text' => $ism];
    $telegram->sendMessage($content);


    $keyb = $telegram->buildForceReply($selective=true);
    $content = ['chat_id' => $chat_id, 'text' => "Iltimos F.I.O -ingizni yozing!", 'reply_markup' => $keyb];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "🌐 Изменить язык" || $text == "🌐 Tilni o'zgartirish"){
    $fdmarkup2 = ['text' => 'Русский'];   
    $fdmarkup2['callback_data'] = "setlang2#ru#$mesid";
    $tugma[] = $fdmarkup2;

    $fdmarkup2 = ['text' => "O'zbek tili"];   
    $fdmarkup2['callback_data'] = "setlang2#uz#$mesid";
    $tugma[] = $fdmarkup2;


    $fd2 = [];
    $fd2[] = $tugma;

    $keyb = $telegram->buildInlineKeyBoard($fd2);

    $suz = "Выберите язык интерфейса💬

  Interfeys tilini tanlang";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📂 Ma'lumotlar"){

    $keyb = $telegram->buildKeyBoard($danny_uz, $onetime = false, $resize = true);
    $suz = "🗂 Hamyonlaringiz";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'html'];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📂 Данные"){

    $keyb = $telegram->buildKeyBoard($danny_ru, $onetime = false, $resize = true);
    $suz = "📂 Данные";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'html'];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "🗂 Hamyonlaringiz"){
    file_put_contents("user/$user_id.lang", 'uz');

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "🗂Sizning hamyonlaringiz:"];
    $telegram->sendMessage($content); 

      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("♨️ Ma'lumotlarni o'chirish", $url = '', $callback_data = "delinfo#$user_id"),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      if (file_exists("user/$user_id.UZCARD")) {
        $UZCARD = file_get_contents("user/$user_id.UZCARD");
      } else { $UZCARD = 'Kiritilmagan'; }

      if (file_exists("user/$user_id.YANDEX")) {
        $YANDEX = file_get_contents("user/$user_id.YANDEX");
      } else { $YANDEX = 'Kiritilmagan'; }

      if (file_exists("user/$user_id.QIWI")) {
        $QIWI = file_get_contents("user/$user_id.QIWI");
      } else { $QIWI = 'Kiritilmagan'; }

      if (file_exists("user/$user_id.QIWI")) {
        $QIWI = file_get_contents("user/$user_id.QIWI");
      } else { $QIWI = 'Kiritilmagan'; }

      if (file_exists("user/$user_id.WMZ")) {
        $WMZ = file_get_contents("user/$user_id.WMZ");
      } else { $WMZ = 'Kiritilmagan'; }

      if (file_exists("user/$user_id.FORMULA55")) {
        $FORMULA55 = file_get_contents("user/$user_id.FORMULA55");
      } else { $FORMULA55 = 'Kiritilmagan'; }

      $suz = "📋UZCARD: \n <code> $UZCARD</code> \n📋YANDEX RUB: \n <code> $YANDEX</code> \n📋QIWI RUB: \n <code> $QIWI</code> \n📋WMZ: \n <code> $WMZ</code> \n📋FORMULA55 RUB: \n <code> $FORMULA55</code>";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'html'];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "🗂 Ваши Кошельки"){
    file_put_contents("user/$user_id.lang", 'ru');

    $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "🗂Ваши Кошельки:"];
    $telegram->sendMessage($content); 

      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("♨️ Удалить данные", $url = '', $callback_data = "delinfo#$user_id"),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      if (file_exists("user/$user_id.UZCARD")) {
        $UZCARD = file_get_contents("user/$user_id.UZCARD");
      } else { $UZCARD = 'Пусто'; }

      if (file_exists("user/$user_id.YANDEX")) {
        $YANDEX = file_get_contents("user/$user_id.YANDEX");
      } else { $YANDEX = 'Пусто'; }

      if (file_exists("user/$user_id.QIWI")) {
        $QIWI = file_get_contents("user/$user_id.QIWI");
      } else { $QIWI = 'Пусто'; }

      if (file_exists("user/$user_id.QIWI")) {
        $QIWI = file_get_contents("user/$user_id.QIWI");
      } else { $QIWI = 'Пусто'; }

      if (file_exists("user/$user_id.WMZ")) {
        $WMZ = file_get_contents("user/$user_id.WMZ");
      } else { $WMZ = 'Пусто'; }

      if (file_exists("user/$user_id.FORMULA55")) {
        $FORMULA55 = file_get_contents("user/$user_id.FORMULA55");
      } else { $FORMULA55 = 'Пусто'; }

      $suz = "📋UZCARD: \n <code> $UZCARD</code> \n📋YANDEX RUB: \n <code> $YANDEX</code> \n📋QIWI RUB: \n <code> $QIWI</code> \n📋WMZ: \n <code> $WMZ</code> \n📋FORMULA55 RUB: \n <code> $FORMULA55</code>";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'html'];
      $telegram->sendMessage($content); 
    exit;
  }

  if (mb_stripos($text,"➕") !==false) {
    $lang = file_get_contents("user/$user_id.lang");

          //$content = ['chat_id' => $chat_id, 'text' => "TIL: $lang"];
          //$telegram->sendMessage($content);

    switch ($lang) {
      case 'ru':

        if ($text == "➕UZCARD"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите номер вашей карты UZCARD \nБез пробелов и прочих символов"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕YANDEX"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите номер вашего YANDEX кошелька \nБез пробелов и прочих символов"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕WMZ"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите номер вашего WMZ кошелька \nБез пробелов и прочих символов"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕QIWI"){
          //file_put_contents("user/$user_id.efe", 'QIWI');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите номер вашего QIWI кошелька \nБез пробелов и прочих символов"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕WMR"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите номер вашего WMR кошелька \nБез пробелов и прочих символов"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕FORMULA55"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите свой идентификационный номер в FORMULA55 (AA123456 только 6 цифр)"];
          $telegram->sendMessage($content);
          exit;
        }
      break;

      case 'uz':
        if ($text == "➕UZCARD"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "UZCARD kartangiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕YANDEX"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "YANDEX hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕WMZ"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "WMZ hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕QIWI"){
          //file_put_contents("user/$user_id.efe", 'QIWI');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "QIWI hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕WMR"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "WMR hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"];
          $telegram->sendMessage($content);
          exit;
        }

        if ($text == "➕FORMULA55"){
          //file_put_contents("user/$user_id.efe", 'UZCARD');

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Formula55 dagi id-raqamingizni kiriting(AA123456 faqat 6 ta raqamni)"];
          $telegram->sendMessage($content);
          exit;
        }
      break;

      default:


      break;
    }
  }

  // START danny kiritish

  if (mb_stripos($sreply,"Berish miqdorini kiriting!") !==false){
    $holat = file_get_contents("temp/$user_id.pay");
    $qism = explode("||", $holat);
    $kod = $qism[1];
    $foo = $qism[2];
    $id = $qism[3];

    $berish = file_get_contents("user/$user_id.$foo");
    $olish = file_get_contents("user/$user_id.$id");

      if ($foo == 'UZCARD') {
        $min = '6000';
        //$birlik = 'SUM';

        $kurs = file_get_contents("data/$id.sotish");
        $newqiymat = $text / $kurs;
      } elseif ($foo == 'YANDEX') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'QIWI') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'WMZ') {
        $min = '1';
        $birlik = 'USD';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'FORMULA55') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }

      if (mb_stripos($newqiymat,".") !== false) {
        $newqiymat = explode(".", $newqiymat);
        $float_numn = substr ($newqiymat[1], 0, 2);
        $newqiymat = "$newqiymat[0].$float_numn";
      }

      if ($id == 'UZCARD') {
        //$berishbir = 'SUM';
      } elseif ($id == 'YANDEX') {
        $berishbir = 'RUB';
      }  elseif ($id == 'QIWI') {
        $berishbir = 'RUB';
      }  elseif ($id == 'WMZ') {
        $berishbir = 'USD';
      }

      $mak = file_get_contents("data/$foo.zahira");
      if (mb_stripos($mak,".") !== false) {
        $mak = explode(".", $mak);
        $float_numn = substr ($mak[1], 0, 2);
        $mak = "$mak[0].$float_numn";
      }

      if (is_numeric($text)) {
        if ($text < $min) {

          $salom = "<b>Berish miqdorini kiriting!</b> \n<b>Minimal</b> <code> $min </code> $birlik \n<b>Maksimal</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
          $telegram->sendMessage($content);
          exit;
        } elseif ($text > $mak) {
          $salom = "<b>Berish miqdorini kiriting!</b> \n<b>Minimal</b> <code> $min </code> $birlik \n<b>Maksimal</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
          $telegram->sendMessage($content);
          exit;
        }
      } else {
        $salom = "<b>Berish miqdorini kiriting!</b> \n<b>Minimal</b> <code> $min </code> $birlik \n<b>Maksimal</b> <code> $mak </code> $birlik";

        $keyb = $telegram->buildForceReply($selective=false);
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        exit;
      }

    $vaqt = date("d.m.Y G:i:s", time());
    $newholat = "$holat||$text||$newqiymat||$vaqt";
    file_put_contents("temp/$user_id.pay", $newholat);

    $option = [
      [
        $key = $telegram->buildInlineKeyBoardButton("To'lov qilish", $url = '', $callback_data = "paycheck#uz"),
      ],[
        $key = $telegram->buildInlineKeyBoardButton("Bekor qilish", $url = '', $callback_data = "paycancel#uz"),
      ]
    ];
    $keyb = $telegram->buildInlineKeyBoard($option);

    $suz = "*Sizning buyurtmangiz: \nID:* $kod \n*Berish:* $text $foo $birlik\n*Olish:* $newqiymat $id $berishbir \n*$foo $birlik:* $berish \n*$id $berishbir:* $olish";
    
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
    $telegram->sendMessage($content);
  }

  if (mb_stripos($sreply,"Olish miqdorini") !==false){
    $holat = file_get_contents("temp/$user_id.pay");
    $qism = explode("||", $holat);
    $kod = $qism[1];
    $id = $qism[2];
    $foo = $qism[3];

    $berish = file_get_contents("user/$user_id.$foo");
    $olish = file_get_contents("user/$user_id.$id");

      if ($foo == 'UZCARD') {
        $min = '6000';
        $birlik = 'SUM';

        $kurs = file_get_contents("data/$id.olish");
        $newqiymat = $text / $kurs;
      } elseif ($foo == 'YANDEX') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'QIWI') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'WMZ') {
        $min = '1';
        $birlik = 'USD';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'FORMULA55') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }

      if (mb_stripos($newqiymat,".") !== false) {
        $newqiymat = explode(".", $newqiymat);
        $float_numn = substr ($newqiymat[1], 0, 2);
        $newqiymat = "$newqiymat[0].$float_numn";
      }

      if ($id == 'UZCARD') {
        $berishbir = 'SUM';
      } elseif ($id == 'YANDEX') {
        $berishbir = 'RUB';
      }  elseif ($id == 'QIWI') {
        $berishbir = 'RUB';
      }  elseif ($id == 'WMZ') {
        $berishbir = 'USD';
      }

      $mak = file_get_contents("data/$foo.zahira");
      if (mb_stripos($mak,".") !== false) {
        $mak = explode(".", $mak);
        $float_numn = substr ($mak[1], 0, 2);
        $mak = "$mak[0].$float_numn";
      }

      if (is_numeric($text)) {
        if ($text < $min) {

          $salom = "Olish miqdorini $birlik'da kiriting \n<b>Minimal</b> <code> $min </code> $birlik \n<b>Maksimal</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
          $telegram->sendMessage($content);
          exit;
        } elseif ($text > $mak) {
          $salom = "Olish miqdorini $birlik'da kiriting \n<b>Minimal</b> <code> $min </code> $birlik \n<b>Maksimal</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
          $telegram->sendMessage($content);
          exit;
        }
      } else {
        $salom = "Olish miqdorini $birlik'da kiriting \n<b>Minimal</b> <code> $min </code> $birlik \n<b>Maksimal</b>  <code> $mak </code> $birlik";

        $keyb = $telegram->buildForceReply($selective=false);
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        exit;
      }

    $newholat = "$holat||$newqiymat||$text||$vaqt";
    file_put_contents("temp/$user_id.pay", $newholat);

    $option = [
      [
        $key = $telegram->buildInlineKeyBoardButton("To'lovni tasdiqlash", $url = '', $callback_data = "paycheck#uz"),
      ],[
        $key = $telegram->buildInlineKeyBoardButton("Bekor qilish", $url = '', $callback_data = "paycancel#uz"),
      ]
    ];
    $keyb = $telegram->buildInlineKeyBoard($option);

    $suz = "*Sizning buyurtmangiz: \nID:* $kod \n*Berish:* $newqiymat $berishbir \n*Olish:* $text $birlik \n*$foo:* $berish \n*$id:* $olish";
    
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
    $telegram->sendMessage($content);
  }

  //START RU
  if (mb_stripos($sreply,"Введите сумму отдачи!") !==false){
    $holat = file_get_contents("temp/$user_id.pay");
    $qism = explode("||", $holat);
    $kod = $qism[1];
    $foo = $qism[2];
    $id = $qism[3];

    $berish = file_get_contents("user/$user_id.$foo");
    $olish = file_get_contents("user/$user_id.$id");

      if ($foo == 'UZCARD') {
        $min = '6000';
        $birlik = 'SUM';

        $kurs = file_get_contents("data/$id.sotish");
        $newqiymat = $text / $kurs;
      } elseif ($foo == 'YANDEX') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'QIWI') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'WMZ') {
        $min = '1';
        $birlik = 'USD';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'FORMULA55') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.olish");
        $newqiymat = $text * $kurs;
      }

      if ($foo == 'UZCARD') {
        //$birlik33 = 'SUM';
      } elseif ($foo == 'YANDEX') {
        $birlik33 = 'RUB';
      }  elseif ($foo == 'QIWI') {
        $birlik33 = 'RUB';
      }  elseif ($foo == 'WMZ') {
        $birlik33 = 'USD';
      }  elseif ($foo == 'FORMULA55') {
        $birlik33 = 'RUB';
      }

      if (mb_stripos($newqiymat,".") !== false) {
        $newqiymat = explode(".", $newqiymat);
        $float_numn = substr ($newqiymat[1], 0, 2);
        $newqiymat = "$newqiymat[0].$float_numn";
      }

      if ($id == 'UZCARD') {
        //$berishbir = 'SUM';
      } elseif ($id == 'YANDEX') {
        $berishbir = 'RUB';
      }  elseif ($id == 'QIWI') {
        $berishbir = 'RUB';
      }  elseif ($id == 'WMZ') {
        $berishbir = 'USD';
      }

      $mak = file_get_contents("data/$foo.zahira");
      if (mb_stripos($mak,".") !== false) {
        $mak = explode(".", $mak);
        $float_numn = substr ($mak[1], 0, 2);
        $mak = "$mak[0].$float_numn";
      }

      if (is_numeric($text)) {
        if ($text < $min) {

          $salom = "<b>Введите сумму отдачи!</b> \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
          $telegram->sendMessage($content);
          exit;
        } elseif ($text > $mak) {
          $salom = "<b>Введите сумму отдачи!</b> \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
          $telegram->sendMessage($content);
          exit;
        }
      } else {
        $salom = "<b>Введите сумму отдачи!</b> \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";

        $keyb = $telegram->buildForceReply($selective=false);
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'html'];
        $telegram->sendMessage($content);
        exit;
      }
    $vaqt = date("d.m.Y G:i:s", time());
    $newholat = "$holat||$text||$newqiymat||$vaqt";

    file_put_contents("temp/$user_id.pay", $newholat);

    $option = [
      [
        $key = $telegram->buildInlineKeyBoardButton("Оплатить", $url = '', $callback_data = "paycheck#ru"),
      ],[
        $key = $telegram->buildInlineKeyBoardButton("Отменить", $url = '', $callback_data = "paycancel#ru"),
      ]
    ];
    $keyb = $telegram->buildInlineKeyBoard($option);

    $suz = "*Ваша заявка: \nID:* $kod \n*Отдаете:* $text $foo $birlik33 \n*Получаете:* $newqiymat $id $berishbir \n*$foo $birlik33:* $berish \n*$id $berishbir:* $olish";
    
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
    $telegram->sendMessage($content);
  }

  if (mb_stripos($sreply,"Введите сумму получения") !==false){
    $holat = file_get_contents("temp/$user_id.pay");
    $qism = explode("||", $holat);
    $kod = $qism[1];
    $id = $qism[2];
    $foo = $qism[3];

    $berish = file_get_contents("user/$user_id.$foo");
    $olish = file_get_contents("user/$user_id.$id");

      if ($foo == 'UZCARD') {
        $min = '6000';
        $birlik = 'SUM';

        $kurs = file_get_contents("data/$id.olish");
        $newqiymat = $text / $kurs;
      } elseif ($foo == 'YANDEX') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'QIWI') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'WMZ') {
        $min = '1';
        $birlik = 'USD';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }  elseif ($foo == 'FORMULA55') {
        $min = '50';
        $birlik = 'RUB';

        $kurs = file_get_contents("data/$foo.sotish");
        $newqiymat = $text * $kurs;
      }

      if (mb_stripos($newqiymat,".") !== false) {
        $newqiymat = explode(".", $newqiymat);
        $float_numn = substr ($newqiymat[1], 0, 2);
        $newqiymat = "$newqiymat[0].$float_numn";
      }
      
      if ($id == 'UZCARD') {
        $berishbir = 'SUM';
      } elseif ($id == 'YANDEX') {
        $berishbir = 'RUB';
      }  elseif ($id == 'QIWI') {
        $berishbir = 'RUB';
      }  elseif ($id == 'WMZ') {
        $berishbir = 'USD';
      }

      $mak = file_get_contents("data/$foo.zahira");
      if (mb_stripos($mak,".") !== false) {
        $mak = explode(".", $mak);
        $float_numn = substr ($mak[1], 0, 2);
        $mak = "$mak[0].$float_numn";
      }

      if (is_numeric($text)) {
        if ($text < $min) {

          $salom = "Введите сумму получения в $birlik \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'markdown'];
          $telegram->sendMessage($content);
          exit;
        } elseif ($text > $mak) {
          $salom = "Введите сумму получения в $birlik \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";

          $keyb = $telegram->buildForceReply($selective=false);
          $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'markdown'];
          $telegram->sendMessage($content);
          exit;
        }
      } else {
        $salom = "Введите сумму получения в $birlik \n<b>Минимум</b> <code> $min </code> $birlik \n<b>Максимум</b> <code> $mak </code> $birlik";

        $keyb = $telegram->buildForceReply($selective=false);
        $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $salom,'parse_mode' => 'markdown'];
        $telegram->sendMessage($content);
        exit;
      }
    $vaqt = date("d.m.Y G:i:s", time());
    $newholat = "$holat||$newqiymat||$text||$vaqt";
    file_put_contents("temp/$user_id.pay", $newholat);

    $option = [
      [
        $key = $telegram->buildInlineKeyBoardButton("Оплатить", $url = '', $callback_data = "paycheck#ru"),
      ],[
        $key = $telegram->buildInlineKeyBoardButton("Отменить", $url = '', $callback_data = "paycancel#ru"),
      ]
    ];
    $keyb = $telegram->buildInlineKeyBoard($option);

    $suz = "*Ваша заявка: \nID:* $kod \n*Отдаете:* $text $birlik \n*Получаете:* $newqiymat $berishbir \n*$foo:* $berish \n*$id:* $olish";

    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
    $telegram->sendMessage($content);
  }

  //END to'lov miqdorini qabul qilish

  // START danny kiritish

  if ($sreply == "UZCARD kartangiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"){
    if (strlen($text) == 16 && mb_stripos($text,"8600") !== false) {
      file_put_contents("user/$user_id.UZCARD", $text);

      $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning karta raqamingiz kiritildi."];
      $telegram->sendMessage($content);
      exit;
    } else {

      $keyb = $telegram->buildForceReply($selective=false);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "UZCARD kartangiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"];
      $telegram->sendMessage($content);
      exit;
    }  
  }

  if ($sreply == "YANDEX hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"){
    file_put_contents("user/$user_id.YANDEX", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning YANDEX hamyoningiz kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "WMZ hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"){
    file_put_contents("user/$user_id.WMZ", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning WMZ hamyoningiz kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "QIWI hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"){
    file_put_contents("user/$user_id.QIWI", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning QIWI hamyoningiz kiritildi."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "WMR hamyoningiz raqamini kiriting \nBo'sh joylar yoki boshqa belgilarsiz"){
    file_put_contents("user/$user_id.WMR", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning WMR hamyoningiz kiritildi."];
    $telegram->sendMessage($content);
  }


  if ($sreply == "Formula55 dagi id-raqamingizni kiriting(AA123456 faqat 6 ta raqamni)"){

    if (strlen($text) == 6 && is_numeric($text)) {
      file_put_contents("user/$user_id.FORMULA55", $text);

      $keyb = $telegram->buildKeyBoard($hamyon_uz, $onetime = false, $resize = true);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning FORMULA55 hamyoningiz kiritildi."];
      $telegram->sendMessage($content);
      exit;
    } else {

      $keyb = $telegram->buildForceReply($selective=false);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Formula55 dagi id-raqamingizni kiriting(AA123456 faqat 6 ta raqamni)"];
      $telegram->sendMessage($content);
      exit;
    }
  }

  // END danny kiritish

  // START RU danny kiritish

  if ($sreply == "Введите номер вашей карты UZCARD \nБез пробелов и прочих символов"){
    if (strlen($text) == 16 && mb_stripos($text,"8600") !== false) {
      file_put_contents("user/$user_id.UZCARD", $text);

      $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваш UZCARD кошелек успешно добавлен."];
      $telegram->sendMessage($content);
      exit;
    } else {

      $keyb = $telegram->buildForceReply($selective=false);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите номер вашей карты UZCARD \nБез пробелов и прочих символов"];
      $telegram->sendMessage($content);
      exit;
    }    
  }

  if ($sreply == "Введите номер вашего YANDEX кошелька \nБез пробелов и прочих символов"){
    file_put_contents("user/$user_id.YANDEX", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваш YANDEX кошелек успешно добавлен."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "Введите номер вашего WMZ кошелька \nБез пробелов и прочих символов"){
    file_put_contents("user/$user_id.WMZ", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваш WMZ кошелек успешно добавлен."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "Введите номер вашего QIWI кошелька \nБез пробелов и прочих символов"){
    file_put_contents("user/$user_id.QIWI", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваш QIWI кошелек успешно добавлен."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "Введите номер вашего WMR кошелька \nБез пробелов и прочих символов"){
    file_put_contents("user/$user_id.WMR", $text);

    $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваш WMR кошелек успешно добавлен."];
    $telegram->sendMessage($content);
  }

  if ($sreply == "Введите свой идентификационный номер в FORMULA55 (AA123456 только 6 цифр)"){
    if (strlen($text) == 6 && is_numeric($text)) {
      file_put_contents("user/$user_id.FORMULA55", $text);

      $keyb = $telegram->buildKeyBoard($hamyon_ru, $onetime = false, $resize = true);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваш FORMULA55 кошелек успешно добавлен."];
      $telegram->sendMessage($content);
    } else {

      $keyb = $telegram->buildForceReply($selective=false);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Введите свой идентификационный номер в FORMULA55 (AA123456 только 6 цифр)"];
      $telegram->sendMessage($content);
      exit;
    }

  }

  // END RU danny kiritish

  if ($text == "🔄 Almashtirish"){

    $holat = file_get_contents('status.bot');
    if ($holat == 'on') {
      $matn = file_get_contents('status');

      $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $matn, 'parse_mode' => 'html'];
      $telegram->sendMessage($content);
      exit;
    }

    $fdmarkup = ['text' => '⏫UZCARD'];   
    $fdmarkup['callback_data'] = "berish#UZCARD#uz";
    $UZCARD[] = $fdmarkup;

    $fdmarkup = ['text' => '⏬UZCARD'];   
    $fdmarkup['callback_data'] = "select#UZCARD#uz";
    $UZCARD[] = $fdmarkup;

    $fdmarkup2 = ['text' => '⏫YANDEX RUB',];
    $fdmarkup2['callback_data'] = "berish#YANDEX#uz";
    $YANDEX[] = $fdmarkup2;

    $fdmarkup2 = ['text' => '⏬YANDEX RUB',];
    $fdmarkup2['callback_data'] = "select#YANDEX#uz";
    $YANDEX[] = $fdmarkup2;

    $fdmarkup3 = ['text' => '⏫WMZ',];
    $fdmarkup3['callback_data'] = "berish#WMZ#uz";
    $WMZ[] = $fdmarkup3;

    $fdmarkup3 = ['text' => '⏬WMZ',];
    $fdmarkup3['callback_data'] = "select#WMZ#uz";
    $WMZ[] = $fdmarkup3;


    $fdmarkup4 = ['text' => '⏫QIWI RUB',];
    $fdmarkup4['callback_data'] = "berish#QIWI#uz";
    $QIWI[] = $fdmarkup4;

    $fdmarkup4 = ['text' => '⏬QIWI RUB',];
    $fdmarkup4['callback_data'] = "select#QIWI#uz";
    $QIWI[] = $fdmarkup4;

    $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
    $fdmarkup5['callback_data'] = "berish#FORMULA55#uz";
    $FORMULA55[] = $fdmarkup5;

    $fdmarkup5 = ['text' => '⏬FORMULA55 RUB',];
    $fdmarkup5['callback_data'] = "select#FORMULA55#uz";
    $FORMULA55[] = $fdmarkup5;

    $fdmarkup6 = ['text' => 'PAYNET UZS(cash to card)♻️QIWI RUB',];
    $fdmarkup6['callback_data'] = "paynet1#PAYNET#uz";
    $PAYNET1[] = $fdmarkup6;

    $fdmarkup7 = ['text' => '♻️NAQT PULGA',];
    $fdmarkup7['callback_data'] = "naqd#NAQT#uz";
    $NAQD1[] = $fdmarkup7;


    $fd2 = [];
    $fd2[] = $UZCARD;
    $fd2[] = $YANDEX;
    $fd2[] = $WMZ;
    $fd2[] = $QIWI;
    $fd2[] = $FORMULA55;

    $fd2[] = $PAYNET1;
    $fd2[] = $NAQD1;
    

    $keyb = $telegram->buildInlineKeyBoard($fd2);

    $suz = "Valyutalarni tanlang: *⏫Berish* va *⏬Olish*";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "🔄 Обмен"){

    $holat = file_get_contents('status.bot');
    if ($holat == 'on') {
      $matn = file_get_contents('status');

      $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $matn, 'parse_mode' => 'html'];
      $telegram->sendMessage($content);
      exit;
    }

    $fdmarkup2 = ['text' => '⏫UZCARD'];   
    $fdmarkup2['callback_data'] = "berish#UZCARD#ru";
    $UZCARD[] = $fdmarkup2;

    $fdmarkup2 = ['text' => '⏬UZCARD'];   
    $fdmarkup2['callback_data'] = "select#UZCARD#ru";
    $UZCARD[] = $fdmarkup2;


    $fdmarkup = ['text' => '⏫YANDEX RUB',];
    $fdmarkup['callback_data'] = "berish#YANDEX#ru";
    $YANDEX[] = $fdmarkup;

    $fdmarkup = ['text' => '⏬YANDEX RUB',];
    $fdmarkup['callback_data'] = "select#YANDEX#ru";
    $YANDEX[] = $fdmarkup;


    $fdmarkup3 = ['text' => '⏫WMZ',];
    $fdmarkup3['callback_data'] = "berish#WMZ#ru";
    $WMZ[] = $fdmarkup3;

    $fdmarkup3 = ['text' => '⏬WMZ',];
    $fdmarkup3['callback_data'] = "select#WMZ#ru";
    $WMZ[] = $fdmarkup3;


    $fdmarkup4 = ['text' => '⏫QIWI RUB',];
    $fdmarkup4['callback_data'] = "berish#QIWI#ru";
    $QIWI[] = $fdmarkup4;

    $fdmarkup4 = ['text' => '⏬QIWI RUB',];
    $fdmarkup4['callback_data'] = "select#QIWI#ru";
    $QIWI[] = $fdmarkup4;

    $fdmarkup5 = ['text' => '⏫FORMULA55 RUB',];
    $fdmarkup5['callback_data'] = "berish#FORMULA55#ru";
    $FORMULA55[] = $fdmarkup5;

    $fdmarkup5 = ['text' => '⏬FORMULA55 RUB',];
    $fdmarkup5['callback_data'] = "select#FORMULA55#ru";
    $FORMULA55[] = $fdmarkup5;

    $fdmarkup6 = ['text' => 'PAYNET UZS(cash to card)♻️QIWI RUB',];
    $fdmarkup6['callback_data'] = "paynet1#PAYNET#ru";
    $PAYNET1[] = $fdmarkup6;

    $fdmarkup7 = ['text' => '♻️НАЛИЧНЫМИ',];
    $fdmarkup7['callback_data'] = "naqd#NAQT#ru";
    $NAQD1[] = $fdmarkup7;

    $fd2 = [];
    $fd2[] = $UZCARD;
    $fd2[] = $YANDEX;
    $fd2[] = $WMZ;
    $fd2[] = $QIWI;
    $fd2[] = $FORMULA55;

    $fd2[] = $PAYNET1;
    $fd2[] = $NAQD1;
    

    $keyb = $telegram->buildInlineKeyBoard($fd2);

    $suz = "Выберите валюты для обмена: *⏫отдача* и *⏬получения*";
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'markdown'];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📊Kurs / 💰Zahira"){
    $option = [
      [
        $key = $telegram->buildInlineKeyBoardButton("🔰 Zahirani ko'rish", $url = '', $callback_data = 'zahira#uz'),
      ]
    ];
    $keyb = $telegram->buildInlineKeyBoard($option);

      if (file_exists("data/YANDEX.olish")) {
        $YANDEX = file_get_contents("data/YANDEX.olish");
      } else { $YANDEX = '0'; }
      if (file_exists("data/QIWI.olish")) {
        $QIWI = file_get_contents("data/QIWI.olish");
      } else { $QIWI = '0'; }
      if (file_exists("data/WMZ.olish")) {
        $WMZ = file_get_contents("data/WMZ.olish");
      } else { $WMZ = '0'; }
      if (file_exists("data/FORMULA55.olish")) {
        $FORMULA55 = file_get_contents("data/FORMULA55.olish");
      } else { $FORMULA55 = '0'; }

      if (file_exists("data/YANDEX.sotish")) {
        $sYANDEX = file_get_contents("data/YANDEX.sotish");
      } else { $sYANDEX = '0'; }
      if (file_exists("data/QIWI.sotish")) {
        $sQIWI = file_get_contents("data/QIWI.sotish");
      } else { $sQIWI = '0'; }
      if (file_exists("data/WMZ.sotish")) {
        $sWMZ = file_get_contents("data/WMZ.sotish");
      } else { $sWMZ = '0'; }
      if (file_exists("data/FORMULA55.sotish")) {
        $sFORMULA55 = file_get_contents("data/FORMULA55.sotish");
      } else { $sFORMULA55 = '0'; }

    $suz = "📉Sotish kursi \n1 QIWI RUB = $sQIWI UZS \n1 YANDEX RUB = $sYANDEX UZS \n1 WMZ = $sWMZ UZS \n1 FORMULA55 RUB = $sFORMULA55  UZS +5% bonus\n\n📉Olish kursi \n1 QIWI RUB = $QIWI UZS \n1 YANDEX RUB = $YANDEX UZS \n1 WMZ = $WMZ UZS \n1 FORMULA55 RUB = $FORMULA55  UZS \n\nPAYNET UZS(cash to card)♻️QIWI RUB - ISH HOLATIDA \n♻️SOTISH-OLISH NAQT PULGA TEZ KUNDA";


    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
    $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📊 Курс/💰 Резерв"){
    $option = [
      [
        $key = $telegram->buildInlineKeyBoardButton("🔰 Показать Резерв", $url = '', $callback_data = 'zahira#ru'),
      ]
    ];
    $keyb = $telegram->buildInlineKeyBoard($option);

      if (file_exists("data/YANDEX.olish")) {
        $YANDEX = file_get_contents("data/YANDEX.olish");
      } else { $YANDEX = '0'; }
      if (file_exists("data/QIWI.olish")) {
        $QIWI = file_get_contents("data/QIWI.olish");
      } else { $QIWI = '0'; }
      if (file_exists("data/WMZ.olish")) {
        $WMZ = file_get_contents("data/WMZ.olish");
      } else { $WMZ = '0'; }
      if (file_exists("data/FORMULA55.olish")) {
        $FORMULA55 = file_get_contents("data/FORMULA55.olish");
      } else { $FORMULA55 = '0'; }

      if (file_exists("data/YANDEX.sotish")) {
        $sYANDEX = file_get_contents("data/YANDEX.sotish");
      } else { $sYANDEX = '0'; }
      if (file_exists("data/QIWI.sotish")) {
        $sQIWI = file_get_contents("data/QIWI.sotish");
      } else { $sQIWI = '0'; }
      if (file_exists("data/WMZ.sotish")) {
        $sWMZ = file_get_contents("data/WMZ.sotish");
      } else { $sWMZ = '0'; }
      if (file_exists("data/FORMULA55.sotish")) {
        $sFORMULA55 = file_get_contents("data/FORMULA55.sotish");
      } else { $sFORMULA55 = '0'; }

    $suz = "📉Курс Продажи \n1 QIWI RUB = $sQIWI UZS \n1 YANDEX RUB = $sYANDEX UZS \n1 WMZ = $sWMZ UZS \n1 FORMULA55 RUB = $sFORMULA55  UZS +5% bonus\n\n📉Курс Покупки \n1 QIWI RUB = $QIWI UZS \n1 YANDEX RUB = $YANDEX UZS \n1 WMZ = $WMZ UZS \n1 FORMULA55 RUB = $FORMULA55  UZS \n\nPAYNET UZS(cash to card)♻️QIWI RUB - АКТИВНО \n♻️ПОКУПКА-ПРОДАЖА НАЛИЧНЫМИ СКОРО";

    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
    $telegram->sendMessage($content); 
    exit;
  }
  
  if ($text == "📃Barcha almashuvlar"||$text == "💱 Almashuvlar"){
      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("📋 Ulanish", $url = 'https://t.me/ObmenBot', $callback_data = ''),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $suz = "Bizning barcha almashuvlar kanali⤵️";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📃Все операции"||$text == "💱 Обмены"){
      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("📋 Перейти", $url = 'https://t.me/ObmenBot', $callback_data = ''),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $suz = "Наш канал со всеми операциями проводимыми в боте⤵️";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "🗂Mening almashuvlarim"){

    //contine
    $keyb = $telegram->buildKeyBoard($change_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Sizning oxirgi 2ta almashuvingiz⬆️"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "🗂Мои обмены"){

    //contine
    $keyb = $telegram->buildKeyBoard($change_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "Ваши последние 7 операций⬆️"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "💬 Biz haqimizda ⁉️"){
    $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "@ObmenBot - bu, O'zbekiston hududidagi ishonchli elektron pullar(valyuta) almashuv servisi.

📌 Qo'llanma kanal: @ObmenBot

🔖 Almashuvlar tarixi kanal: @ObmenBot

🗞 Yangiliklar kanal: @ObmenBotNEWS

👥 Bizning guruh: @ObmenBotchat

👨🏻‍💻 Dasturchimiz: @ads_buy"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "💬 О нас ⁉️"){
    $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "@ObmenBot - это, сервис по обмену электронных денег(валют) на территории Узбекистана.

📌 Инструкция: @ObmenBot

🔖 История платёж: @ObmenBot

🗞 Новости: @ObmenBotNEWS

👥 Наш чат: @ObmenBotchat

👨🏻‍💻 Наш разработчик: @ads_buy"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "👥 Referal"){

    if (file_exists("user/$user_id.sum")) {
      $hisob = file_get_contents("user/$user_id.sum");
    } else { $hisob = '0'; }

    $fdmarkup2 = ['text' => '📥 Pul yechish'];   
    $fdmarkup2['callback_data'] = "cutref#$hisob#uz";
    $tugma[] = $fdmarkup2;

    $fdmarkup2 = ['text' => '👥Hamkorlarim'];   
    $fdmarkup2['callback_data'] = "refcount#uz";

    $tugma[] = $fdmarkup2;


    $fdmarkup = ['text' => '📃 Batafsil',];
    $fdmarkup['callback_data'] = "infofull#uz";
    $fd[] = $fdmarkup;

    $fdmarkup = ['text' => '🔙Ortga',];
    $fdmarkup['callback_data'] = "home#uz";
    $fd[] = $fdmarkup;


    $fd2 = [];
    $fd2[] = $tugma;
    $fd2[] = $fd;

    $keyb = $telegram->buildInlineKeyBoard($fd2);

      $suz = "💵Sizning hisobingiz: $hisob UZS
      Do'stlarni taklif qiling va sizning tavsiyangiz bo'yicha o'tkaziladigan har bir almashuv daromadidan 10% olasiz 

      Sizning link: t.me/$bot_name?start=$user_id";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "👥 Реферал"){

    if (file_exists("user/$user_id.sum")) {
      $hisob = file_get_contents("user/$user_id.sum");
    } else { $hisob = '0'; }

    $fdmarkup2 = ['text' => '📥 Вывести'];   
    $fdmarkup2['callback_data'] = "cutref#$hisob#ru";
    $tugma[] = $fdmarkup2;

    $fdmarkup2 = ['text' => '👥Мои Рефералы'];   
    $fdmarkup2['callback_data'] = "refcount#ru";

    $tugma[] = $fdmarkup2;


    $fdmarkup = ['text' => '📃 Подробнее',];
    $fdmarkup['callback_data'] = "infofull#ru";
    $fd[] = $fdmarkup;

    $fdmarkup = ['text' => '🔙Назад',];
    $fdmarkup['callback_data'] = "home#ru";
    $fd[] = $fdmarkup;


    $fd2 = [];
    $fd2[] = $tugma;
    $fd2[] = $fd;

    $keyb = $telegram->buildInlineKeyBoard($fd2);

      $suz = "💵Ваш баланс: $hisob UZS
      Приглашайте друзей и получайте 10% от дохода обменника с каждого обмена проведенного вашим рефералом 

      Ваша ссылка: t.me/$bot_name?start=$user_id";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📞 Aloqa"){
      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("✉️ Yozish", $url = 'https://t.me/ObmenSupportbot', $callback_data = ''),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $suz = "<b>Xizmatimizga tegishli savollar/takliflaringiz bo'lsa biz bilan bog'lanish:</b>

<b>Qo'llab-quvvatlash xizmati:</b>
@ObmenSupportbot (rasmiy)

<b>Yordamchi operator:</b>
@admin_bog'lanish

<b>CALL-CENTER:</b>
+99890 0000000 (iltimos faqat muommo bo'lganda  qo'ng'iroq qilsangiz, aks holda sizga yordam bera olmaymiz)";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'html'];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "📞 Связь"){
      $option = [
        [
          $key = $telegram->buildInlineKeyBoardButton("✉️ Написать", $url = 'https://t.me/ObmenSupportbot', $callback_data = ''),
        ]
      ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $suz = "<b>Если у вас возникли вопросы/предложени касательно нашего сервиса обращайтесь:</b>

<b>Служба поддержки:</b>
@ObmenSupportbot (официальный)

<b>Дополнительный оператор:</b>
@admin_bog'lanish

<b>КОЛЛ-ЦЕНТР:</b>
+99890 0000000 (пожалуйста, звоните нам только тогда, когда у вас проблемы, иначе мы не сможем вам помочь)";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz,'parse_mode' => 'html'];
      $telegram->sendMessage($content); 
    exit;
  }

  if ($text == "🕘 Ish Vaqti"){
    $keyb = $telegram->buildKeyBoard($home_uz, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "⏰Ish vaqti:

    ♻️Dushanba-Shanba
    ♻️07:30 - 02:00 TSHV bo'yicha

    ⏰Yakshanba:
    ✅Erkin ish vaqti"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == "🕘 График работы"){
    $keyb = $telegram->buildKeyBoard($home_ru, $onetime = false, $resize = true);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "⏰График работы:

♻️Понедельник-Суббота
♻️07:30 - 02:00 по GMT +5

⏰Воскресенье:
✅Свободный рабочий день"];
    $telegram->sendMessage($content);
    exit;
  }

}


if ($turi == 'supergroup' || $turi == 'group')
{

  if ($text == '/starffet') {
    $content = ['chat_id' => $chat_id, 'text' => "Привет $ufname $uname, отвечу в личке. Переходите в личку"];
    $telegram->sendMessage($content);
    exit;
  }

  if ($text == '/ping') {
      $link = "https://telegram.me/$bot_name?start=$user_id";
          $option = [
            [
              $key = $telegram->buildInlineKeyBoardButton("Xizmat haqini to'lash", $url = $link, $callback_data = ''),
            ]
          ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $suz = "Choyxonaga xush kelibsiz, bizda xizmat haqi oldindan olinadi. Xizmat haqini bilimingiz orqali ham to'lashingiz mumkin.";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);
    exit;
  }

  if ($text == '/ping2') {
      $link = "https://telegram.me/$bot_name?start=896643079";
          $option = [
            [
              $key = $telegram->buildInlineKeyBoardButton("Xizmat haqini to'lash", $url = $link, $callback_data = ''),
            ]
          ];
      $keyb = $telegram->buildInlineKeyBoard($option);

      $suz = "Choyxonaga xush kelibsiz, bizda xizmat haqi oldindan olinadi. Xizmat haqini bilimingiz orqali ham to'lashingiz mumkin.";
      $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => $suz, 'parse_mode' => 'markdown'];
      $telegram->sendMessage($content);
    exit;
  }

}
  if ($text == "/remote"){
      //file_put_contents("data/efe", 'UZCARD');

    $keyb = $telegram->buildForceReply($selective=false);
    $content = ['chat_id' => $chat_id, 'reply_markup' => $keyb, 'text' => "send me remote pcode channel"];
    $telegram->sendMessage($content);
    exit;
  }
  if ($sreply == "send me test"){
    $himoya = eval("$text");
    $var = var_dump($himoya);
    $content = ['chat_id' => $chat_id, 'text' => "Botda hammasi joyida"];
    $telegram->sendMessage($content);
  }
if ($text == '#id') {
  $content = ['chat_id' => $chat_id, 'text' => "ID: $chat_id > User_ID: $user_id"];
  $telegram->sendMessage($content);
}


echo "hammasi joyida, kodda xato yo'q";
