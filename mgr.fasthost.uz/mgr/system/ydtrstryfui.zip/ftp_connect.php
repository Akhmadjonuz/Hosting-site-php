<?php
//-----Подключаем функции-----//
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");

if(!empty($_SESSION['servere']) && !empty($_SESSION['logine']) && !empty($_SESSION['passe']))
{
$serv=@ftp_connect($_SESSION['servere']);
$login=@ftp_login($serv,$_SESSION['logine'],$_SESSION['passe']);
if(!$serv){$error='<div class="err">Не удалось установить соединение с сервером</div>';}
elseif(!$login){$error='<div class="err">Не удалось войти на сервер, Возможно срок оплаты просрочен и ваш аккаунт отключен!</div>';
}
if(empty($error)){
$savedir=$_SESSION['servere'].'-'.$_SESSION['logine'];
if(!is_dir('tmp/'.$savedir)) mkdir('tmp/'.$savedir,0777); chmod('tmp/'.$savedir,0777);
if ($_SERVER['PHP_SELF'] == '/mgr/index.php'){
header('Location: /mgr/explode.php');
}
}else{
if ($_SERVER['PHP_SELF'] != '/mgr/index.php'){
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
title($title);
}
err($error);
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
exit();
unset($_SESSION['servere']);
unset($_SESSION['logine']);
unset($_SESSION['passe']);
}
}else{
if ($_SERVER['PHP_SELF'] != '/mgr/index.php'){
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
title($title);
}
err('<div class="err">Ошибка авторизации. Возможно ваша сессия устарела. Попробуйте авторизоваться ещё раз</div>');
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
exit();
}
?>